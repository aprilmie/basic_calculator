<?php
// ── Forgot Password — MARKETPLACE. ───────────────────────────────────────────
// 3-step flow: Step 1 = Enter email  |  Step 2 = Verify OTP  |  Step 3 = New password
// Mirrors the SchoolCanteenOrderingSystem forgot_password.php flow.

if (session_status() === PHP_SESSION_NONE) session_start();
require_once 'includes/config.php';
require_once 'includes/mailer.php';

// Already logged in? Go home.
if (isLoggedIn()) {
    header('Location: ' . BASE_URL . '/index.php');
    exit;
}

$db = getDB();

// ── Ensure OTP / reset columns exist ─────────────────────────────────────────
$existing = $db->query("SHOW COLUMNS FROM users")->fetchAll(PDO::FETCH_COLUMN);
if (!in_array('otp_code',     $existing)) $db->exec("ALTER TABLE users ADD COLUMN otp_code VARCHAR(6) DEFAULT NULL");
if (!in_array('otp_expires',  $existing)) $db->exec("ALTER TABLE users ADD COLUMN otp_expires BIGINT DEFAULT NULL");
if (!in_array('otp_attempts', $existing)) $db->exec("ALTER TABLE users ADD COLUMN otp_attempts TINYINT DEFAULT 0");
if (!in_array('reset_token',  $existing)) $db->exec("ALTER TABLE users ADD COLUMN reset_token VARCHAR(64) DEFAULT NULL");
if (!in_array('reset_expires',$existing)) $db->exec("ALTER TABLE users ADD COLUMN reset_expires BIGINT DEFAULT NULL");

// ── Magic-link handler: ?token=xxx skips OTP, drops into step 3 ──────────────
if ($_SERVER['REQUEST_METHOD'] === 'GET' && !empty($_GET['token'])) {
    $tok = trim($_GET['token']);
    $now = time();
    $stmt = $db->prepare("SELECT id, email, full_name FROM users WHERE reset_token = ? AND reset_expires > ?");
    $stmt->execute([$tok, $now]);
    $row = $stmt->fetch();
    if ($row) {
        $_SESSION['fp_step']        = 3;
        $_SESSION['fp_email']       = $row['email'];
        $_SESSION['fp_reset_token'] = $tok;
        unset($_SESSION['fp_fallback_otp']);
    } else {
        unset($_SESSION['fp_step'], $_SESSION['fp_email'], $_SESSION['fp_reset_token'], $_SESSION['fp_fallback_otp']);
        $_SESSION['fp_link_expired'] = true;
    }
    header('Location: forgot_password.php');
    exit;
}

$step  = $_SESSION['fp_step']  ?? 1;
$email = $_SESSION['fp_email'] ?? '';
$swal  = null;

$link_expired = false;
if (!empty($_SESSION['fp_link_expired'])) {
    $link_expired = true;
    unset($_SESSION['fp_link_expired']);
}

// ── POST handler ──────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = trim($_POST['action'] ?? '');

    // ── STEP 1: Send OTP ──────────────────────────────────────────────────────
    if ($action === 'send_otp') {
        $email = trim($_POST['email'] ?? '');
        if (empty($email)) {
            $swal = ['type'=>'warning','title'=>'Email Required','text'=>'Please enter your email address.'];
            $step = 1;
        } else {
            $stmt = $db->prepare("SELECT id, full_name, verify_status FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch();
            if (!$user) {
                $swal = ['type'=>'error','title'=>'Email Not Found','text'=>'No account exists with that email address.'];
                $step = 1;
            } elseif ($user['verify_status'] != 1) {
                $swal = ['type'=>'warning','title'=>'Email Not Verified','text'=>'Your account is not yet verified. Please verify your email before resetting your password.'];
                $step = 1;
            } else {
                $otp           = str_pad(random_int(0, 999999), 6, '0', STR_PAD_LEFT);
                $expires       = time() + 600;          // OTP valid 10 min
                $magic_token   = bin2hex(random_bytes(32));
                $magic_expires = time() + 900;          // Magic link valid 15 min

                $db->prepare("UPDATE users SET otp_code=?, otp_expires=?, otp_attempts=0, reset_token=?, reset_expires=? WHERE email=?")
                   ->execute([$otp, $expires, $magic_token, $magic_expires, $email]);

                $magic_link = SITE_URL . '/forgot_password.php?token=' . urlencode($magic_token);
                $result     = sendOtpEmail($email, $user['full_name'], $otp, $magic_link);

                $_SESSION['fp_step']  = 2;
                $_SESSION['fp_email'] = $email;
                if (!$result['ok']) {
                    $_SESSION['fp_fallback_otp'] = $result['otp'] ?? $otp;
                } else {
                    unset($_SESSION['fp_fallback_otp']);
                }

                $swal = $result['ok']
                    ? ['type'=>'success','title'=>'Code Sent!','text'=>'A 6-digit code was sent to ' . $email . '. Check your inbox (and spam). It expires in 10 minutes. The email also contains a direct link valid for 15 minutes.']
                    : ['type'=>'info','title'=>'Email Could Not Be Sent','text'=>'SMTP not configured. Your code is shown below.'];
                $step = 2;
            }
        }
    }

    // ── STEP 2: Verify OTP ────────────────────────────────────────────────────
    elseif ($action === 'verify_otp') {
        $otp_input = trim(implode('', $_POST['otp'] ?? []));
        $email     = $_SESSION['fp_email'] ?? '';
        if (empty($email)) {
            unset($_SESSION['fp_step'], $_SESSION['fp_email'], $_SESSION['fp_fallback_otp']);
            header('Location: forgot_password.php');
            exit;
        }
        if (strlen($otp_input) !== 6 || !ctype_digit($otp_input)) {
            $swal = ['type'=>'warning','title'=>'Invalid Code','text'=>'Please enter the complete 6-digit code.'];
            $step = 2;
        } else {
            $stmt = $db->prepare("SELECT id, otp_code, otp_expires, otp_attempts FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $row = $stmt->fetch();

            if ($row['otp_attempts'] >= 5) {
                $db->prepare("UPDATE users SET otp_code=NULL, otp_expires=NULL, otp_attempts=0 WHERE email=?")->execute([$email]);
                unset($_SESSION['fp_step'], $_SESSION['fp_email'], $_SESSION['fp_fallback_otp']);
                $swal = ['type'=>'error','title'=>'Too Many Attempts','text'=>'You have exceeded the attempt limit. Please request a new code.'];
                $step = 1; $email = '';
            } elseif (time() > $row['otp_expires']) {
                $swal = ['type'=>'warning','title'=>'Code Expired','text'=>'Your code has expired. Please request a new one.'];
                $step = 2;
            } elseif ($otp_input !== $row['otp_code']) {
                $db->prepare("UPDATE users SET otp_attempts = otp_attempts + 1 WHERE email=?")->execute([$email]);
                $remaining = max(0, 5 - ($row['otp_attempts'] + 1));
                $swal = ['type'=>'error','title'=>'Incorrect Code','text'=>'Wrong code. ' . ($remaining > 0 ? "$remaining attempt(s) remaining." : 'No attempts left — request a new code.')];
                $step = 2;
            } else {
                // OTP correct — issue a reset token
                $reset_token = bin2hex(random_bytes(32));
                $reset_exp   = time() + 900;
                $db->prepare("UPDATE users SET otp_code=NULL, otp_expires=NULL, otp_attempts=0, reset_token=?, reset_expires=? WHERE email=?")
                   ->execute([$reset_token, $reset_exp, $email]);
                $_SESSION['fp_step']        = 3;
                $_SESSION['fp_reset_token'] = $reset_token;
                unset($_SESSION['fp_fallback_otp']);
                $swal = ['type'=>'success','title'=>'Code Verified!','text'=>'Identity confirmed. Please set your new password.'];
                $step = 3;
            }
        }
    }

    // ── STEP 2: Resend OTP ────────────────────────────────────────────────────
    elseif ($action === 'resend_otp') {
        $email = $_SESSION['fp_email'] ?? '';
        if (empty($email)) { header('Location: forgot_password.php'); exit; }

        $stmt = $db->prepare("SELECT full_name FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $row = $stmt->fetch();
        $full_name = $row['full_name'] ?? 'User';

        $otp           = str_pad(random_int(0, 999999), 6, '0', STR_PAD_LEFT);
        $expires       = time() + 600;
        $magic_token   = bin2hex(random_bytes(32));
        $magic_expires = time() + 900;

        $db->prepare("UPDATE users SET otp_code=?, otp_expires=?, otp_attempts=0, reset_token=?, reset_expires=? WHERE email=?")
           ->execute([$otp, $expires, $magic_token, $magic_expires, $email]);

        $magic_link = SITE_URL . '/forgot_password.php?token=' . urlencode($magic_token);
        $result     = sendOtpEmail($email, $full_name, $otp, $magic_link);

        if (!$result['ok']) {
            $_SESSION['fp_fallback_otp'] = $result['otp'] ?? $otp;
        } else {
            unset($_SESSION['fp_fallback_otp']);
        }

        $_SESSION['fp_step'] = 2;
        $swal = ['type'=>'info','title'=>'New Code Sent','text'=>'A fresh 6-digit code and a direct reset link have been sent to ' . $email . '.'];
        $step = 2;
    }

    // ── STEP 3: Save new password ─────────────────────────────────────────────
    elseif ($action === 'reset_password') {
        $reset_token      = $_SESSION['fp_reset_token'] ?? '';
        $new_password     = trim($_POST['new_password']     ?? '');
        $confirm_password = trim($_POST['confirm_password'] ?? '');

        if (empty($reset_token)) { header('Location: forgot_password.php'); exit; }

        if (empty($new_password) || strlen($new_password) < 6) {
            $swal = ['type'=>'warning','title'=>'Weak Password','text'=>'Password must be at least 6 characters.'];
            $step = 3;
        } elseif ($new_password !== $confirm_password) {
            $swal = ['type'=>'error','title'=>'Passwords Do Not Match','text'=>'Both passwords must be identical.'];
            $step = 3;
        } else {
            $now  = time();
            $stmt = $db->prepare("SELECT id FROM users WHERE reset_token = ? AND reset_expires > ?");
            $stmt->execute([$reset_token, $now]);
            $row = $stmt->fetch();

            if (!$row) {
                unset($_SESSION['fp_step'], $_SESSION['fp_email'], $_SESSION['fp_reset_token']);
                $swal = ['type'=>'error','title'=>'Session Expired','text'=>'Reset session expired. Please start over.','redirect'=>'forgot_password.php','btn'=>'Start Over'];
                $step = 1; $email = '';
            } else {
                $db->prepare("UPDATE users SET password=?, reset_token=NULL, reset_expires=NULL WHERE id=?")
                   ->execute([password_hash($new_password, PASSWORD_DEFAULT), $row['id']]);
                unset($_SESSION['fp_step'], $_SESSION['fp_email'], $_SESSION['fp_reset_token'], $_SESSION['fp_fallback_otp']);
                $swal = ['type'=>'success','title'=>'Password Reset!','text'=>'Your password has been updated. You can now log in.','redirect'=>'login.php','btn'=>'Go to Login'];
                $step = 1; $email = '';
            }
        }
    }

    // ── Cancel ────────────────────────────────────────────────────────────────
    elseif ($action === 'cancel') {
        unset($_SESSION['fp_step'], $_SESSION['fp_email'], $_SESSION['fp_reset_token'], $_SESSION['fp_fallback_otp']);
        header('Location: forgot_password.php');
        exit;
    }
}

// Re-read session state for rendering
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $step  = $_SESSION['fp_step']  ?? 1;
    $email = $_SESSION['fp_email'] ?? '';
}
$fallback_otp = $_SESSION['fp_fallback_otp'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Forgot Password — MARKETPLACE.</title>
<link rel="stylesheet" href="css/style.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Outfit:wght@300;400;600;700;800&display=swap" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<style>
  body { background: #f4f4f4; font-family: 'Outfit', sans-serif; margin: 0; }

  .fp-wrap { max-width: 460px; margin: 56px auto 80px; padding: 0 16px; }

  .fp-brand {
    text-align: center;
    font-family: 'Bebas Neue', sans-serif;
    font-size: 2rem;
    letter-spacing: 2px;
    color: #111;
    margin-bottom: 24px;
  }
  .fp-brand span { color: #e01010; }

  .fp-card {
    background: #fff;
    border-radius: 14px;
    box-shadow: 0 4px 28px rgba(0,0,0,.10);
    padding: 38px 40px 32px;
    border-top: 5px solid #e01010;
  }

  /* Step bar */
  .step-bar { display: flex; align-items: center; margin-bottom: 28px; }
  .step-dot {
    width: 32px; height: 32px; border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    font-size: .78rem; font-weight: 700; flex-shrink: 0;
    transition: all .3s;
  }
  .step-dot.done   { background: #28a745; color: #fff; }
  .step-dot.active { background: #e01010; color: #fff; box-shadow: 0 0 0 4px rgba(224,16,16,.16); }
  .step-dot.idle   { background: #eee; color: #aaa; }
  .step-line { flex: 1; height: 3px; background: #eee; margin: 0 5px; }
  .step-line.done  { background: #28a745; }

  /* Headings */
  .fp-card h2 { margin: 0 0 4px; color: #111; font-size: 1.35rem; font-weight: 700; }
  .fp-sub { color: #999; font-size: .88rem; margin: 0 0 22px; line-height: 1.6; }

  /* Form groups */
  .fg { margin-bottom: 16px; }
  .fg label { display: block; font-weight: 600; font-size: .87rem; color: #333; margin-bottom: 6px; }
  .fg input[type=email],
  .fg input[type=password],
  .fg input[type=text] {
    width: 100%; padding: 11px 13px;
    border: 1.5px solid #ddd; border-radius: 8px;
    font-size: .95rem; box-sizing: border-box;
    font-family: 'Outfit', sans-serif;
    transition: border-color .18s, box-shadow .18s;
  }
  .fg input:focus { outline: none; border-color: #e01010; box-shadow: 0 0 0 3px rgba(224,16,16,.10); }

  /* OTP boxes */
  .otp-row { display: flex; gap: 10px; justify-content: center; margin: 8px 0 20px; }
  .otp-row input {
    width: 50px; height: 60px; text-align: center;
    font-size: 1.5rem; font-weight: 700;
    border: 2px solid #ddd; border-radius: 10px;
    outline: none; font-family: 'Outfit', sans-serif;
    transition: border-color .18s, box-shadow .18s;
    color: #111;
    -moz-appearance: textfield;
  }
  .otp-row input::-webkit-outer-spin-button,
  .otp-row input::-webkit-inner-spin-button { -webkit-appearance: none; margin: 0; }
  .otp-row input:focus  { border-color: #e01010; box-shadow: 0 0 0 3px rgba(224,16,16,.12); }
  .otp-row input.filled { border-color: #28a745; background: #f5fff7; }

  /* Buttons */
  .fp-btn {
    width: 100%; padding: 13px;
    background: #e01010; color: #fff;
    border: none; border-radius: 9px;
    font-size: 1rem; font-weight: 700;
    cursor: pointer; letter-spacing: .3px;
    font-family: 'Outfit', sans-serif;
    transition: background .18s, transform .1s;
  }
  .fp-btn:hover  { background: #b80d0d; transform: translateY(-1px); }
  .fp-btn:active { transform: translateY(0); }

  .link-btn {
    background: none; border: none; color: #e01010;
    font-weight: 600; cursor: pointer; font-size: .88rem;
    padding: 0; text-decoration: underline;
    font-family: 'Outfit', sans-serif;
  }
  .cancel-link {
    color: #aaa; font-size: .85rem; cursor: pointer;
    background: none; border: none; text-decoration: underline;
    font-family: 'Outfit', sans-serif;
  }

  /* Fallback OTP display */
  .fallback-box {
    background: #fffbec; border: 2px dashed #ffc107;
    border-radius: 10px; padding: 14px 16px;
    margin-bottom: 18px; text-align: center;
  }
  .fallback-box p { color: #856404; font-size: .83rem; margin: 0 0 8px; }
  .fallback-code  { font-size: 2rem; font-weight: 800; letter-spacing: 8px; color: #111; font-family: monospace; }

  .email-badge {
    background: #f0f2f5; border-radius: 8px;
    padding: 7px 12px; font-size: .87rem;
    color: #333; font-weight: 600;
    display: inline-block; margin-bottom: 18px;
  }

  /* Eye toggle wrapper */
  .pw-wrap { position: relative; display: block; }
  .pw-wrap input { width: 100%; padding-right: 44px !important; box-sizing: border-box; }
  .pw-toggle {
    position: absolute; right: 0; top: 0; bottom: 0;
    width: 44px;
    display: flex; align-items: center; justify-content: center;
    background: none; border: none; cursor: pointer;
    padding: 0; color: #aaa; font-size: 1.1rem; line-height: 1;
    border-radius: 0 8px 8px 0;
    transition: color .18s;
  }
  .pw-toggle:hover { color: #e01010; }
</style>
</head>
<body>

<div class="fp-wrap">

  <div class="fp-brand">MARKET<span>PLACE.</span></div>

  <div class="fp-card">

    <!-- Step progress bar -->
    <div class="step-bar">
      <div class="step-dot <?= $step > 1 ? 'done' : ($step == 1 ? 'active' : 'idle') ?>"><?= $step > 1 ? '✓' : '1' ?></div>
      <div class="step-line <?= $step > 1 ? 'done' : '' ?>"></div>
      <div class="step-dot <?= $step > 2 ? 'done' : ($step == 2 ? 'active' : 'idle') ?>"><?= $step > 2 ? '✓' : '2' ?></div>
      <div class="step-line <?= $step > 2 ? 'done' : '' ?>"></div>
      <div class="step-dot <?= $step == 3 ? 'active' : 'idle' ?>">3</div>
    </div>

    <?php if ($step === 1): ?>
    <!-- ── STEP 1: Enter email ─────────────────────────────────────── -->
    <h2>Forgot Password</h2>
    <p class="fp-sub">Enter your registered email and we'll send a 6-digit verification code to confirm your identity.</p>

    <?php if ($link_expired): ?>
    <div style="background:#fff3cd;border:1.5px solid #ffc107;border-radius:9px;padding:12px 16px;margin-bottom:18px;color:#856404;font-size:.88rem;display:flex;align-items:center;gap:10px;">
      <span style="font-size:1.2rem;">⚠️</span>
      <span>That reset link has <strong>expired or already been used</strong>. Enter your email below to request a fresh one.</span>
    </div>
    <?php endif; ?>

    <form action="forgot_password.php" method="post">
      <input type="hidden" name="action" value="send_otp">
      <div class="fg">
        <label>Email Address</label>
        <input type="email" name="email" value="<?= htmlspecialchars($email) ?>" placeholder="you@email.com" required autofocus>
      </div>
      <button type="submit" class="fp-btn">📧 Send Verification Code</button>
    </form>
    <p style="text-align:center;margin-top:14px;">
      <a href="login.php" style="color:#aaa;font-size:.87rem;">← Back to Login</a>
    </p>

    <?php elseif ($step === 2): ?>
    <!-- ── STEP 2: Enter OTP ───────────────────────────────────────── -->
    <h2>Enter Verification Code</h2>
    <p class="fp-sub">We sent a 6-digit code to:</p>
    <div class="email-badge">📧 <?= htmlspecialchars($email) ?></div>

    <?php if ($fallback_otp): ?>
    <div class="fallback-box">
      <p>📬 We couldn't send the email right now. Here is your verification code:</p>
      <div class="fallback-code"><?= htmlspecialchars($fallback_otp) ?></div>
    </div>
    <?php endif; ?>

    <form action="forgot_password.php" method="post" id="otp-form">
      <input type="hidden" name="action" value="verify_otp">
      <?php for ($i = 1; $i <= 6; $i++): ?>
      <input type="hidden" name="otp[]" id="otp-h<?= $i ?>" value="">
      <?php endfor; ?>
      <div class="otp-row">
        <?php for ($i = 1; $i <= 6; $i++): ?>
        <input type="number" id="d<?= $i ?>" min="0" max="9" maxlength="1" inputmode="numeric"
               <?= $i == 1 ? 'autocomplete="one-time-code"' : '' ?>>
        <?php endfor; ?>
      </div>
      <button type="submit" class="fp-btn">✅ Verify Code</button>
    </form>

    <p style="text-align:center;margin-top:14px;font-size:.87rem;color:#888;">
      Didn't get it?&nbsp;
      <form action="forgot_password.php" method="post" style="display:inline;">
        <input type="hidden" name="action" value="resend_otp">
        <button type="submit" class="link-btn">Resend Code</button>
      </form>
      &nbsp;·&nbsp;
      <form action="forgot_password.php" method="post" style="display:inline;">
        <input type="hidden" name="action" value="cancel">
        <button type="submit" class="cancel-link">Use different email</button>
      </form>
    </p>

    <?php elseif ($step === 3): ?>
    <!-- ── STEP 3: New password ────────────────────────────────────── -->
    <h2>Set New Password</h2>
    <p class="fp-sub">Identity verified ✓ — enter your new password below.</p>

    <form action="forgot_password.php" method="post">
      <input type="hidden" name="action" value="reset_password">
      <div class="fg">
        <label>New Password <span style="color:#aaa;font-size:.78rem;">(min. 6 characters)</span></label>
        <div class="pw-wrap">
          <input type="password" name="new_password" id="fp-pw" placeholder="••••••••" required autofocus>
          <button type="button" class="pw-toggle" onclick="togglePw('fp-pw',this)" title="Show/hide password">👁</button>
        </div>
      </div>
      <div class="fg">
        <label>Confirm New Password</label>
        <div class="pw-wrap">
          <input type="password" name="confirm_password" id="fp-cpw" placeholder="••••••••" required>
          <button type="button" class="pw-toggle" onclick="togglePw('fp-cpw',this)" title="Show/hide password">👁</button>
        </div>
      </div>
      <button type="submit" class="fp-btn">🔒 Reset Password</button>
    </form>
    <?php endif; ?>

  </div><!-- /.fp-card -->
</div><!-- /.fp-wrap -->

<!-- SweetAlert2 ──────────────────────────────────────────────────────────── -->
<?php if ($swal): ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
  Swal.fire({
    icon:                <?= json_encode($swal['type']) ?>,
    title:               <?= json_encode($swal['title']) ?>,
    text:                <?= json_encode($swal['text']) ?>,
    confirmButtonColor:  '#e01010',
    confirmButtonText:   <?= json_encode($swal['btn'] ?? 'OK') ?>
  }).then(function (r) {
    <?php if (!empty($swal['redirect'])): ?>
    if (r.isConfirmed) window.location.href = <?= json_encode($swal['redirect']) ?>;
    <?php endif; ?>
  });
});
</script>
<?php endif; ?>

<!-- OTP digit-input behaviour ────────────────────────────────────────────── -->
<script>
(function () {
  var digits = [];
  for (var i = 1; i <= 6; i++) digits.push(document.getElementById('d' + i));
  if (!digits[0]) return;

  function syncHidden() {
    digits.forEach(function (d, i) {
      var h = document.getElementById('otp-h' + (i + 1));
      if (h) h.value = d.value;
      d.classList.toggle('filled', d.value !== '');
    });
  }

  digits.forEach(function (inp, idx) {
    inp.addEventListener('input', function () {
      if (this.value.length > 1) this.value = this.value.slice(-1);
      syncHidden();
      if (this.value && idx < 5) digits[idx + 1].focus();
      if (idx === 5 && digits.every(function (d) { return d.value !== ''; }))
        document.getElementById('otp-form').submit();
    });
    inp.addEventListener('keydown', function (e) {
      if (e.key === 'Backspace' && !this.value && idx > 0) {
        digits[idx - 1].focus();
        digits[idx - 1].value = '';
        syncHidden();
      }
    });
    inp.addEventListener('focus', function () { this.select(); });
  });

  digits[0].addEventListener('paste', function (e) {
    var p = (e.clipboardData || window.clipboardData).getData('text').replace(/\D/g, '').slice(0, 6);
    if (p.length) {
      e.preventDefault();
      p.split('').forEach(function (ch, i) { if (digits[i]) digits[i].value = ch; });
      digits[Math.min(p.length, 5)].focus();
      syncHidden();
    }
  });

  digits[0].focus();
})();
</script>

<!-- Password show/hide ────────────────────────────────────────────────────── -->
<script>
function togglePw(id, btn) {
  var inp  = document.getElementById(id);
  var show = inp.type === 'password';
  inp.type      = show ? 'text' : 'password';
  btn.style.color = show ? '#e01010' : '#aaa';
  btn.title     = show ? 'Hide password' : 'Show password';
}
</script>

</body>
</html>
