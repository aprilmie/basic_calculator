<?php
// ── Login / Register / Forgot-password page ──────────────────────────────────
session_start();
require_once 'includes/config.php';
require_once 'includes/mailer.php';

// Already logged in → go to dashboard
if (isLoggedIn()) {
    redirect('/pages/' . $_SESSION['role'] . '/dashboard.php');
}

// ── Defaults ─────────────────────────────────────────────────────────────────
$tab        = $_GET['tab'] ?? 'login';   // login | register | forgot
$error      = '';
$success    = '';
$sellerMode = false;  // tracks whether "Sell" tile is selected on the register form
$forgotStep  = 'request'; // request | reset
$forgotEmail = '';

// ── Form handling ─────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $db     = getDB();
    $action = $_POST['action'] ?? '';

    // ── LOGIN ─────────────────────────────────────────────────────────────────
    if ($action === 'login') {
        $email = trim($_POST['email'] ?? '');
        $pass  = $_POST['password'] ?? '';

        $stmt = $db->prepare('SELECT * FROM users WHERE email = ?');
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($pass, $user['password'])) {
            if ($user['status'] === 'banned') {
                $error = 'Your account has been banned.';
                $tab   = 'login';
            } elseif (isset($user['verify_status']) && $user['verify_status'] == 0) {
                $error = 'Please verify your email address before logging in. Check your inbox for the verification link.';
                $tab   = 'login';
            } else {
                $_SESSION['user_id']     = $user['id'];
                $_SESSION['role']        = $user['role'];
                $_SESSION['welcome_user'] = ['name' => $user['full_name'], 'role' => $user['role']];
                redirect('/pages/' . $user['role'] . '/dashboard.php');
            }
        } else {
            $error = 'Invalid email or password.';
            $tab   = 'login';
        }
    }

    // ── REGISTER ──────────────────────────────────────────────────────────────
    if ($action === 'register') {
        $name      = trim($_POST['full_name']  ?? '');
        $email     = trim($_POST['email']      ?? '');
        $pass      = $_POST['password']        ?? '';
        $storeName = trim($_POST['store_name'] ?? '');
        $role      = in_array($_POST['role'] ?? '', ['customer', 'seller'])
                     ? $_POST['role'] : 'customer';
        $sellerMode = ($role === 'seller');

        if (!$name || !$email || !$pass) {
            $error = 'All fields are required.';
            $tab   = 'register';
        } elseif ($role === 'seller' && !$storeName) {
            $error = 'Store name is required.';
            $tab   = 'register';
        } else {
            $check = $db->prepare('SELECT id FROM users WHERE email = ?');
            $check->execute([$email]);

            if ($check->fetch()) {
                $error = 'Email already registered.';
                $tab   = 'register';
            } else {
                // Sellers are displayed by their store name instead of their personal name
                $displayName = ($role === 'seller' && $storeName) ? $storeName : $name;

                // Generate a verification token
                $token = bin2hex(random_bytes(32));

                $db->prepare('INSERT INTO users (full_name, email, password, role, verify_token, verify_status) VALUES (?,?,?,?,?,0)')
                   ->execute([$displayName, $email, password_hash($pass, PASSWORD_DEFAULT), $role, $token]);

                // Send verification email
                $result = sendVerificationEmail($email, $displayName, $token);

                if ($result['ok']) {
                    $success = "Account created! We've sent a verification link to <strong>" . htmlspecialchars($email) . "</strong>. Please check your inbox and verify your email before logging in.";
                    $tab     = 'login';
                } else {
                    // Still registered, but warn about email failure
                    $success = "Account created! However, the verification email could not be sent. Please contact support.";
                    $tab     = 'login';
                }
            }
        }
    }

    // ── FORGOT PASSWORD ───────────────────────────────────────────────────────
    if ($action === 'forgot') {
        $email = trim($_POST['email'] ?? '');
        if (!$email) {
            $error = 'Please enter your email address.';
            $tab   = 'forgot';
        } else {
            $db   = getDB();
            $stmt = $db->prepare('SELECT id, full_name FROM users WHERE email = ?');
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if ($user) {
                $otp     = strval(random_int(100000, 999999));
                $expires = date('Y-m-d H:i:s', time() + 600); // 10 min

                // Ensure otp columns exist
                $cols = array_column($db->query("SHOW COLUMNS FROM users")->fetchAll(), 'Field');
                if (!in_array('reset_otp', $cols)) {
                    $db->exec("ALTER TABLE users ADD COLUMN reset_otp VARCHAR(6) DEFAULT NULL");
                }
                if (!in_array('reset_otp_expires', $cols)) {
                    $db->exec("ALTER TABLE users ADD COLUMN reset_otp_expires DATETIME DEFAULT NULL");
                }

                $db->prepare('UPDATE users SET reset_otp = ?, reset_otp_expires = ? WHERE id = ?')
                   ->execute([$otp, $expires, $user['id']]);

                sendOtpEmail($email, $user['full_name'], $otp);
            }

            // Always show success to prevent email enumeration
            $success = 'If that email is registered, a reset code has been sent.';
            $tab     = 'forgot';
        }
    }

    // ── VERIFY OTP + RESET PASSWORD ──────────────────────────────────────────
    if ($action === 'reset_password') {
        $email   = trim($_POST['email']    ?? '');
        $otp     = trim($_POST['otp']      ?? '');
        $newpass = $_POST['new_password']  ?? '';
        $db      = getDB();

        $stmt = $db->prepare('SELECT id, reset_otp, reset_otp_expires FROM users WHERE email = ?');
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if (!$user || $user['reset_otp'] !== $otp || strtotime($user['reset_otp_expires']) < time()) {
            $error   = 'Invalid or expired reset code. Please try again.';
            $tab     = 'forgot';
            $forgotStep = 'reset';
            $forgotEmail = $email;
        } elseif (strlen($newpass) < 6) {
            $error   = 'Password must be at least 6 characters.';
            $tab     = 'forgot';
            $forgotStep = 'reset';
            $forgotEmail = $email;
        } else {
            $db->prepare('UPDATE users SET password = ?, reset_otp = NULL, reset_otp_expires = NULL WHERE id = ?')
               ->execute([password_hash($newpass, PASSWORD_DEFAULT), $user['id']]);
            $success = 'Password reset successfully! You can now log in.';
            $tab     = 'login';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Sign In — MARKETPLACE.</title>
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;900&display=swap"
        rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.all.min.js"></script>
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: 'Outfit', sans-serif;
      background: #0a0a0a;
      min-height: 100vh;
      display: flex; flex-direction: column;
    }

    /* Nav */
    .nav {
      background: #0a0a0a;
      border-bottom: 2px solid #e01010;
      height: 58px;
      display: flex; align-items: center;
      padding: 0 36px; flex-shrink: 0;
    }
    .nav-brand {
      font-size: 24px; font-weight: 900; letter-spacing: -0.5px;
      color: #fff; text-decoration: none; text-transform: uppercase;
    }
    .nav-brand span { color: #e01010; }

    /* Page background */
    .auth-bg {
      flex: 1;
      display: flex; align-items: center; justify-content: center;
      padding: 40px 16px 60px;
      background:
        radial-gradient(ellipse 65% 52% at 50% 0%,   rgba(155,0,0,0.72) 0%, transparent 65%),
        radial-gradient(ellipse 45% 38% at 0% 100%,  rgba(100,0,0,0.32) 0%, transparent 60%),
        radial-gradient(ellipse 45% 38% at 100% 100%, rgba(80,0,0,0.22) 0%, transparent 60%),
        #0a0a0a;
    }

    /* Card */
    .auth-card {
      background: #fff;
      border-radius: 10px;
      padding: 34px 34px 38px;
      width: 100%; max-width: 386px;
      box-shadow: 0 28px 70px rgba(0,0,0,0.55);
      animation: cardIn 0.4s cubic-bezier(0.22,1,0.36,1) both;
    }
    @keyframes cardIn {
      from { opacity: 0; transform: translateY(18px) scale(0.97); }
      to   { opacity: 1; transform: translateY(0) scale(1); }
    }
    .card-brand {
      font-size: 26px; font-weight: 900; letter-spacing: -0.5px;
      color: #0a0a0a; text-transform: uppercase; line-height: 1; margin-bottom: 4px;
    }
    .card-brand span { color: #e01010; }
    .card-sub { font-size: 13px; color: #aaa; margin-bottom: 20px; }

    /* Tabs */
    .tab-row {
      display: flex;
      border: 1.5px solid #ddd;
      border-radius: 5px;
      overflow: hidden;
      margin-bottom: 22px;
    }
    .tab-btn {
      flex: 1; padding: 10px;
      border: none; background: #efefef;
      font-family: 'Outfit', sans-serif;
      font-size: 13px; font-weight: 600; color: #888;
      cursor: pointer; transition: all 0.15s;
    }
    .tab-btn.active { background: #fff; color: #111; font-weight: 700; }

    /* Fields */
    .field-label {
      display: block;
      font-size: 10px; font-weight: 700; letter-spacing: 1.3px;
      text-transform: uppercase; color: #aaa;
      margin-bottom: 7px;
    }
    .field-input {
      width: 100%; padding: 11px 13px;
      border: 1.5px solid #e2e2e2; border-radius: 5px;
      font-family: 'Outfit', sans-serif; font-size: 14px; color: #111;
      outline: none; background: #fff;
      transition: border-color 0.15s, box-shadow 0.15s;
      margin-bottom: 14px;
    }
    .field-input:focus {
      border-color: #e01010;
      box-shadow: 0 0 0 3px rgba(224,16,16,0.08);
    }
    .field-input::placeholder { color: #c0c0c0; }

    /* Role tiles (register page) */
    .iwantto-lbl {
      font-size: 10px; font-weight: 700; letter-spacing: 1.3px;
      text-transform: uppercase; color: #aaa;
      display: block; margin-bottom: 10px;
    }
    .role-row {
      display: flex; gap: 12px; justify-content: center;
      margin-bottom: 18px;
    }
    .role-tile {
      flex: 1; max-width: 124px;
      border: 2px solid #e2e2e2; border-radius: 7px;
      padding: 16px 10px 12px;
      text-align: center; cursor: pointer;
      transition: all 0.15s; background: #fff; user-select: none;
    }
    .role-tile:hover  { border-color: #e01010; background: #fff8f8; }
    .role-tile.active { border-color: #e01010; background: #fff0f0; }
    .role-tile-icon { font-size: 30px; display: block; margin-bottom: 7px; }
    .role-tile-name {
      font-size: 14px; font-weight: 800; letter-spacing: 1px;
      color: #111; text-transform: uppercase;
    }

    /* Submit button */
    .submit-btn {
      width: 100%; padding: 13px;
      border: none; border-radius: 5px;
      background: #e01010; color: #fff;
      font-family: 'Outfit', sans-serif;
      font-size: 14px; font-weight: 800; letter-spacing: 2.5px;
      text-transform: uppercase; cursor: pointer; margin-top: 6px;
      transition: background 0.18s, box-shadow 0.18s;
    }
    .submit-btn:hover { background: #c00; box-shadow: 0 4px 18px rgba(224,16,16,0.32); }

    /* Forgot password link */
    .forgot-link {
      display: block; text-align: right;
      font-size: 12px; font-weight: 600; color: #e01010;
      background: none; border: none; padding: 0; cursor: pointer;
      margin-top: -8px; margin-bottom: 14px; width: 100%;
      text-decoration: none;
    }
    .forgot-link:hover { text-decoration: underline; }

    /* Demo credentials hint */
    .demo-hint { display: none; }

    /* Password field with eye toggle */
    .pw-wrap {
      position: relative;
      display: block;
      margin-bottom: 14px;
    }
    .pw-wrap .field-input {
      margin-bottom: 0;
      padding-right: 42px;
      width: 100%;
      box-sizing: border-box;
    }
    .pw-eye {
      position: absolute;
      right: 0; top: 0; bottom: 0;
      width: 42px;
      display: flex; align-items: center; justify-content: center;
      background: none; border: none;
      cursor: pointer; padding: 0;
      color: #bbb;
      border-radius: 0 8px 8px 0;
      transition: color 0.15s;
    }
    .pw-eye:hover { color: #e01010; }
    .eye-icon {
      width: 18px; height: 18px;
      stroke: currentColor; stroke-width: 2;
      stroke-linecap: round; stroke-linejoin: round;
      fill: none;
    }

    /* Forgot password panel */
    .back-btn {
      display: inline-flex; align-items: center; gap: 5px;
      font-size: 12px; font-weight: 600; color: #e01010;
      background: none; border: none; padding: 0; cursor: pointer;
      margin-bottom: 18px; text-decoration: none;
    }
    .back-btn:hover { text-decoration: underline; }
    .forgot-icon  { text-align: center; font-size: 40px; margin-bottom: 10px; }
    .forgot-title {
      font-size: 22px; font-weight: 900; letter-spacing: -0.3px;
      color: #111; text-align: center; margin-bottom: 6px; text-transform: uppercase;
    }
    .forgot-desc {
      font-size: 13px; color: #aaa; text-align: center;
      line-height: 1.6; margin-bottom: 22px;
    }
  </style>
</head>
<body>

<!-- ── Navigation ─────────────────────────────────────────────────────────── -->
<nav class="nav">
  <a href="index.php" class="nav-brand">MARKETPLACE<span>.</span></a>
</nav>

<!-- ── Auth card ──────────────────────────────────────────────────────────── -->
<div class="auth-bg">
  <div class="auth-card">

    <?php if ($tab !== 'forgot'): ?>
      <!-- Brand + tabs -->
      <div class="card-brand">MARKETPLACE<span>.</span></div>
      <div class="card-sub">Your local online marketplace</div>

      <div class="tab-row">
        <button class="tab-btn <?= $tab === 'login'    ? 'active' : '' ?>" onclick="showTab('login')">Sign In</button>
        <button class="tab-btn <?= $tab === 'register' ? 'active' : '' ?>" onclick="showTab('register')">Register</button>
      </div>

      <!-- ── LOGIN panel ──────────────────────────────────────────────────── -->
      <div id="panel-login" style="display:<?= $tab === 'login' ? 'block' : 'none' ?>">
        <form method="POST">
          <input type="hidden" name="action" value="login">

          <label class="field-label">Email Address</label>
          <input type="email" name="email" class="field-input"
                 placeholder="email@marketplace.com" required>

          <label class="field-label">Password</label>
          <div class="pw-wrap">
            <input type="password" name="password" id="login-pw" class="field-input"
                   placeholder="••••••••" required>
            <button type="button" class="pw-eye" onclick="togglePw('login-pw', this)" tabindex="-1">
              <svg class="eye-icon eye-off" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>
              <svg class="eye-icon eye-on" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" style="display:none"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
            </button>
          </div>

          <button type="button" class="forgot-link"
                  onclick="window.location='forgot_password.php'">Forgot password?</button>

          <button type="submit" class="submit-btn">Login</button>
        </form>
      </div>

      <!-- ── REGISTER panel ────────────────────────────────────────────────── -->
      <div id="panel-register" style="display:<?= $tab === 'register' ? 'block' : 'none' ?>">
        <form method="POST">
          <input type="hidden" name="action" value="register">
          <!-- Role is set via JS when the tile is clicked -->
          <input type="hidden" name="role" id="reg-role" value="<?= $sellerMode ? 'seller' : 'customer' ?>">

          <span class="iwantto-lbl">I Want To</span>
          <div class="role-row">
            <div class="role-tile <?= !$sellerMode ? 'active' : '' ?>" id="tile-customer"
                 onclick="setRole('customer')">
              <span class="role-tile-icon">🛒</span>
              <span class="role-tile-name">Buy</span>
            </div>
            <div class="role-tile <?= $sellerMode ? 'active' : '' ?>" id="tile-seller"
                 onclick="setRole('seller')">
              <span class="role-tile-icon">🏪</span>
              <span class="role-tile-name">Sell</span>
            </div>
          </div>

          <label class="field-label">Full Name</label>
          <input type="text" name="full_name" class="field-input" placeholder="Full Name" required>

          <!-- Store name – shown only when "Sell" is selected -->
          <div id="store-group" style="display:<?= $sellerMode ? 'block' : 'none' ?>">
            <label class="field-label">Store Name</label>
            <input type="text" name="store_name" class="field-input" placeholder="e.g. TechZone PH">
          </div>

          <label class="field-label">Email Address</label>
          <input type="email" name="email" class="field-input"
                 placeholder="email@marketplace.com" required>

          <label class="field-label">Password</label>
          <div class="pw-wrap">
            <input type="password" name="password" id="reg-pw" class="field-input"
                   placeholder="••••••••" required>
            <button type="button" class="pw-eye" onclick="togglePw('reg-pw', this)" tabindex="-1">
              <svg class="eye-icon eye-off" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>
              <svg class="eye-icon eye-on" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" style="display:none"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
            </button>
          </div>

          <button type="submit" class="submit-btn">Create Account</button>
        </form>
      </div>

    <?php else: ?>
      <!-- ── FORGOT PASSWORD panel ─────────────────────────────────────────── -->
      <button class="back-btn" onclick="window.location='login.php'">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none"
             stroke="currentColor" stroke-width="2.5">
          <path d="M19 12H5M12 5l-7 7 7 7"/>
        </svg>
        Back to Sign In
      </button>

      <?php if ($success && $tab === 'login'): ?>
        <!-- password reset done – this branch won't show in forgot panel -->
      <?php elseif ($success): ?>
        <!-- OTP sent confirmation -->
        <div class="forgot-icon">📬</div>
        <div class="forgot-title">Check Your Email</div>
        <p class="forgot-desc"><?= $success ?></p>

        <!-- Step 2: enter OTP + new password -->
        <form method="POST">
          <input type="hidden" name="action" value="reset_password">
          <input type="hidden" name="email" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
          <label class="field-label">Reset Code (6 digits)</label>
          <input type="text" name="otp" class="field-input" placeholder="123456"
                 maxlength="6" pattern="\d{6}" autocomplete="one-time-code" autofocus required>
          <label class="field-label">New Password</label>
          <input type="password" name="new_password" class="field-input"
                 placeholder="••••••••" minlength="6" required>
          <button type="submit" class="submit-btn">Reset Password</button>
        </form>

      <?php elseif ($forgotStep === 'reset'): ?>
        <!-- Back here after failed OTP verify -->
        <div class="forgot-icon">🔑</div>
        <div class="forgot-title">Enter Reset Code</div>
        <form method="POST">
          <input type="hidden" name="action" value="reset_password">
          <label class="field-label">Email Address</label>
          <input type="email" name="email" class="field-input"
                 value="<?= htmlspecialchars($forgotEmail) ?>" required>
          <label class="field-label">Reset Code (6 digits)</label>
          <input type="text" name="otp" class="field-input" placeholder="123456"
                 maxlength="6" pattern="\d{6}" required>
          <label class="field-label">New Password</label>
          <input type="password" name="new_password" class="field-input"
                 placeholder="••••••••" minlength="6" required>
          <button type="submit" class="submit-btn">Reset Password</button>
        </form>

      <?php else: ?>
        <div class="forgot-icon">🔑</div>
        <div class="forgot-title">Forgot Password?</div>
        <p class="forgot-desc">Enter your account email and we'll send you a 6-digit reset code.</p>

        <form method="POST">
          <input type="hidden" name="action" value="forgot">
          <label class="field-label">Email Address</label>
          <input type="email" name="email" class="field-input"
                 placeholder="you@marketplace.com" required>
          <button type="submit" class="submit-btn">Send Reset Code</button>
        </form>
      <?php endif; ?>
    <?php endif; ?>

  </div>
</div>

<script>
  // ── Password eye toggle ──────────────────────────────────────────────────────
  function togglePw(id, btn) {
    const inp = document.getElementById(id);
    const isHidden = inp.type === 'password';
    inp.type = isHidden ? 'text' : 'password';
    btn.querySelector('.eye-off').style.display = isHidden ? 'none'  : '';
    btn.querySelector('.eye-on').style.display  = isHidden ? ''      : 'none';
    btn.style.color = isHidden ? '#e01010' : '#bbb';
  }

  // ── Tab switcher ─────────────────────────────────────────────────────────────
  function showTab(t) {
    document.getElementById('panel-login').style.display    = t === 'login'    ? 'block' : 'none';
    document.getElementById('panel-register').style.display = t === 'register' ? 'block' : 'none';
    document.querySelectorAll('.tab-btn').forEach((b, i) => {
      b.classList.toggle('active', (i === 0 && t === 'login') || (i === 1 && t === 'register'));
    });
  }

  // ── Role tile switcher ───────────────────────────────────────────────────────
  function setRole(r) {
    document.getElementById('reg-role').value = r;
    document.getElementById('tile-customer').classList.toggle('active', r === 'customer');
    document.getElementById('tile-seller').classList.toggle('active', r === 'seller');
    document.getElementById('store-group').style.display = r === 'seller' ? 'block' : 'none';
  }

  // ── Auto-open register tab from URL ─────────────────────────────────────────
  (function () {
    if (new URLSearchParams(location.search).get('tab') === 'register') showTab('register');
  })();

  // ── SweetAlert2 theme matching MARKETPLACE. ──────────────────────────────────
  const Toast = Swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: 4000,
    timerProgressBar: true,
    didOpen: (toast) => {
      toast.addEventListener('mouseenter', Swal.stopTimer);
      toast.addEventListener('mouseleave', Swal.resumeTimer);
    }
  });

  // ── Fire alerts from PHP state ───────────────────────────────────────────────
  <?php
  $jsError   = addslashes(strip_tags($error));
  $jsSuccess = addslashes(strip_tags($success));
  ?>

  <?php if ($error && $tab === 'login'): ?>
  Swal.fire({
    icon: 'error',
    title: 'Login Failed',
    text: '<?= $jsError ?>',
    confirmButtonColor: '#e01010',
    confirmButtonText: 'Try Again',
    customClass: { popup: 'swal-marketplace' }
  });
  <?php elseif ($error && $tab === 'register'): ?>
  Swal.fire({
    icon: 'error',
    title: 'Registration Failed',
    text: '<?= $jsError ?>',
    confirmButtonColor: '#e01010',
    confirmButtonText: 'Fix & Retry',
    customClass: { popup: 'swal-marketplace' }
  }).then(() => showTab('register'));
  <?php elseif ($error && $tab === 'forgot'): ?>
  Swal.fire({
    icon: 'error',
    title: 'Error',
    text: '<?= $jsError ?>',
    confirmButtonColor: '#e01010',
    customClass: { popup: 'swal-marketplace' }
  });
  <?php endif; ?>

  <?php if ($success && $tab === 'login' && str_contains($success, 'reset')): ?>
  Swal.fire({
    icon: 'success',
    title: 'Password Reset!',
    text: 'Your password has been updated. You can now sign in.',
    confirmButtonColor: '#e01010',
    confirmButtonText: 'Sign In',
    customClass: { popup: 'swal-marketplace' }
  });
  <?php elseif ($success && $tab === 'login'): ?>
  Swal.fire({
    icon: 'success',
    title: 'Account Created!',
    html: 'A verification link has been sent to your email.<br><small style="color:#888;">Please check your inbox and verify before logging in.</small>',
    confirmButtonColor: '#e01010',
    confirmButtonText: 'Got it!',
    customClass: { popup: 'swal-marketplace' }
  });
  <?php elseif ($success && $tab === 'forgot'): ?>
  Toast.fire({
    icon: 'info',
    title: 'Reset code sent to your email!'
  });
  <?php endif; ?>
</script>

<style>
  .swal-marketplace { font-family: 'Outfit', sans-serif !important; border-radius: 10px !important; }
  .swal-marketplace .swal2-title { font-weight: 900 !important; letter-spacing: -0.3px !important; color: #111 !important; }
  .swal-marketplace .swal2-html-container,
  .swal-marketplace .swal2-content { font-size: 14px !important; color: #555 !important; }
  .swal-marketplace .swal2-icon.swal2-error { border-color: #e01010 !important; color: #e01010 !important; }
  .swal-marketplace .swal2-icon.swal2-success { border-color: #28a745 !important; }
  .swal-marketplace .swal2-icon.swal2-success [class^=swal2-success-line] { background: #28a745 !important; }
  .swal-marketplace .swal2-icon.swal2-success .swal2-success-ring { border-color: rgba(40,167,69,.3) !important; }
</style>
<?php include 'includes/toast.php'; ?>
</body>
</html>
