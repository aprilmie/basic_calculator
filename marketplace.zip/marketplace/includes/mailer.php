<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once __DIR__ . '/../vendor/autoload.php';

define('MAIL_USERNAME', 'nekoybanez133@gmail.com');
define('MAIL_PASSWORD', 'lnmfoqawwpbxdveu');
define('MAIL_FROM_ADDR', 'nekoybanez133@gmail.com');
define('MAIL_FROM_LABEL', 'MARKETPLACE.');

// ── Base URL helper ───────────────────────────────────────────────────────────
function _mailerBaseUrl(): string {
    return defined('SITE_URL') ? SITE_URL : 'http://localhost/marketplace';
}

// ── Shared SMTP factory ───────────────────────────────────────────────────────
function _buildMailer(): PHPMailer {
    $mail = new PHPMailer(true);
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = MAIL_USERNAME;
    $mail->Password   = MAIL_PASSWORD;
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = 587;
    $mail->setFrom(MAIL_FROM_ADDR, MAIL_FROM_LABEL);
    return $mail;
}

/**
 * Send an email-verification link to a newly registered user.
 *
 * @param string $email     Recipient email
 * @param string $name      Recipient display name
 * @param string $token     verify_token stored in the users table
 * @return array            ['ok' => bool, 'error' => string|null]
 */
function sendVerificationEmail(string $email, string $name, string $token): array {
    $link = _mailerBaseUrl() . '/verify.php?token=' . urlencode($token);

    try {
        $mail = _buildMailer();
        $mail->addAddress($email, $name);
        $mail->isHTML(true);
        $mail->Subject = 'Verify Your MARKETPLACE. Account';
        $mail->Body = "
            <div style='font-family:Arial,sans-serif;max-width:520px;margin:auto;'>
                <h2 style='color:#e01010;letter-spacing:-0.5px;'>MARKETPLACE.</h2>
                <p>Hi <strong>" . htmlspecialchars($name) . "</strong>,</p>
                <p>Thanks for registering! Click the button below to verify your email address and activate your account.</p>
                <p style='text-align:center;margin:32px 0;'>
                    <a href='" . $link . "' style='
                        background:#e01010;
                        color:#ffffff;
                        padding:13px 32px;
                        text-decoration:none;
                        border-radius:6px;
                        font-weight:bold;
                        font-size:15px;
                        font-family:Arial,sans-serif;
                    '>Verify My Account</a>
                </p>
                <p style='font-size:13px;color:#777;'>Or copy and paste this link into your browser:<br>
                    <a href='" . $link . "' style='color:#e01010;'>" . $link . "</a>
                </p>
                <hr style='border:none;border-top:1px solid #eee;margin:24px 0;'>
                <small style='color:#aaa;'>If you did not create an account on MARKETPLACE., you can safely ignore this email.</small>
            </div>
        ";
        $mail->AltBody = "Hi $name,\n\nVerify your MARKETPLACE. account by visiting:\n$link\n\nIf you did not register, ignore this email.";
        $mail->send();
        return ['ok' => true, 'error' => null];
    } catch (Exception $e) {
        return ['ok' => false, 'error' => $mail->ErrorInfo ?? $e->getMessage()];
    }
}

/**
 * Send a password-reset OTP email.
 *
 * @param string $email  Recipient email
 * @param string $name   Recipient display name
 * @param string $otp         6-digit OTP
 * @param string $reset_link  Optional magic link to skip OTP entry (token-based)
 * @return array              ['ok' => bool, 'otp' => string, 'error' => string|null]
 */
function sendOtpEmail(string $email, string $name, string $otp, string $reset_link = ''): array {
    $link_block = $reset_link ? "
                <hr style='border:none;border-top:1px solid #eee;margin:28px 0 20px;'>
                <p style='font-size:13px;color:#555;margin:0 0 10px;'>
                    <strong>Closed the tab or code expired?</strong><br>
                    Use the button below to go directly to the password reset page — no code needed.
                    This link is valid for <strong>15 minutes</strong>.
                </p>
                <p style='text-align:center;margin:18px 0;'>
                    <a href='" . htmlspecialchars($reset_link) . "' style='
                        background:#111;
                        color:#ffffff;
                        padding:11px 26px;
                        text-decoration:none;
                        border-radius:6px;
                        font-weight:bold;
                        font-size:14px;
                    '>🔗 Open Reset Page Directly</a>
                </p>
                <p style='font-size:12px;color:#aaa;text-align:center;'>
                    Or copy this link:<br>
                    <a href='" . htmlspecialchars($reset_link) . "' style='color:#e01010;word-break:break-all;'>" . htmlspecialchars($reset_link) . "</a>
                </p>" : "";

    try {
        $mail = _buildMailer();
        $mail->addAddress($email, $name);
        $mail->isHTML(true);
        $mail->Subject = 'Your Password Reset Code — MARKETPLACE.';
        $mail->Body = "
            <div style='font-family:Arial,sans-serif;max-width:520px;margin:auto;'>
                <h2 style='color:#e01010;letter-spacing:-0.5px;'>MARKETPLACE.</h2>
                <p>Hi <strong>" . htmlspecialchars($name) . "</strong>,</p>
                <p>You requested a password reset. Use the code below — it expires in <strong>10 minutes</strong>.</p>
                <div style='text-align:center;margin:30px 0;'>
                    <span style='
                        display:inline-block;
                        background:#f5f5f5;
                        border:2px dashed #e01010;
                        border-radius:10px;
                        padding:16px 36px;
                        font-size:2rem;
                        font-weight:800;
                        letter-spacing:10px;
                        color:#111;
                        font-family:monospace;
                    '>" . htmlspecialchars($otp) . "</span>
                </div>
                <p style='font-size:13px;color:#777;'>If you did not request a password reset, you can safely ignore this email.</p>
                $link_block
                <hr style='border:none;border-top:1px solid #eee;margin:24px 0;'>
                <small style='color:#aaa;'>This code is valid for 10 minutes and can only be used once.</small>
            </div>
        ";
        $mail->AltBody = "Hi $name,\n\nYour MARKETPLACE. password reset code is: $otp\n\nIt expires in 10 minutes.\n\n"
            . ($reset_link ? "Closed the tab or code expired? Use this direct link (valid 15 min):\n$reset_link\n\n" : "")
            . "If you did not request this, ignore this email.";
        $mail->send();
        return ['ok' => true, 'otp' => $otp, 'error' => null];
    } catch (Exception $e) {
        return ['ok' => false, 'otp' => $otp, 'error' => $mail->ErrorInfo ?? $e->getMessage()];
    }
}
?>
