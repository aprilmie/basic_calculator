<?php
// ── Seller sidebar navigation ────────────────────────────────────────────────
$current = basename($_SERVER['PHP_SELF'], '.php');

$links = [
    'dashboard'     => 'Overview',
    'orders'        => 'Orders',
    'notifications' => 'Notifications',
    'profile'       => 'My Profile',
    'products'      => 'My Products',
];
?>
<aside class="dash-sidebar">
  <div class="dash-sidebar-title">SELLER PANEL</div>
  <nav class="dash-sidebar-nav">
    <?php foreach ($links as $page => $label): ?>
      <a href="<?= BASE_URL ?>/pages/seller/<?= $page ?>.php"
         class="dash-sidebar-link <?= $current === $page ? 'active' : '' ?>">
        <?= $label ?>
      </a>
    <?php endforeach; ?>
  </nav>
</aside>
