<?php
// ── Admin sidebar navigation ─────────────────────────────────────────────────
$current = basename($_SERVER['PHP_SELF'], '.php');

$links = [
    'dashboard' => 'Overview',
    'orders'    => 'Orders',
    'users'     => 'Users',
    'products'  => 'Products',
    'about'     => 'About',
    'profile'   => 'My Profile',
];
?>
<aside class="dash-sidebar">
  <div class="dash-sidebar-title">ADMIN PANEL</div>
  <nav class="dash-sidebar-nav">
    <?php foreach ($links as $page => $label): ?>
      <a href="<?= BASE_URL ?>/pages/admin/<?= $page ?>.php"
         class="dash-sidebar-link <?= $current === $page ? 'active' : '' ?>">
        <?= $label ?>
      </a>
    <?php endforeach; ?>
  </nav>
</aside>
