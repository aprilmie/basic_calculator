<?php
// ── Customer sidebar navigation ─────────────────────────────────────────────
$current = basename($_SERVER['PHP_SELF'], '.php');

$links = [
    'dashboard'     => 'Overview',
    'orders'        => 'My Orders',
    'notifications' => 'Notifications',
    'profile'       => 'My Profile',
    'browse'        => 'Browse',
];
?>
<aside class="dash-sidebar">
  <div class="dash-sidebar-title">MY ACCOUNT</div>
  <nav class="dash-sidebar-nav">
    <?php foreach ($links as $page => $label): ?>
      <a href="<?= BASE_URL ?>/pages/customer/<?= $page ?>.php"
         class="dash-sidebar-link <?= $current === $page ? 'active' : '' ?>">
        <?= $label ?>
      </a>
    <?php endforeach; ?>
  </nav>
</aside>
