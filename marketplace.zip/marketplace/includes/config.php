<?php
// ============================================================
//  DATABASE CREDENTIALS
//  Edit these to match your local setup.
// ============================================================
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'marketplace_db');

define('SITE_NAME', 'MARKETPLACE.');
define('SITE_URL',  'http://localhost/marketplace');


// ============================================================
//  BASE URL  (auto-detected – works in a subfolder or at root)
// ============================================================
$_depth = substr_count(
    str_replace(realpath(__DIR__ . '/../'), '', realpath($_SERVER['SCRIPT_FILENAME'])),
    DIRECTORY_SEPARATOR
) - 1;
$_base = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/');
for ($i = 0; $i < $_depth; $i++) {
    $_base = dirname($_base);
}
define('BASE_URL', rtrim($_base, '/'));


// ============================================================
//  DATABASE CONNECTION  (singleton – one connection per request)
// ============================================================
function getDB(): PDO
{
    static $pdo = null;

    if ($pdo === null) {
        try {
            $pdo = new PDO(
                'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8',
                DB_USER,
                DB_PASS
            );
            $pdo->setAttribute(PDO::ATTR_ERRMODE,            PDO::ERRMODE_EXCEPTION);
            $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            die(
                "<div style='font-family:sans-serif;padding:40px;color:#c00'>"
                . "<h2>Database Connection Failed</h2>"
                . "<p>" . $e->getMessage() . "</p>"
                . "<p>Please import <strong>marketplace_db.sql</strong> and update "
                . "<strong>includes/config.php</strong>.</p></div>"
            );
        }
    }

    return $pdo;
}


// ============================================================
//  SESSION / AUTH HELPERS
// ============================================================

/** Returns true if a user is currently logged in. */
function isLoggedIn(): bool
{
    return isset($_SESSION['user_id']);
}

/** Redirects to login if the user is not logged in. */
function requireLogin(): void
{
    if (!isLoggedIn()) {
        header('Location: ' . BASE_URL . '/login.php');
        exit;
    }
}

/**
 * Ensures the logged-in user has the given role.
 * Admins are allowed through any role check.
 */
function requireRole(string $role): void
{
    requireLogin();
    if ($_SESSION['role'] !== $role && $_SESSION['role'] !== 'admin') {
        header('Location: ' . BASE_URL . '/login.php?error=unauthorized');
        exit;
    }
}

/** Fetches the full user row for the currently logged-in user. */
function currentUser(): ?array
{
    if (!isLoggedIn()) return null;

    $stmt = getDB()->prepare('SELECT * FROM users WHERE id = ?');
    $stmt->execute([$_SESSION['user_id']]);
    return $stmt->fetch() ?: null;
}


// ============================================================
//  REDIRECT HELPER
// ============================================================

/**
 * Redirects the browser and stops execution.
 * Paths starting with "/" are automatically prefixed with BASE_URL.
 */
function redirect(string $url): void
{
    $target = (str_starts_with($url, '/')) ? BASE_URL . $url : $url;
    header('Location: ' . $target);
    exit;
}


// ============================================================
//  OUTPUT / FORMAT HELPERS
// ============================================================

/** Strips tags and encodes HTML special chars – safe for echoing user input. */
function sanitize(string $val): string
{
    return htmlspecialchars(strip_tags(trim($val)));
}

/** Formats a number as Philippine Peso. e.g. ₱1,234.56 */
function formatPrice(float $amount): string
{
    return '₱' . number_format($amount, 2);
}

/** Returns up to 2 uppercase initials from a full name. e.g. "Juan dela Cruz" → "JD" */
function getInitials(string $name): string
{
    $initials = '';
    foreach (explode(' ', trim($name)) as $part) {
        $initials .= strtoupper($part[0]);
    }
    return substr($initials, 0, 2);
}


// ============================================================
//  NOTIFICATION & CART COUNTERS  (used in the nav bar)
// ============================================================

/** Returns the number of unread notifications for a user. */
function unreadNotifCount(int $userId): int
{
    $stmt = getDB()->prepare('SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0');
    $stmt->execute([$userId]);
    return (int) $stmt->fetchColumn();
}

/**
 * Queue a toast notification to show on the next page load.
 * type: 'success' | 'error' | 'info' | 'warning'
 */
function setToast(string $type, string $msg): void
{
    if (session_status() === PHP_SESSION_NONE) session_start();
    $_SESSION['_toast'] = ['type' => $type, 'msg' => $msg];
}

/** Returns the total number of items in a user's cart. */
function cartCount(int $userId): int
{
    $stmt = getDB()->prepare('SELECT COALESCE(SUM(quantity), 0) FROM cart WHERE user_id = ?');
    $stmt->execute([$userId]);
    return (int) $stmt->fetchColumn();
}

// ============================================================
//  EMAIL VERIFICATION – column migration
//  Adds verify_token & verify_status to users if missing.
// ============================================================
function ensureVerifyColumns(): void
{
    $db = getDB();
    $cols = array_column(
        $db->query("SHOW COLUMNS FROM users")->fetchAll(), 'Field'
    );
    if (!in_array('verify_token', $cols)) {
        $db->exec("ALTER TABLE users ADD COLUMN verify_token VARCHAR(64) DEFAULT NULL");
    }
    if (!in_array('verify_status', $cols)) {
        $db->exec("ALTER TABLE users ADD COLUMN verify_status TINYINT(1) NOT NULL DEFAULT 0");
        $db->exec("UPDATE users SET verify_status = 1 WHERE verify_token IS NULL");
    }
    if (!in_array('is_super_user', $cols)) {
        $db->exec("ALTER TABLE users ADD COLUMN is_super_user TINYINT(1) NOT NULL DEFAULT 0");
        // Mark the earliest admin as Super User
        $db->exec("UPDATE users SET is_super_user = 1 WHERE role = 'admin' ORDER BY id ASC LIMIT 1");
    }
    // Ensure Super Admin always has locked avatar
    $db->exec("UPDATE users SET avatar = 'uploads/avatars/super_admin_avatar.jpg' WHERE is_super_user = 1");
}
ensureVerifyColumns();

// ============================================================
//  ABOUT INFO TABLE – create & seed if missing
// ============================================================
function ensureAboutTable(): void
{
    $db = getDB();
    $db->exec("CREATE TABLE IF NOT EXISTS about_info (
        id INT AUTO_INCREMENT PRIMARY KEY,
        dev_name     VARCHAR(100) NOT NULL DEFAULT '',
        dev_role     VARCHAR(100) NOT NULL DEFAULT '',
        dev_email    VARCHAR(100) NOT NULL DEFAULT '',
        dev_phone    VARCHAR(50)  NOT NULL DEFAULT '',
        dev_github   VARCHAR(200) NOT NULL DEFAULT '',
        dev_facebook VARCHAR(200) NOT NULL DEFAULT '',
        dev_bio      TEXT,
        site_name    VARCHAR(150) NOT NULL DEFAULT '',
        system_version VARCHAR(20) NOT NULL DEFAULT '1.0.0',
        dev_photo    VARCHAR(255) DEFAULT NULL,
        updated_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )");
    $count = (int) $db->query("SELECT COUNT(*) FROM about_info")->fetchColumn();
    if ($count === 0) {
        $db->exec("INSERT INTO about_info (dev_name, dev_role, dev_email, site_name, system_version, dev_bio)
            VALUES ('Developer Name', 'Full-Stack Developer', 'developer@email.com', 'MARKETPLACE.', '1.0.0', 'Write something about yourself here.')");
    }
}
ensureAboutTable();
