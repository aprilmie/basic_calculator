<?php
// ── Shared <head> partial ────────────────────────────────────────────────────
// Usage:  $pageTitle = 'Page Name'; include '../../includes/head.php';
// $pageTitle must be set before including this file.
$pageTitle = isset($pageTitle) ? sanitize($pageTitle) . ' — ' . SITE_NAME : SITE_NAME;
?>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= $pageTitle ?></title>
<link rel="stylesheet" href="<?= BASE_URL ?>/css/style.css">
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Outfit:wght@300;400;500;600;700;900&display=swap"
      rel="stylesheet">
