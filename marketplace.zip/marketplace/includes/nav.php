<?php
// ── Shared top navigation bar (included on every page) ──────────────────────
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/config.php';

$user    = currentUser();
$cartCnt = $user ? cartCount($user['id']) : 0;
?>
<nav class="dash-nav">

  <!-- Brand / Logo -->
  <a href="<?= BASE_URL ?>/<?= $user ? 'pages/' . $user['role'] . '/dashboard.php' : 'index.php' ?>"
     class="dash-nav-brand">
    MARKETPLACE<span>.</span>
  </a>

  <div class="dash-nav-right">
    <?php if ($user): ?>

      <!-- Cart icon (customers only) -->
      <?php if ($user['role'] === 'customer'): ?>
        <a href="<?= BASE_URL ?>/pages/customer/cart.php" class="dash-cart-btn" title="Cart">
          <svg width="22" height="22" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
              d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13l-1.4 7h12.8M7 13L5.4 5
                 M10 21a1 1 0 100-2 1 1 0 000 2zm7 0a1 1 0 100-2 1 1 0 000 2z"/>
          </svg>
          <?php if ($cartCnt > 0): ?>
            <span class="dash-cart-count"><?= $cartCnt ?></span>
          <?php endif; ?>
        </a>
      <?php endif; ?>

      <!-- Dashboard link -->
      <a href="<?= BASE_URL ?>/pages/<?= $user['role'] ?>/dashboard.php" class="dash-nav-btn">
        Dashboard
      </a>

      <!-- User avatar + name -->
      <div class="dash-user-badge">
        <div class="dash-avatar">
          <?php if (!empty($user['avatar'])): ?>
            <img src="<?= BASE_URL . '/' . sanitize($user['avatar']) ?>" alt=""
                 style="width:100%;height:100%;object-fit:cover;border-radius:50%;">
          <?php else: ?>
            <?= getInitials($user['full_name']) ?>
          <?php endif; ?>
        </div>
        <div class="dash-user-info">
          <div class="dash-user-name"><?= sanitize($user['full_name']) ?></div>
          <div class="dash-user-role"><?= ucfirst($user['role']) ?></div>
        </div>
      </div>

      <!-- About -->
      <a href="<?= BASE_URL ?>/about.php" class="dash-nav-btn">About</a>

      <!-- Sign out -->
      <a href="<?= BASE_URL ?>/logout.php" class="dash-nav-btn">Sign Out</a>

    <?php else: ?>
      <!-- Guest -->
      <a href="<?= BASE_URL ?>/about.php" class="dash-nav-btn">About</a>
      <a href="<?= BASE_URL ?>/login.php" class="dash-nav-btn">GET STARTED</a>
    <?php endif; ?>
  </div>

</nav>
