<?php
// ── Global Toast & Confirm Modal System ─────────────────────────────────────
// Include this ONCE per page, right before </body>.
// PHP usage:   setToast('success', 'Product added.')  then redirect()
// JS usage:    MP.toast('success','Message')
//              MP.confirm('Are you sure?', callback)
// Welcome:     set $_SESSION['welcome_user'] = ['name'=>'...','role'=>'...']

$_toast = null;
if (!empty($_SESSION['_toast'])) {
    $_toast = $_SESSION['_toast'];
    unset($_SESSION['_toast']);
}
$_welcome = null;
if (!empty($_SESSION['welcome_user'])) {
    $_welcome = $_SESSION['welcome_user'];
    unset($_SESSION['welcome_user']);
}
?>
<!-- ═══════════════════════════════════════════════════════════════════════════
     GLOBAL NOTIFICATION UI
     ═══════════════════════════════════════════════════════════════════════════ -->

<!-- Toast container -->
<div id="mp-toast-wrap" aria-live="polite" aria-atomic="true" style="
  position:fixed;top:74px;right:24px;z-index:9999;
  display:flex;flex-direction:column;gap:10px;
  pointer-events:none;
"></div>

<!-- Confirm modal -->
<div id="mp-confirm-overlay" style="
  display:none;position:fixed;inset:0;
  background:rgba(0,0,0,.52);z-index:10000;
  align-items:center;justify-content:center;padding:16px;
" role="dialog" aria-modal="true" aria-labelledby="mp-confirm-title">
  <div style="
    background:#fff;border-radius:12px;
    padding:32px 28px 24px;max-width:400px;width:100%;
    box-shadow:0 24px 64px rgba(0,0,0,.4);
    transform:scale(.96);transition:transform .18s cubic-bezier(.22,1,.36,1);
  " id="mp-confirm-box">
    <div style="display:flex;align-items:flex-start;gap:14px;margin-bottom:22px;">
      <div id="mp-confirm-icon" style="
        width:44px;height:44px;border-radius:50%;flex-shrink:0;
        display:flex;align-items:center;justify-content:center;font-size:20px;
        background:#fff0f0;
      ">⚠️</div>
      <div>
        <div id="mp-confirm-title" style="font-size:16px;font-weight:800;color:#111;margin-bottom:6px;"></div>
        <div id="mp-confirm-msg"   style="font-size:13px;color:#666;line-height:1.6;"></div>
      </div>
    </div>
    <div style="display:flex;gap:10px;justify-content:flex-end;">
      <button id="mp-confirm-cancel" style="
        padding:10px 22px;border:1.5px solid #ddd;border-radius:7px;
        background:#fff;font-size:13px;font-weight:700;cursor:pointer;color:#444;
        transition:background .12s;
      ">Cancel</button>
      <button id="mp-confirm-ok" style="
        padding:10px 22px;border:none;border-radius:7px;
        background:#e01010;color:#fff;font-size:13px;font-weight:800;
        cursor:pointer;letter-spacing:.3px;transition:background .12s;
      ">Confirm</button>
    </div>
  </div>
</div>

<!-- Welcome modal -->
<?php if ($_welcome): ?>
<div id="mp-welcome-overlay" style="
  display:flex;position:fixed;inset:0;
  background:rgba(0,0,0,.62);z-index:10000;
  align-items:center;justify-content:center;padding:16px;
" role="dialog" aria-modal="true">
  <div style="
    background:#111;border-radius:16px;
    padding:40px 36px 32px;max-width:420px;width:100%;text-align:center;
    box-shadow:0 32px 80px rgba(0,0,0,.6);
    animation:wlcIn .45s cubic-bezier(.22,1,.36,1) both;
    position:relative;overflow:hidden;
  ">
    <!-- Red accent top bar -->
    <div style="position:absolute;top:0;left:0;right:0;height:4px;background:#e01010;border-radius:16px 16px 0 0;"></div>

    <!-- Animated avatar ring -->
    <div style="
      width:80px;height:80px;border-radius:50%;
      background:linear-gradient(135deg,#e01010,#800);
      margin:0 auto 18px;
      display:flex;align-items:center;justify-content:center;
      font-size:32px;font-weight:900;color:#fff;
      box-shadow:0 0 0 6px rgba(224,16,16,.18),0 0 0 12px rgba(224,16,16,.08);
    ">
      <?= strtoupper(substr(trim($_welcome['name']), 0, 1)) ?>
    </div>

    <div style="font-size:12px;font-weight:700;letter-spacing:2px;color:#e01010;text-transform:uppercase;margin-bottom:6px;">
      Welcome Back
    </div>
    <div style="font-size:26px;font-weight:900;color:#fff;margin-bottom:6px;line-height:1.2;">
      <?= htmlspecialchars($_welcome['name']) ?>!
    </div>
    <div style="font-size:13px;color:#888;margin-bottom:28px;">
      You're logged in as
      <span style="
        display:inline-block;padding:2px 10px;border-radius:20px;
        font-size:11px;font-weight:700;text-transform:uppercase;margin-left:4px;
        <?= $_welcome['role']==='admin' ? 'background:#e01010;color:#fff;' : ($_welcome['role']==='seller' ? 'background:#3b82f6;color:#fff;' : 'background:#22c55e;color:#fff;') ?>
      "><?= ucfirst($_welcome['role']) ?></span>
    </div>

    <button onclick="document.getElementById('mp-welcome-overlay').style.display='none'" style="
      width:100%;padding:13px;border:none;border-radius:8px;
      background:#e01010;color:#fff;font-size:14px;font-weight:800;
      letter-spacing:1px;cursor:pointer;transition:background .15s;
    " onmouseover="this.style.background='#c00'" onmouseout="this.style.background='#e01010'">
      Let's Go →
    </button>
  </div>
</div>
<style>
@keyframes wlcIn {
  from { opacity:0; transform:scale(.88) translateY(24px); }
  to   { opacity:1; transform:scale(1)  translateY(0); }
}
</style>
<?php endif; ?>

<!-- PHP-triggered toast (fires on page load) -->
<?php if ($_toast): ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
  MP.toast(<?= json_encode($_toast['type']) ?>, <?= json_encode($_toast['msg']) ?>);
});
</script>
<?php endif; ?>

<style>
/* ── Toast styles ── */
.mp-toast {
  pointer-events:auto;
  display:flex;align-items:flex-start;gap:12px;
  padding:14px 16px;border-radius:10px;
  min-width:260px;max-width:360px;
  box-shadow:0 8px 32px rgba(0,0,0,.18);
  font-family:'Outfit','Inter',sans-serif;
  font-size:14px;font-weight:500;
  animation:toastIn .28s cubic-bezier(.22,1,.36,1) both;
  position:relative;overflow:hidden;cursor:default;
}
.mp-toast.hiding { animation:toastOut .22s ease forwards; }
.mp-toast-icon   { font-size:18px;flex-shrink:0;margin-top:1px; }
.mp-toast-body   { flex:1; }
.mp-toast-title  { font-size:13px;font-weight:800;margin-bottom:2px; }
.mp-toast-msg    { font-size:13px;line-height:1.4;opacity:.85; }
.mp-toast-close  {
  background:none;border:none;font-size:15px;line-height:1;
  cursor:pointer;opacity:.45;flex-shrink:0;padding:2px;margin-top:1px;
}
.mp-toast-close:hover { opacity:1; }
/* Progress bar */
.mp-toast-bar {
  position:absolute;bottom:0;left:0;height:3px;
  animation:toastBar var(--dur,4s) linear forwards;
}
/* Types */
.mp-toast-success { background:#f0fdf4;border:1px solid #bbf7d0;color:#166534; }
.mp-toast-success .mp-toast-bar { background:#22c55e; }
.mp-toast-error   { background:#fef2f2;border:1px solid #fecaca;color:#991b1b; }
.mp-toast-error   .mp-toast-bar { background:#e01010; }
.mp-toast-info    { background:#eff6ff;border:1px solid #bfdbfe;color:#1e40af; }
.mp-toast-info    .mp-toast-bar { background:#3b82f6; }
.mp-toast-warning { background:#fffbeb;border:1px solid #fde68a;color:#92400e; }
.mp-toast-warning .mp-toast-bar { background:#eab308; }

@keyframes toastIn  { from{opacity:0;transform:translateX(40px)} to{opacity:1;transform:translateX(0)} }
@keyframes toastOut { from{opacity:1;transform:translateX(0)}     to{opacity:0;transform:translateX(40px)} }
@keyframes toastBar { from{width:100%} to{width:0} }
</style>

<script>
(function(){
  var ICONS = { success:'✅', error:'❌', info:'ℹ️', warning:'⚠️' };
  var DUR   = 4000;
  var wrap  = document.getElementById('mp-toast-wrap');

  /* ── Toast ── */
  function toast(type, msg, title) {
    type = type || 'info';
    var t = document.createElement('div');
    t.className = 'mp-toast mp-toast-' + type;
    t.style.setProperty('--dur', (DUR/1000)+'s');
    t.innerHTML =
      '<span class="mp-toast-icon">' + (ICONS[type]||'🔔') + '</span>' +
      '<div class="mp-toast-body">' +
        (title ? '<div class="mp-toast-title">'+esc(title)+'</div>' : '') +
        '<div class="mp-toast-msg">'+esc(msg)+'</div>' +
      '</div>' +
      '<button class="mp-toast-close" aria-label="Close">&#x2715;</button>' +
      '<div class="mp-toast-bar"></div>';
    wrap.appendChild(t);

    function dismiss() {
      t.classList.add('hiding');
      setTimeout(function(){ t.parentNode && t.parentNode.removeChild(t); }, 240);
    }
    t.querySelector('.mp-toast-close').addEventListener('click', dismiss);
    setTimeout(dismiss, DUR);
  }

  /* ── Confirm ── */
  var overlay   = document.getElementById('mp-confirm-overlay');
  var box       = document.getElementById('mp-confirm-box');
  var titleEl   = document.getElementById('mp-confirm-title');
  var msgEl     = document.getElementById('mp-confirm-msg');
  var okBtn     = document.getElementById('mp-confirm-ok');
  var cancelBtn = document.getElementById('mp-confirm-cancel');
  var _cb       = null;

  function confirm(msg, cb, opts) {
    opts = opts || {};
    titleEl.textContent = opts.title   || 'Are you sure?';
    msgEl.textContent   = msg          || '';
    okBtn.textContent   = opts.ok      || 'Confirm';
    okBtn.style.background = opts.danger === false ? '#3b82f6' : '#e01010';
    cancelBtn.textContent  = opts.cancel || 'Cancel';
    _cb = cb;
    overlay.style.display = 'flex';
    setTimeout(function(){ box.style.transform = 'scale(1)'; }, 10);
  }

  function closeConfirm() {
    overlay.style.display = 'none';
    box.style.transform = 'scale(.96)';
    _cb = null;
  }

  okBtn.addEventListener('click', function(){
    if (_cb) _cb();
    closeConfirm();
  });
  cancelBtn.addEventListener('click', closeConfirm);
  overlay.addEventListener('click', function(e){ if(e.target===overlay) closeConfirm(); });
  document.addEventListener('keydown', function(e){
    if(e.key==='Escape' && overlay.style.display==='flex') closeConfirm();
  });

  /* ── Helper ── */
  function esc(s) {
    return String(s)
      .replace(/&/g,'&amp;').replace(/</g,'&lt;')
      .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }

  /* ── Intercept data-confirm forms ── */
  document.addEventListener('submit', function(e){
    var form = e.target;
    var msg  = form.dataset.confirm;
    if (!msg) return;
    e.preventDefault();
    MP.confirm(msg, function(){ form.dataset.confirm=''; form.submit(); }, {
      title: form.dataset.confirmTitle || 'Confirm Action',
      ok:    form.dataset.confirmOk    || 'Yes, Proceed',
    });
  }, true);

  /* ── Intercept data-mp-confirm buttons ── */
  document.addEventListener('click', function(e){
    var btn = e.target.closest('[data-mp-confirm]');
    if (!btn) return;
    var msg  = btn.dataset.mpConfirm;
    var form = btn.closest('form');
    if (!msg || !form) return;
    e.preventDefault();
    MP.confirm(msg, function(){
      btn.removeAttribute('data-mp-confirm');
      btn.click();
    }, { title: 'Confirm Action', ok: 'Yes, Proceed' });
  }, true);

  /* ── Expose globally ── */
  window.MP = { toast: toast, confirm: confirm };
})();
</script>
