<?php
// ── About / Developer Info — MARKETPLACE. ────────────────────────────────────
session_start();
require_once 'includes/config.php';

$db    = getDB();
$about = $db->query("SELECT * FROM about_info WHERE id = 1")->fetch();
if (!$about) {
    $about = [
        'dev_name'       => 'Developer',
        'dev_role'       => 'Full-Stack Developer',
        'dev_email'      => '',
        'dev_phone'      => '',
        'dev_github'     => '',
        'dev_facebook'   => '',
        'dev_bio'        => '',
        'site_name'      => 'MARKETPLACE.',
        'system_version' => '1.0.0',
        'dev_photo'      => null,
        'updated_at'     => null,
    ];
}

$photo_src = !empty($about['dev_photo'])
    ? 'uploads/' . htmlspecialchars($about['dev_photo'])
    : 'https://ui-avatars.com/api/?name=' . urlencode($about['dev_name']) . '&background=111111&color=fff&size=200&bold=true&format=png';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php $pageTitle = 'About'; include 'includes/head.php'; ?>
</head>
<body>
<?php include 'includes/nav.php'; ?>

<style>
.dev-page {
    max-width: 520px;
    margin: 52px auto 80px;
    padding: 0 16px;
}

/* Card */
.dev-card {
    background: #fff;
    border-radius: 20px;
    box-shadow: 0 8px 40px rgba(0,0,0,.10);
    overflow: hidden;
}

/* Top banner */
.dev-card-banner {
    background: linear-gradient(135deg, #111 0%, #2a2a2a 60%, #1a1a1a 100%);
    height: 90px;
    position: relative;
}

/* Avatar */
.dev-avatar-wrap {
    position: absolute;
    bottom: -52px;
    left: 50%;
    transform: translateX(-50%);
}
.dev-avatar {
    width: 104px;
    height: 104px;
    border-radius: 50%;
    object-fit: cover;
    border: 4px solid #fff;
    box-shadow: 0 4px 18px rgba(0,0,0,.18);
    display: block;
}

/* Body */
.dev-card-body {
    padding: 64px 36px 36px;
    text-align: center;
}
.dev-name {
    font-size: 1.55rem;
    font-weight: 800;
    color: #111;
    margin: 0 0 5px;
    font-family: 'Outfit', sans-serif;
}
.dev-role {
    font-size: .9rem;
    font-weight: 700;
    color: #e01010;
    margin: 0 0 6px;
}
.dev-site {
    font-size: .8rem;
    color: #aaa;
    margin: 0 0 18px;
    font-family: 'Bebas Neue', sans-serif;
    letter-spacing: 1px;
}
.dev-divider {
    height: 1.5px;
    background: #f4f4f4;
    margin: 0 0 20px;
}
.dev-bio {
    font-size: .9rem;
    color: #666;
    line-height: 1.7;
    margin: 0 0 22px;
}

/* Contact rows */
.dev-contacts {
    display: flex;
    flex-direction: column;
    gap: 10px;
    margin-bottom: 24px;
}
.dev-contact-row {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 9px;
    font-size: .86rem;
    color: #555;
}
.dev-contact-row a {
    color: #111;
    text-decoration: none;
    font-weight: 600;
}
.dev-contact-row a:hover { color: #e01010; }
.dev-contact-icon {
    width: 28px;
    height: 28px;
    border-radius: 50%;
    background: #f4f4f4;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: .85rem;
    flex-shrink: 0;
}

/* Social buttons */
.dev-socials {
    display: flex;
    gap: 10px;
    justify-content: center;
    flex-wrap: wrap;
    margin-bottom: 28px;
}
.dev-social-btn {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 9px 20px;
    border-radius: 9px;
    font-size: .84rem;
    font-weight: 700;
    text-decoration: none;
    transition: transform .15s, box-shadow .15s;
}
.dev-social-btn:hover { transform: translateY(-2px); box-shadow: 0 5px 14px rgba(0,0,0,.13); }
.dsb-gh   { background: #24292e; color: #fff; }
.dsb-fb   { background: #1877f2; color: #fff; }
.dsb-mail { background: #e01010; color: #fff; }

/* System footer strip */
.dev-sys-strip {
    background: #f8f9fa;
    border-top: 1.5px solid #f0f0f0;
    padding: 14px 24px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 8px;
}
.dev-sys-text {
    font-size: .75rem;
    color: #aaa;
    font-weight: 500;
}
.dev-sys-text strong { color: #888; }

/* Admin edit link */
.dev-edit-link {
    text-align: center;
    margin-top: 18px;
}
</style>

<div class="dev-page">
    <div class="dev-card">

        <!-- Banner + avatar -->
        <div class="dev-card-banner">
            <div class="dev-avatar-wrap">
                <img src="<?= $photo_src ?>" class="dev-avatar" alt="<?= htmlspecialchars($about['dev_name']) ?>">
            </div>
        </div>

        <!-- Body -->
        <div class="dev-card-body">

            <div class="dev-name"><?= htmlspecialchars($about['dev_name'] ?: 'Developer') ?></div>

            <?php if ($about['dev_role']): ?>
            <div class="dev-role">💼 <?= htmlspecialchars($about['dev_role']) ?></div>
            <?php endif; ?>

            <?php if ($about['site_name']): ?>
            <div class="dev-site">🛒 <?= htmlspecialchars($about['site_name']) ?></div>
            <?php endif; ?>

            <div class="dev-divider"></div>

            <?php if (!empty($about['dev_bio'])): ?>
            <p class="dev-bio"><?= nl2br(htmlspecialchars($about['dev_bio'])) ?></p>
            <?php endif; ?>

            <!-- Contact info -->
            <?php if ($about['dev_email'] || $about['dev_phone']): ?>
            <div class="dev-contacts">
                <?php if ($about['dev_email']): ?>
                <div class="dev-contact-row">
                    <span class="dev-contact-icon">✉️</span>
                    <a href="mailto:<?= htmlspecialchars($about['dev_email']) ?>"><?= htmlspecialchars($about['dev_email']) ?></a>
                </div>
                <?php endif; ?>
                <?php if ($about['dev_phone']): ?>
                <div class="dev-contact-row">
                    <span class="dev-contact-icon">📱</span>
                    <span><?= htmlspecialchars($about['dev_phone']) ?></span>
                </div>
                <?php endif; ?>
            </div>
            <?php endif; ?>

            <!-- Social buttons -->
            <?php if ($about['dev_email'] || $about['dev_github'] || $about['dev_facebook']): ?>
            <div class="dev-socials">
                <?php if ($about['dev_email']): ?>
                <a href="mailto:<?= htmlspecialchars($about['dev_email']) ?>" class="dev-social-btn dsb-mail">✉️ Email</a>
                <?php endif; ?>
                <?php if ($about['dev_github']): ?>
                <a href="<?= htmlspecialchars($about['dev_github']) ?>" class="dev-social-btn dsb-gh" target="_blank">🐙 GitHub</a>
                <?php endif; ?>
                <?php if ($about['dev_facebook']): ?>
                <a href="<?= htmlspecialchars($about['dev_facebook']) ?>" class="dev-social-btn dsb-fb" target="_blank">📘 Facebook</a>
                <?php endif; ?>
            </div>
            <?php endif; ?>

        </div>

        <!-- System info footer strip -->
        <div class="dev-sys-strip">
            <span class="dev-sys-text">
                <strong>MARKETPLACE.</strong>
                <?php if (!empty($about['updated_at'])): ?> · Updated <?= date('M j, Y', strtotime($about['updated_at'])) ?><?php endif; ?>
            </span>
            <span style="background:#e01010;color:#fff;border-radius:20px;padding:3px 12px;font-size:.72rem;font-weight:800;">
                v<?= htmlspecialchars($about['system_version'] ?? '1.0.0') ?>
            </span>
        </div>

    </div>

    <!-- Admin-only edit button -->
    <?php if (isLoggedIn() && $_SESSION['role'] === 'admin'): ?>
    <div class="dev-edit-link">
        <a href="<?= BASE_URL ?>/pages/admin/about.php"
           style="display:inline-block;margin-top:4px;padding:9px 22px;background:#111;color:#fff;border-radius:9px;font-size:.86rem;font-weight:700;text-decoration:none;">
            ⚙️ Edit Developer Info
        </a>
    </div>
    <?php endif; ?>

</div>

</body>
</html>
