<?php
// ── Landing page ─────────────────────────────────────────────────────────────
// Logged-in users are redirected straight to their dashboard.
session_start();
require_once 'includes/config.php';

if (isLoggedIn()) {
    redirect('/pages/' . $_SESSION['role'] . '/dashboard.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>MARKETPLACE. — The Modern Filipino Marketplace</title>
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;900&display=swap" rel="stylesheet">
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

    body {
      font-family: 'Outfit', sans-serif;
      background: #0a0a0a;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      overflow-x: hidden;
    }

    /* ── Navigation ── */
    .nav {
      background: #0a0a0a;
      border-bottom: 2px solid #e01010;
      height: 58px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0 36px;
      flex-shrink: 0;
    }
    .nav-brand {
      font-size: 24px; font-weight: 900; letter-spacing: -0.5px;
      color: #fff; text-decoration: none; text-transform: uppercase;
    }
    .nav-brand span { color: #e01010; }
    .nav-btn {
      background: transparent;
      border: 1.5px solid rgba(255,255,255,0.35);
      border-radius: 3px;
      color: #fff;
      font-family: 'Outfit', sans-serif;
      font-size: 12px; font-weight: 700; letter-spacing: 1.8px;
      text-transform: uppercase;
      padding: 8px 20px;
      text-decoration: none;
      transition: border-color 0.18s, background 0.18s;
    }
    .nav-btn:hover {
      border-color: rgba(255,255,255,0.7);
      background: rgba(255,255,255,0.06);
    }

    /* ── Hero section ── */
    .hero {
      flex: 1;
      position: relative;
      display: flex;
      align-items: center;
      justify-content: center;
      text-align: center;
      padding: 60px 24px 80px;
      overflow: hidden;
    }
    /* Red radial glow from the top */
    .hero::before {
      content: '';
      position: absolute;
      top: -60px; left: 50%;
      transform: translateX(-50%);
      width: 900px; height: 520px;
      background: radial-gradient(ellipse, rgba(160,0,0,0.72) 0%, rgba(100,0,0,0.38) 40%, transparent 72%);
      pointer-events: none;
      z-index: 0;
    }
    .hero-inner { position: relative; z-index: 1; max-width: 740px; }
    .hero-title {
      font-size: clamp(48px, 8.5vw, 92px);
      font-weight: 700;
      color: #fff;
      line-height: 1.08;
      letter-spacing: -1px;
    }
    .hero-title .red { color: #e01010; display: block; }
    .hero-desc {
      font-size: clamp(15px, 2vw, 18px);
      font-weight: 300;
      color: rgba(255,255,255,0.62);
      line-height: 1.75;
      max-width: 560px;
      margin: 36px auto 0;
    }
  </style>
</head>
<body>

  <nav class="nav">
    <a href="index.php" class="nav-brand">MARKETPLACE<span>.</span></a>
    <a href="login.php" class="nav-btn">Get Started</a>
  </nav>

  <section class="hero">
    <div class="hero-inner">
      <h1 class="hero-title">
        The Modern Filipino
        <span class="red">Marketplace</span>
      </h1>
      <p class="hero-desc">
        Buy and sell local goods, crafts, and products.
        Connect buyers with trusted sellers across the Philippines.
      </p>
    </div>
  </section>

</body>
</html>
