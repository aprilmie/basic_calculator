<?php
// ── Email Verification Handler ────────────────────────────────────────────────
session_start();
require_once 'includes/config.php';

$token  = trim($_GET['token'] ?? '');
$status = 'invalid'; // invalid | already | success

if ($token) {
    $db   = getDB();
    $stmt = $db->prepare('SELECT id, verify_status FROM users WHERE verify_token = ?');
    $stmt->execute([$token]);
    $user = $stmt->fetch();

    if ($user) {
        if ($user['verify_status'] == 1) {
            $status = 'already';
        } else {
            $db->prepare('UPDATE users SET verify_status = 1, verify_token = NULL WHERE id = ?')
               ->execute([$user['id']]);
            $status = 'success';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Email Verification — MARKETPLACE.</title>
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;600;700;900&display=swap" rel="stylesheet">
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: 'Outfit', sans-serif;
      background: #0a0a0a;
      min-height: 100vh;
      display: flex; flex-direction: column;
    }
    .nav {
      background: #0a0a0a;
      border-bottom: 2px solid #e01010;
      height: 58px;
      display: flex; align-items: center;
      padding: 0 36px;
    }
    .nav-brand {
      font-size: 24px; font-weight: 900;
      color: #fff; text-decoration: none; text-transform: uppercase;
    }
    .nav-brand span { color: #e01010; }
    .page {
      flex: 1; display: flex; align-items: center; justify-content: center;
      padding: 40px 16px;
      background:
        radial-gradient(ellipse 65% 52% at 50% 0%, rgba(155,0,0,0.72) 0%, transparent 65%),
        #0a0a0a;
    }
    .card {
      background: #fff; border-radius: 10px;
      padding: 40px 36px; width: 100%; max-width: 400px;
      text-align: center;
      box-shadow: 0 28px 70px rgba(0,0,0,0.55);
    }
    .icon  { font-size: 52px; margin-bottom: 18px; }
    .title { font-size: 24px; font-weight: 900; color: #111; text-transform: uppercase; letter-spacing: -0.5px; margin-bottom: 10px; }
    .msg   { font-size: 14px; color: #777; line-height: 1.7; margin-bottom: 26px; }
    .btn {
      display: inline-block;
      background: #e01010; color: #fff;
      padding: 13px 32px; border-radius: 6px;
      font-family: 'Outfit', sans-serif;
      font-size: 14px; font-weight: 800; letter-spacing: 2px;
      text-transform: uppercase; text-decoration: none;
      transition: background .18s;
    }
    .btn:hover { background: #c00; }
    .btn.grey  { background: #555; }
    .btn.grey:hover { background: #333; }
  </style>
</head>
<body>
<nav class="nav">
  <a href="index.php" class="nav-brand">MARKETPLACE<span>.</span></a>
</nav>
<div class="page">
  <div class="card">
    <?php if ($status === 'success'): ?>
      <div class="icon">✅</div>
      <div class="title">Email Verified!</div>
      <p class="msg">Your account has been successfully verified. You can now log in and start using MARKETPLACE.</p>
      <a href="login.php" class="btn">Sign In</a>

    <?php elseif ($status === 'already'): ?>
      <div class="icon">ℹ️</div>
      <div class="title">Already Verified</div>
      <p class="msg">This account is already verified. You can go ahead and log in.</p>
      <a href="login.php" class="btn">Sign In</a>

    <?php else: ?>
      <div class="icon">❌</div>
      <div class="title">Invalid Link</div>
      <p class="msg">This verification link is invalid or has already been used. Please register again or contact support if you need help.</p>
      <a href="login.php?tab=register" class="btn grey">Register</a>
    <?php endif; ?>
  </div>
</div>
</body>
</html>
