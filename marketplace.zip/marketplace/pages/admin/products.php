<?php
// ── Admin – Product Management ───────────────────────────────────────────────
session_start();
require_once '../../includes/config.php';

if (!isLoggedIn() || $_SESSION['role'] !== 'admin') redirect('/login.php');

$user  = currentUser();
$db    = getDB();

// ── Handle POST actions ───────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // Add a new product (admin adds on behalf of any seller / as platform)
    if ($action === 'add_product') {
        $name   = trim($_POST['name']        ?? '');
        $desc   = trim($_POST['description'] ?? '');
        $price  = (float) ($_POST['price']   ?? 0);
        $stock  = (int)   ($_POST['stock']   ?? 0);
        $cat    = (int)   ($_POST['category_id'] ?? 0);
        $sid    = (int)   ($_POST['seller_id']   ?? 0);
        $status = $_POST['status'] ?? 'active';
        $imgPath = null;

        // Handle image upload
        $file = $_FILES['image'] ?? null;
        if ($file && $file['error'] === 0) {
            $ext     = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            $allowed = ['jpg','jpeg','png','gif','webp'];
            if (in_array($ext, $allowed)) {
                $dir = '../../uploads/products/';
                if (!is_dir($dir)) mkdir($dir, 0775, true);
                $filename = 'product_' . time() . '_' . uniqid() . '.' . $ext;
                move_uploaded_file($file['tmp_name'], $dir . $filename);
                $imgPath = 'uploads/products/' . $filename;
            }
        }

        $db->prepare('INSERT INTO products (seller_id, category_id, name, description, price, stock, image, status) VALUES (?,?,?,?,?,?,?,?)')
           ->execute([$sid ?: 1, $cat, $name, $desc, $price, $stock, $imgPath, $status]);
        setToast('success', 'Product added.');
            redirect('/pages/admin/products.php');
    }

    // Edit a product (admin full edit)
    if ($action === 'edit_product') {
        $pid    = (int) $_POST['product_id'];
        $name   = trim($_POST['name']        ?? '');
        $desc   = trim($_POST['description'] ?? '');
        $price  = (float) ($_POST['price']   ?? 0);
        $stock  = (int)   ($_POST['stock']   ?? 0);
        $cat    = (int)   ($_POST['category_id'] ?? 0);
        $sid    = (int)   ($_POST['seller_id']   ?? 0);
        $status = $_POST['status'] ?? 'active';

        // Handle new image upload
        $file = $_FILES['image'] ?? null;
        if ($file && $file['error'] === 0) {
            $ext     = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            $allowed = ['jpg','jpeg','png','gif','webp'];
            if (in_array($ext, $allowed)) {
                $dir = '../../uploads/products/';
                if (!is_dir($dir)) mkdir($dir, 0775, true);
                // Remove old image
                $old = $db->prepare('SELECT image FROM products WHERE id = ?');
                $old->execute([$pid]);
                $oldRow = $old->fetch();
                if ($oldRow && $oldRow['image'] && file_exists('../../' . $oldRow['image'])) {
                    unlink('../../' . $oldRow['image']);
                }
                $filename = 'product_' . time() . '_' . uniqid() . '.' . $ext;
                move_uploaded_file($file['tmp_name'], $dir . $filename);
                $db->prepare('UPDATE products SET seller_id=?,category_id=?,name=?,description=?,price=?,stock=?,image=?,status=? WHERE id=?')
                   ->execute([$sid, $cat, $name, $desc, $price, $stock, 'uploads/products/'.$filename, $status, $pid]);
            }
        } else {
            $db->prepare('UPDATE products SET seller_id=?,category_id=?,name=?,description=?,price=?,stock=?,status=? WHERE id=?')
               ->execute([$sid, $cat, $name, $desc, $price, $stock, $status, $pid]);
        }
        setToast('success', 'Product updated.');
            redirect('/pages/admin/products.php');
    }

    // Update a product's status
    if ($action === 'update_status') {
        $pid    = (int) $_POST['product_id'];
        $status = $_POST['status'];
        if (in_array($status, ['active', 'inactive', 'sold_out'])) {
            $db->prepare('UPDATE products SET status = ? WHERE id = ?')->execute([$status, $pid]);
            setToast('success', 'Product status updated.');
            redirect('/pages/admin/products.php');
        }
    }

    // Delete a product
    if ($action === 'delete_product') {
        $pid  = (int) $_POST['product_id'];
        $prod = $db->prepare('SELECT image FROM products WHERE id = ?');
        $prod->execute([$pid]);
        $row  = $prod->fetch();
        if ($row && $row['image'] && file_exists('../../' . $row['image'])) {
            unlink('../../' . $row['image']);
        }
        // Remove FK-dependent rows first
        $db->prepare('DELETE FROM cart        WHERE product_id = ?')->execute([$pid]);
        $db->prepare('DELETE FROM order_items WHERE product_id = ?')->execute([$pid]);
        $db->prepare('DELETE FROM products    WHERE id = ?')->execute([$pid]);
        setToast('success', 'Product deleted.');
        redirect('/pages/admin/products.php');
    }
}


// ── Search & filter ───────────────────────────────────────────────────────────
$search    = trim($_GET['q']   ?? '');
$catFilter = $_GET['cat']      ?? 'all';

$where  = ['1=1'];
$params = [];
if ($search) {
    $where[]  = '(p.name LIKE ? OR u.full_name LIKE ?)';
    $params[] = "%$search%";
    $params[] = "%$search%";
}
if ($catFilter !== 'all') {
    $where[]  = 'c.name = ?';
    $params[] = $catFilter;
}

$stmt = $db->prepare('
    SELECT p.*, c.name AS cat_name, u.full_name AS seller_name
    FROM products p
    LEFT JOIN categories c ON p.category_id = c.id
    JOIN users u ON p.seller_id = u.id
    WHERE ' . implode(' AND ', $where) . '
    ORDER BY p.created_at DESC
');
$stmt->execute($params);
$products = $stmt->fetchAll();

$cats    = $db->query('SELECT DISTINCT name FROM categories ORDER BY name')->fetchAll(PDO::FETCH_COLUMN);
$catRows = $db->query('SELECT * FROM categories ORDER BY name')->fetchAll();
$sellers = $db->query("SELECT id, full_name FROM users WHERE role = 'seller' ORDER BY full_name")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <?php $pageTitle = 'Products'; include '../../includes/head.php'; ?>
</head>
<body>
<?php include '../../includes/nav.php'; ?>

<div class="dash-layout">
  <?php include '../../includes/admin_sidebar.php'; ?>

  <main class="dash-main">
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:4px;">
      <div>
        <div class="dash-page-title">All Products</div>
        <div class="dash-page-sub"><?= count($products) ?> products on platform</div>
      </div>
      <button class="btn btn-red" onclick="openModal('addProductModal')">+ Add Product</button>
    </div>

    <!-- Search + category filter -->
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:20px;flex-wrap:wrap;">
      <form method="GET" style="flex:1;min-width:220px;margin:0;">
        <div class="search-bar-wrap" style="margin-bottom:0;">
          <input type="text" name="q" value="<?= sanitize($search) ?>"
                 placeholder="Search products or sellers..." class="form-control"
                 style="height:42px;">
          <span class="search-icon">
            <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                d="M21 21l-4.35-4.35m0 0A7.5 7.5 0 104.5 4.5a7.5 7.5 0 0012.15 12.15z"/>
            </svg>
          </span>
          <?php if ($catFilter !== 'all'): ?>
            <input type="hidden" name="cat" value="<?= $catFilter ?>">
          <?php endif; ?>
        </div>
      </form>
      <div style="display:flex;gap:6px;flex-shrink:0;flex-wrap:nowrap;overflow-x:auto;">
        <a href="?cat=all<?= $search ? '&q=' . urlencode($search) : '' ?>"
           style="
             display:inline-flex;align-items:center;justify-content:center;
             height:42px;padding:0 18px;border-radius:6px;font-size:13px;font-weight:700;
             text-decoration:none;white-space:nowrap;transition:all .12s;
             <?= $catFilter === 'all'
               ? 'background:#111;color:#fff;border:1.5px solid #111;'
               : 'background:#fff;color:#444;border:1.5px solid #ddd;' ?>
           ">All</a>
        <?php foreach ($cats as $c): ?>
          <a href="?cat=<?= urlencode($c) ?><?= $search ? '&q=' . urlencode($search) : '' ?>"
             style="
               display:inline-flex;align-items:center;justify-content:center;
               height:42px;padding:0 18px;border-radius:6px;font-size:13px;font-weight:700;
               text-decoration:none;white-space:nowrap;transition:all .12s;
               <?= $catFilter === $c
                 ? 'background:#111;color:#fff;border:1.5px solid #111;'
                 : 'background:#fff;color:#444;border:1.5px solid #ddd;' ?>
             ">
            <?= sanitize($c) ?>
          </a>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- Products table -->
    <div class="dash-table-card">
      <table class="dash-table">
        <thead>
          <tr>
            <th>Image</th>
            <th>Product</th>
            <th>Seller</th>
            <th>Category</th>
            <th>Price</th>
            <th>Stock</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($products)): ?>
            <tr>
              <td colspan="8" style="text-align:center;padding:40px;color:#888">No products found.</td>
            </tr>
          <?php else: ?>
            <?php foreach ($products as $p): ?>
              <tr>
                <td>
                  <?php if (!empty($p['image'])): ?>
                    <img src="<?= BASE_URL . '/' . sanitize($p['image']) ?>" alt=""
                         style="width:44px;height:44px;object-fit:cover;border-radius:4px;border:1px solid #e5e7eb;">
                  <?php else: ?>
                    <div style="width:44px;height:44px;background:#f3f4f6;border-radius:4px;display:flex;align-items:center;justify-content:center;">
                      <svg width="18" height="18" fill="none" stroke="#9ca3af" viewBox="0 0 24 24">
                        <rect x="3" y="3" width="18" height="18" rx="2" stroke-width="1.5"/>
                        <circle cx="8.5" cy="8.5" r="1.5" stroke-width="1.5"/>
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M21 15l-5-5L5 21"/>
                      </svg>
                    </div>
                  <?php endif; ?>
                </td>
                <td><strong><?= sanitize($p['name']) ?></strong></td>
                <td><?= sanitize($p['seller_name']) ?></td>
                <td><?= sanitize($p['cat_name'] ?? '') ?></td>
                <td><?= formatPrice($p['price']) ?></td>
                <td><?= $p['stock'] ?></td>
                <td><span class="badge badge-<?= $p['status'] ?>"><?= strtoupper($p['status']) ?></span></td>
                <td>
                  <div class="action-btns">
                    <!-- Update status -->
                    <form method="POST" style="display:flex;gap:4px">
                      <input type="hidden" name="action"     value="update_status">
                      <input type="hidden" name="product_id" value="<?= $p['id'] ?>">
                      <select name="status" class="form-control"
                              style="width:100px;padding:4px 6px;font-size:12px">
                        <?php foreach (['active', 'sold_out', 'inactive'] as $s): ?>
                          <option value="<?= $s ?>" <?= $p['status'] === $s ? 'selected' : '' ?>>
                            <?= ucfirst(str_replace('_', ' ', $s)) ?>
                          </option>
                        <?php endforeach; ?>
                      </select>
                      <button type="submit" class="btn btn-sm btn-dark">Set</button>
                    </form>
                    <!-- Edit -->
                    <button class="btn btn-sm"
                            style="background:#e0f0ff;color:#1d4ed8;border:none;font-weight:600;"
                            onclick="openEditModal(<?= htmlspecialchars(json_encode($p), ENT_QUOTES) ?>)">
                      Edit
                    </button>
                    <!-- Delete -->
                    <form method="POST" data-confirm="Delete this product?">
                      <input type="hidden" name="action"     value="delete_product">
                      <input type="hidden" name="product_id" value="<?= $p['id'] ?>">
                      <button type="submit" class="btn btn-sm"
                              style="background:#fee2e2;color:#991b1b;border:none">Delete</button>
                    </form>
                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </main>
</div>
<!-- ── Add Product Modal ──────────────────────────────────────────────────── -->
<div class="modal-overlay" id="addProductModal">
  <div class="modal">
    <button class="modal-close" onclick="closeModal('addProductModal')">&times;</button>
    <div class="modal-title">Add New Product</div>
    <form method="POST" enctype="multipart/form-data">
      <input type="hidden" name="action" value="add_product">

      <!-- Image upload -->
      <div class="form-group">
        <label class="form-label">Product Image</label>
        <div class="product-img-upload" onclick="document.getElementById('prodImgInput').click()">
          <img id="prodImgPreview" src="" alt="" style="display:none;">
          <svg id="prodImgIcon" width="32" height="32" fill="none" stroke="#9ca3af" viewBox="0 0 24 24" style="margin:0 auto 6px;">
            <rect x="3" y="3" width="18" height="18" rx="2" stroke-width="1.5"/>
            <circle cx="8.5" cy="8.5" r="1.5" stroke-width="1.5"/>
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M21 15l-5-5L5 21"/>
          </svg>
          <span>Click to upload image (JPG, PNG, WEBP)</span>
          <input type="file" name="image" id="prodImgInput" accept="image/*" style="display:none"
                 onchange="previewProductImg(this)">
        </div>
      </div>

      <div class="form-group">
        <label class="form-label">Product Name</label>
        <input type="text" name="name" class="form-control" required>
      </div>
      <div class="form-group">
        <label class="form-label">Description</label>
        <textarea name="description" class="form-control" rows="2"></textarea>
      </div>
      <div class="form-grid-2">
        <div class="form-group">
          <label class="form-label">Price (₱)</label>
          <input type="number" step="0.01" name="price" class="form-control" required>
        </div>
        <div class="form-group">
          <label class="form-label">Stock</label>
          <input type="number" name="stock" class="form-control" value="0">
        </div>
      </div>
      <div class="form-grid-2">
        <div class="form-group">
          <label class="form-label">Category</label>
          <select name="category_id" class="form-control">
            <?php foreach ($catRows as $c): ?>
              <option value="<?= $c['id'] ?>"><?= sanitize($c['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Status</label>
          <select name="status" class="form-control">
            <option value="active">Active</option>
            <option value="sold_out">Sold Out</option>
            <option value="inactive">Inactive</option>
          </select>
        </div>
      </div>
      <div class="form-group">
        <label class="form-label">Assign to Seller</label>
        <select name="seller_id" class="form-control">
          <?php foreach ($sellers as $s): ?>
            <option value="<?= $s['id'] ?>"><?= sanitize($s['full_name']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <button type="submit" class="btn btn-red btn-full" style="margin-top:8px">Add Product</button>
    </form>
  </div>
</div>

<!-- ── Edit Product Modal ─────────────────────────────────────────────────── -->
<div class="modal-overlay" id="editProductModal">
  <div class="modal">
    <button class="modal-close" onclick="closeModal('editProductModal')">&times;</button>
    <div class="modal-title">Edit Product</div>
    <form method="POST" enctype="multipart/form-data">
      <input type="hidden" name="action" value="edit_product">
      <input type="hidden" name="product_id" id="edit-pid">

      <!-- Image upload -->
      <div class="form-group">
        <label class="form-label">Product Image</label>
        <div class="product-img-upload" onclick="document.getElementById('editImgInput').click()">
          <img id="editImgPreview" src="" alt="" style="display:none;max-height:100px;border-radius:4px;margin:0 auto 6px;">
          <svg id="editImgIcon" width="32" height="32" fill="none" stroke="#9ca3af" viewBox="0 0 24 24" style="margin:0 auto 6px;">
            <rect x="3" y="3" width="18" height="18" rx="2" stroke-width="1.5"/>
            <circle cx="8.5" cy="8.5" r="1.5" stroke-width="1.5"/>
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M21 15l-5-5L5 21"/>
          </svg>
          <span id="editImgLabel">Click to change image (leave blank to keep current)</span>
          <input type="file" name="image" id="editImgInput" accept="image/*" style="display:none"
                 onchange="previewEditImg(this)">
        </div>
      </div>

      <div class="form-group">
        <label class="form-label">Product Name</label>
        <input type="text" name="name" id="edit-name" class="form-control" required>
      </div>
      <div class="form-group">
        <label class="form-label">Description</label>
        <textarea name="description" id="edit-desc" class="form-control" rows="2"></textarea>
      </div>
      <div class="form-grid-2">
        <div class="form-group">
          <label class="form-label">Price (₱)</label>
          <input type="number" step="0.01" name="price" id="edit-price" class="form-control">
        </div>
        <div class="form-group">
          <label class="form-label">Stock</label>
          <input type="number" name="stock" id="edit-stock" class="form-control">
        </div>
      </div>
      <div class="form-grid-2">
        <div class="form-group">
          <label class="form-label">Category</label>
          <select name="category_id" id="edit-cat" class="form-control">
            <?php foreach ($catRows as $c): ?>
              <option value="<?= $c['id'] ?>"><?= sanitize($c['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Status</label>
          <select name="status" id="edit-status" class="form-control">
            <option value="active">Active</option>
            <option value="sold_out">Sold Out</option>
            <option value="inactive">Inactive</option>
          </select>
        </div>
      </div>
      <div class="form-group">
        <label class="form-label">Assign to Seller</label>
        <select name="seller_id" id="edit-seller" class="form-control">
          <?php foreach ($sellers as $s): ?>
            <option value="<?= $s['id'] ?>"><?= sanitize($s['full_name']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <button type="submit" class="btn btn-red btn-full" style="margin-top:8px">Save Changes</button>
    </form>
  </div>
</div>

<script>
  function openModal(id)  { document.getElementById(id).classList.add('open'); }
  function closeModal(id) { document.getElementById(id).classList.remove('open'); }

  function previewProductImg(input) {
    if (input.files && input.files[0]) {
      const reader = new FileReader();
      reader.onload = e => {
        const preview = document.getElementById('prodImgPreview');
        const icon    = document.getElementById('prodImgIcon');
        preview.src = e.target.result;
        preview.style.display = 'block';
        icon.style.display    = 'none';
      };
      reader.readAsDataURL(input.files[0]);
    }
  }

  function previewEditImg(input) {
    if (input.files && input.files[0]) {
      const reader = new FileReader();
      reader.onload = e => {
        const preview = document.getElementById('editImgPreview');
        const icon    = document.getElementById('editImgIcon');
        const label   = document.getElementById('editImgLabel');
        preview.src = e.target.result;
        preview.style.display = 'block';
        icon.style.display    = 'none';
        label.textContent     = 'Click to change image';
      };
      reader.readAsDataURL(input.files[0]);
    }
  }

  function openEditModal(p) {
    document.getElementById('edit-pid').value    = p.id;
    document.getElementById('edit-name').value   = p.name;
    document.getElementById('edit-desc').value   = p.description ?? '';
    document.getElementById('edit-price').value  = p.price;
    document.getElementById('edit-stock').value  = p.stock;
    document.getElementById('edit-cat').value    = p.category_id;
    document.getElementById('edit-status').value = p.status;
    document.getElementById('edit-seller').value = p.seller_id;

    // Show existing image or placeholder
    const preview = document.getElementById('editImgPreview');
    const icon    = document.getElementById('editImgIcon');
    const label   = document.getElementById('editImgLabel');
    if (p.image) {
      preview.src = '<?= BASE_URL ?>/' + p.image;
      preview.style.display = 'block';
      icon.style.display    = 'none';
      label.textContent     = 'Click to change image';
    } else {
      preview.style.display = 'none';
      icon.style.display    = 'block';
      label.textContent     = 'Click to upload image (leave blank to keep none)';
    }
    // Reset file input
    document.getElementById('editImgInput').value = '';
    openModal('editProductModal');
  }
</script>
<?php include '../../includes/toast.php'; ?>
</body>
</html>
