<?php
// ── Admin – About & Developer Info ───────────────────────────────────────────
session_start();
require_once '../../includes/config.php';

if (!isLoggedIn() || $_SESSION['role'] !== 'admin') redirect('/login.php');

$db   = getDB();
$user = currentUser();

// ── Save handler ──────────────────────────────────────────────────────────────
$toast = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save_about') {
    $fields = ['dev_name', 'dev_role', 'dev_email', 'dev_phone', 'dev_facebook', 'dev_bio', 'site_name'];
    $sets   = [];
    $params = [];
    foreach ($fields as $f) {
        $sets[]   = "$f = ?";
        $params[] = trim($_POST[$f] ?? '');
    }

    // Handle photo upload
    if (!empty($_FILES['dev_photo']['tmp_name'])) {
        $ext = strtolower(pathinfo($_FILES['dev_photo']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, ['jpg', 'jpeg', 'png', 'webp', 'gif'])) {
            $fname = 'dev_photo_' . time() . '.' . $ext;
            if (move_uploaded_file($_FILES['dev_photo']['tmp_name'], __DIR__ . '/../../uploads/' . $fname)) {
                $sets[]   = "dev_photo = ?";
                $params[] = $fname;
            }
        }
    }

    $params[] = 1; // WHERE id = 1
    $db->prepare("UPDATE about_info SET " . implode(', ', $sets) . " WHERE id = ?")->execute($params);
    $toast = ['type' => 'success', 'msg' => 'Developer info saved successfully!'];
}

// ── Load about info ───────────────────────────────────────────────────────────
$about = $db->query("SELECT * FROM about_info WHERE id = 1")->fetch();

$dev_photo = !empty($about['dev_photo'])
    ? '../../uploads/' . htmlspecialchars($about['dev_photo'])
    : 'https://ui-avatars.com/api/?name=' . urlencode($about['dev_name'] ?? 'Dev') . '&background=111111&color=fff&size=200&bold=true&format=png';

$adm_photo = !empty($user['is_super_user'])
    ? '../../uploads/avatars/super_admin_avatar.jpg'
    : (!empty($user['avatar'])
        ? '../../' . htmlspecialchars($user['avatar'])
        : 'https://ui-avatars.com/api/?name=' . urlencode($user['full_name'] ?? 'Admin') . '&background=e01010&color=fff&size=200&bold=true&format=png');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php $pageTitle = 'About & Developer'; include '../../includes/head.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>
<?php include '../../includes/nav.php'; ?>

<div class="dash-layout">
  <?php include '../../includes/admin_sidebar.php'; ?>

  <main class="dash-main">
    <div class="dash-page-title">About &amp; Developer</div>
    <div class="dash-page-sub">Manage the developer info shown on the public About page.</div>

<style>
.abt-page { display:flex; flex-direction:column; gap:22px; }

.abt-hero {
    background: linear-gradient(135deg, #111 0%, #2a2a2a 60%, #1a1a1a 100%);
    border-radius: 16px;
    padding: 32px 36px;
    display: flex; align-items: center; gap: 28px; flex-wrap: wrap;
    color: #fff; box-shadow: 0 6px 28px rgba(0,0,0,.18);
    position: relative; overflow: hidden;
}
.abt-hero::before {
    content: ''; position: absolute; right: -40px; top: -40px;
    width: 220px; height: 220px; border-radius: 50%;
    background: rgba(224,16,16,.12); pointer-events: none;
}
.abt-hero-photo {
    width: 110px; height: 110px; border-radius: 50%; object-fit: cover;
    border: 4px solid #e01010; box-shadow: 0 4px 18px rgba(224,16,16,.4);
    flex-shrink: 0; position: relative; z-index: 1;
}
.abt-hero-text h2 { margin: 0 0 4px; font-size: 1.6rem; }
.abt-hero-text .abt-role { color: #e01010; font-weight: 700; font-size: .92rem; margin: 0 0 8px; }
.abt-hero-text .abt-meta { display: flex; gap: 14px; flex-wrap: wrap; margin-top: 10px; }
.abt-meta-item { font-size: .83rem; color: rgba(255,255,255,.7); display: flex; align-items: center; gap: 5px; }
.abt-meta-item strong { color: #fff; }
.abt-super-badge { display:inline-flex;align-items:center;gap:5px;background:#e8a020;color:#fff;border-radius:20px;padding:3px 12px;font-size:.75rem;font-weight:700;margin-left:8px;vertical-align:middle; }

.abt-cols { display: flex; gap: 22px; flex-wrap: wrap; }
.abt-col-left  { flex: 1; min-width: 260px; display: flex; flex-direction: column; gap: 22px; }
.abt-col-right { flex: 2; min-width: 300px; }

.abt-card {
    background: #fff; border-radius: 14px;
    box-shadow: 0 2px 12px rgba(0,0,0,.07);
    padding: 24px 26px;
}
.abt-card-title {
    font-size: .78rem; text-transform: uppercase; letter-spacing: .6px;
    color: #aaa; font-weight: 700; margin: 0 0 16px;
    padding-bottom: 10px; border-bottom: 2px solid #f4f4f4;
    display: flex; align-items: center; gap: 7px;
}

.abt-info-row { display: flex; align-items: flex-start; gap: 10px; padding: 9px 0; border-bottom: 1px solid #f5f5f5; }
.abt-info-row:last-child { border-bottom: none; }
.abt-info-row .lbl { font-size: .78rem; color: #aaa; font-weight: 600; min-width: 90px; padding-top: 2px; text-transform: uppercase; letter-spacing: .3px; }
.abt-info-row .val { font-size: .92rem; color: #111; font-weight: 600; word-break: break-word; }

.abt-socials { display: flex; gap: 8px; flex-wrap: wrap; margin-top: 14px; }
.abt-social-btn { display:inline-flex;align-items:center;gap:6px;padding:7px 15px;border-radius:8px;font-size:.82rem;font-weight:700;text-decoration:none;transition:transform .15s,box-shadow .15s; }
.abt-social-btn:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,.15); }
.abt-sb-fb   { background: #1877f2; color: #fff; }
.abt-sb-mail { background: #e01010; color: #fff; }

.abt-dev-photo-wrap { text-align: center; margin-bottom: 16px; }
.abt-dev-photo { width:90px;height:90px;border-radius:50%;object-fit:cover;border:3px solid #111;box-shadow:0 3px 12px rgba(0,0,0,.12); }
.abt-dev-name { font-size:1.1rem;font-weight:800;color:#111;margin:0 0 2px;text-align:center; }
.abt-dev-role { color:#e01010;font-weight:600;font-size:.84rem;text-align:center;margin:0 0 14px; }
.abt-site-box { background:linear-gradient(135deg,#111,#2a2a2a);border-radius:10px;padding:12px 16px;color:#fff;font-size:.85rem;text-align:center; }
.abt-site-box strong { display:block;font-size:.95rem;margin-bottom:2px;font-family:'Bebas Neue',sans-serif;letter-spacing:1px; }

.af { margin-bottom: 14px; }
.af label { display: block; font-weight: 600; font-size: .83rem; color: #555; margin-bottom: 5px; }
.af input[type=text],
.af input[type=email],
.af textarea {
    width: 100%; padding: 9px 12px; border: 1.5px solid #ddd; border-radius: 8px;
    font-size: .92rem; box-sizing: border-box; font-family: 'Outfit', sans-serif;
    transition: border-color .15s;
}
.af input:focus, .af textarea:focus { outline: none; border-color: #e01010; box-shadow: 0 0 0 3px rgba(224,16,16,.09); }
.af textarea { resize: vertical; min-height: 76px; }
.af-row { display: flex; gap: 14px; flex-wrap: wrap; }
.af-row .af { flex: 1; min-width: 150px; }
.af-photo-thumb { width: 68px; height: 68px; border-radius: 50%; object-fit: cover; border: 3px solid #e01010; flex-shrink: 0; }
</style>

<div class="abt-page">

    <!-- Admin hero -->
    <div class="abt-hero">
        <img src="<?= $adm_photo ?>" class="abt-hero-photo" alt="Admin Photo">
        <div class="abt-hero-text">
            <h2>
                <?= htmlspecialchars($user['full_name'] ?? 'Admin') ?>
                <?php if (!empty($user['is_super_user'])): ?>
                <span class="abt-super-badge">⭐ Super Admin</span>
                <?php endif; ?>
            </h2>
            <div class="abt-role">🔑 <?= ucfirst($user['role'] ?? 'admin') ?> — MARKETPLACE.</div>
            <div class="abt-meta">
                <span class="abt-meta-item">✉️ <strong><?= htmlspecialchars($user['email'] ?? '—') ?></strong></span>
                <span class="abt-meta-item">🛒 <strong><?= htmlspecialchars($about['site_name'] ?? 'MARKETPLACE.') ?></strong></span>
                <span class="abt-meta-item">🗓️ Joined <strong><?= !empty($user['created_at']) ? date('M j, Y', strtotime($user['created_at'])) : '—' ?></strong></span>
            </div>
        </div>
    </div>

    <!-- Two-column content -->
    <div class="abt-cols">

        <!-- Left: preview + system info -->
        <div class="abt-col-left">

            <div class="abt-card">
                <div class="abt-card-title">👨‍💻 Developer Preview</div>
                <div class="abt-dev-photo-wrap">
                    <img src="<?= $dev_photo ?>" class="abt-dev-photo" id="photoPreviewImg" alt="Developer">
                </div>
                <div class="abt-dev-name"><?= htmlspecialchars($about['dev_name'] ?? '—') ?></div>
                <div class="abt-dev-role"><?= htmlspecialchars($about['dev_role'] ?? '—') ?></div>

                <?php if (!empty($about['dev_bio'])): ?>
                <p style="font-size:.84rem;color:#666;line-height:1.6;text-align:center;margin:0 0 14px;"><?= nl2br(htmlspecialchars($about['dev_bio'])) ?></p>
                <?php endif; ?>

                <?php if ($about['dev_email'] || $about['dev_facebook']): ?>
                <div class="abt-socials" style="justify-content:center;">
                    <?php if ($about['dev_email']): ?>
                    <a href="mailto:<?= htmlspecialchars($about['dev_email']) ?>" class="abt-social-btn abt-sb-mail">✉️ Email</a>
                    <?php endif; ?>
                    <?php if ($about['dev_facebook']): ?>
                    <a href="<?= htmlspecialchars($about['dev_facebook']) ?>" class="abt-social-btn abt-sb-fb" target="_blank">📘 Facebook</a>
                    <?php endif; ?>
                </div>
                <?php endif; ?>

                <div class="abt-site-box" style="margin-top:16px;">
                    <strong><?= htmlspecialchars($about['site_name'] ?? 'MARKETPLACE.') ?></strong>
                    Online Marketplace System
                </div>
            </div>

            <!-- System info card -->
            <div class="abt-card">
                <div class="abt-card-title">🖥️ System Info</div>
                <div class="abt-info-row">
                    <span class="lbl">System</span>
                    <span class="val">MARKETPLACE.</span>
                </div>
                <div class="abt-info-row">
                    <span class="lbl">Last Edit</span>
                    <span class="val"><?= !empty($about['updated_at']) ? date('M j, Y g:i A', strtotime($about['updated_at'])) : '—' ?></span>
                </div>
            </div>
        </div>

        <!-- Right: edit form -->
        <div class="abt-col-right">
            <div class="abt-card">
                <div class="abt-card-title">✏️ Edit Developer Information</div>
                <form method="post" action="about.php" enctype="multipart/form-data">
                    <input type="hidden" name="action" value="save_about">

                    <div class="af-row">
                        <div class="af">
                            <label>Developer Name *</label>
                            <input type="text" name="dev_name" value="<?= htmlspecialchars($about['dev_name'] ?? '') ?>" required placeholder="Juan Dela Cruz">
                        </div>
                        <div class="af">
                            <label>Role / Title</label>
                            <input type="text" name="dev_role" value="<?= htmlspecialchars($about['dev_role'] ?? '') ?>" placeholder="Full-Stack Developer">
                        </div>
                    </div>

                    <div class="af-row">
                        <div class="af">
                            <label>Email</label>
                            <input type="email" name="dev_email" value="<?= htmlspecialchars($about['dev_email'] ?? '') ?>" placeholder="dev@email.com">
                        </div>
                        <div class="af">
                            <label>Phone</label>
                            <input type="text" name="dev_phone" value="<?= htmlspecialchars($about['dev_phone'] ?? '') ?>" placeholder="+63 9XX XXX XXXX">
                        </div>
                    </div>

                    <div class="af">
                        <label>Facebook URL</label>
                        <input type="text" name="dev_facebook" value="<?= htmlspecialchars($about['dev_facebook'] ?? '') ?>" placeholder="https://facebook.com/username">
                    </div>

                    <div class="af">
                        <label>Bio / Description</label>
                        <textarea name="dev_bio" placeholder="Write a short bio about the developer..."><?= htmlspecialchars($about['dev_bio'] ?? '') ?></textarea>
                    </div>

                    <div class="af">
                        <label>Site Name</label>
                        <input type="text" name="site_name" value="<?= htmlspecialchars($about['site_name'] ?? '') ?>" placeholder="MARKETPLACE.">
                    </div>

                    <div class="af">
                        <label>Developer Photo <span style="color:#bbb;font-weight:400;font-size:.75rem;">(JPG/PNG/WEBP — leave blank to keep current)</span></label>
                        <div style="display:flex;align-items:center;gap:14px;flex-wrap:wrap;">
                            <img src="<?= $dev_photo ?>" class="af-photo-thumb" id="photoPreviewThumb" alt="">
                            <input type="file" name="dev_photo" accept="image/*" onchange="previewAboutPhoto(this)" style="flex:1;min-width:0;">
                        </div>
                    </div>

                    <div style="display:flex;justify-content:flex-end;gap:10px;margin-top:6px;">
                        <button type="submit" class="btn" style="padding:10px 28px;font-size:.92rem;">💾 Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

  </main>
</div>

<?php if ($toast): ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    Swal.fire({
        icon: <?= json_encode($toast['type']) ?>,
        title: 'Saved!',
        text: <?= json_encode($toast['msg']) ?>,
        confirmButtonColor: '#e01010',
        timer: 3000,
        timerProgressBar: true
    });
});
</script>
<?php endif; ?>

<script>
function previewAboutPhoto(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function (e) {
            document.getElementById('photoPreviewThumb').src = e.target.result;
            document.getElementById('photoPreviewImg').src   = e.target.result;
        };
        reader.readAsDataURL(input.files[0]);
    }
}
</script>

</body>
</html>
