<?php
// ── Admin – Order Management ─────────────────────────────────────────────────
session_start();
require_once '../../includes/config.php';

if (!isLoggedIn() || $_SESSION['role'] !== 'admin') redirect('/login.php');

$user  = currentUser();
$db    = getDB();

// ── Update order status ───────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'update_status') {
    $orderId = (int) $_POST['order_id'];
    $status  = $_POST['status'];
    if (in_array($status, ['paid', 'shipped', 'delivered', 'cancelled'])) {
        $db->prepare('UPDATE orders SET status = ? WHERE id = ?')->execute([$status, $orderId]);
        setToast('success', 'Order status updated.');
            redirect('/pages/admin/orders.php');
    }
}


// ── Search & status filter ────────────────────────────────────────────────────
$search       = trim($_GET['q']    ?? '');
$statusFilter = $_GET['status']    ?? 'all';

$where  = ['1=1'];
$params = [];
if ($search) {
    $where[]  = '(o.order_code LIKE ? OR u.full_name LIKE ?)';
    $params[] = "%$search%";
    $params[] = "%$search%";
}
if ($statusFilter !== 'all') {
    $where[]  = 'o.status = ?';
    $params[] = $statusFilter;
}

$stmt = $db->prepare('
    SELECT o.*, u.full_name AS customer_name,
           GROUP_CONCAT(p.name SEPARATOR ", ") AS products
    FROM orders o
    JOIN users u ON o.customer_id = u.id
    LEFT JOIN order_items oi ON o.id = oi.order_id
    LEFT JOIN products p     ON oi.product_id = p.id
    WHERE ' . implode(' AND ', $where) . '
    GROUP BY o.id
    ORDER BY o.created_at DESC
');
$stmt->execute($params);
$orders = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <?php $pageTitle = 'Orders'; include '../../includes/head.php'; ?>
</head>
<body>
<?php include '../../includes/nav.php'; ?>

<div class="dash-layout">
  <?php include '../../includes/admin_sidebar.php'; ?>

  <main class="dash-main">
    <div class="dash-page-title">All Orders</div>
    <div class="dash-page-sub"><?= count($orders) ?> orders found</div>

    <!-- Search + status filter -->
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:20px;flex-wrap:wrap;">
      <form method="GET" style="flex:1;min-width:220px;margin:0;">
        <div class="search-bar-wrap" style="margin-bottom:0;">
          <input type="text" name="q" value="<?= sanitize($search) ?>"
                 placeholder="Search by order ID or customer..." class="form-control"
                 style="height:42px;">
          <span class="search-icon">
            <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                d="M21 21l-4.35-4.35m0 0A7.5 7.5 0 104.5 4.5a7.5 7.5 0 0012.15 12.15z"/>
            </svg>
          </span>
          <?php if ($statusFilter !== 'all'): ?>
            <input type="hidden" name="status" value="<?= $statusFilter ?>">
          <?php endif; ?>
        </div>
      </form>
      <div style="display:flex;gap:6px;flex-shrink:0;flex-wrap:nowrap;">
        <?php foreach (['all' => 'All', 'paid' => 'Paid', 'shipped' => 'Shipped',
                        'delivered' => 'Delivered', 'cancelled' => 'Cancelled'] as $k => $v): ?>
          <a href="?status=<?= $k ?><?= $search ? '&q=' . urlencode($search) : '' ?>"
             style="
               display:inline-flex;align-items:center;justify-content:center;
               height:42px;padding:0 18px;border-radius:6px;font-size:13px;font-weight:700;
               text-decoration:none;white-space:nowrap;transition:all .12s;
               <?= $statusFilter === $k
                 ? 'background:#111;color:#fff;border:1.5px solid #111;'
                 : 'background:#fff;color:#444;border:1.5px solid #ddd;' ?>
             ">
            <?= $v ?>
          </a>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- Orders table -->
    <div class="dash-table-card">
      <table class="dash-table">
        <thead>
          <tr>
            <th>Order ID</th>
            <th>Customer</th>
            <th>Products</th>
            <th>Total</th>
            <th>Status</th>
            <th>Date</th>
            <th>Update</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($orders)): ?>
            <tr>
              <td colspan="7" style="text-align:center;padding:40px;color:#888">No orders found.</td>
            </tr>
          <?php else: ?>
            <?php foreach ($orders as $o): ?>
              <tr>
                <td><?= sanitize($o['order_code']) ?></td>
                <td><?= sanitize($o['customer_name']) ?></td>
                <td style="max-width:200px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">
                  <?= sanitize($o['products'] ?? '') ?>
                </td>
                <td><?= formatPrice($o['total']) ?></td>
                <td><span class="badge badge-<?= $o['status'] ?>"><?= strtoupper($o['status']) ?></span></td>
                <td><?= date('M d, Y', strtotime($o['created_at'])) ?></td>
                <td>
                  <form method="POST" style="display:flex;gap:4px">
                    <input type="hidden" name="action"   value="update_status">
                    <input type="hidden" name="order_id" value="<?= $o['id'] ?>">
                    <select name="status" class="form-control"
                            style="width:110px;padding:4px 6px;font-size:12px">
                      <?php foreach (['paid', 'shipped', 'delivered', 'cancelled'] as $s): ?>
                        <option value="<?= $s ?>" <?= $o['status'] === $s ? 'selected' : '' ?>>
                          <?= ucfirst($s) ?>
                        </option>
                      <?php endforeach; ?>
                    </select>
                    <button type="submit" class="btn btn-sm btn-red">Set</button>
                  </form>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </main>
</div>
<?php include '../../includes/toast.php'; ?>
</body>
</html>
