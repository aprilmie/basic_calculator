<?php
// ── Admin – Dashboard ────────────────────────────────────────────────────────
session_start();
require_once '../../includes/config.php';

// Admins only
if (!isLoggedIn() || $_SESSION['role'] !== 'admin') redirect('/login.php');

$user = currentUser();
$db   = getDB();

// ── Platform-wide stats ───────────────────────────────────────────────────────
$totalUsers     = $db->query("SELECT COUNT(*) FROM users WHERE role != 'admin'")->fetchColumn();
$totalProducts  = $db->query('SELECT COUNT(*) FROM products')->fetchColumn();
$totalOrders    = $db->query('SELECT COUNT(*) FROM orders')->fetchColumn();
$totalRevenue   = $db->query("SELECT COALESCE(SUM(total),0) FROM orders WHERE status != 'cancelled'")->fetchColumn();

// ── Recent data ───────────────────────────────────────────────────────────────
$recentOrders = $db->query('
    SELECT o.order_code, u.full_name AS customer, o.total, o.status, o.created_at
    FROM orders o
    JOIN users u ON o.customer_id = u.id
    ORDER BY o.created_at DESC
    LIMIT 5
')->fetchAll();

$recentUsers = $db->query('
    SELECT full_name, email, role, status, created_at
    FROM users
    ORDER BY created_at DESC
    LIMIT 5
')->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <?php $pageTitle = 'Admin Dashboard'; include '../../includes/head.php'; ?>
</head>
<body>
<?php include '../../includes/nav.php'; ?>

<div class="dash-layout">
  <?php include '../../includes/admin_sidebar.php'; ?>

  <main class="dash-main">
    <div class="dash-page-title">Admin Overview</div>
    <div class="dash-page-sub">Platform-wide statistics and management.</div>

    <!-- Stat cards -->
    <div class="admin-stat-grid">
      <div class="admin-stat">
        <div class="num"><?= $totalUsers ?></div>
        <div class="lbl">Total Users</div>
      </div>
      <div class="admin-stat">
        <div class="num"><?= $totalProducts ?></div>
        <div class="lbl">Products</div>
      </div>
      <div class="admin-stat">
        <div class="num"><?= $totalOrders ?></div>
        <div class="lbl">Orders</div>
      </div>
      <div class="admin-stat">
        <div class="num"><?= formatPrice($totalRevenue) ?></div>
        <div class="lbl">Revenue</div>
      </div>
    </div>

    <!-- Recent orders + recent users side by side -->
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px">

      <div class="dash-table-card">
        <div class="dash-table-header">Recent Orders</div>
        <table class="dash-table">
          <thead>
            <tr><th>Order</th><th>Customer</th><th>Total</th><th>Status</th></tr>
          </thead>
          <tbody>
            <?php foreach ($recentOrders as $o): ?>
              <tr>
                <td><?= sanitize($o['order_code']) ?></td>
                <td><?= sanitize($o['customer']) ?></td>
                <td><?= formatPrice($o['total']) ?></td>
                <td><span class="badge badge-<?= $o['status'] ?>"><?= strtoupper($o['status']) ?></span></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>

      <div class="dash-table-card">
        <div class="dash-table-header">Recent Users</div>
        <table class="dash-table">
          <thead>
            <tr><th>Name</th><th>Role</th><th>Status</th></tr>
          </thead>
          <tbody>
            <?php foreach ($recentUsers as $u): ?>
              <tr>
                <td>
                  <strong><?= sanitize($u['full_name']) ?></strong><br>
                  <span style="font-size:12px;color:#888"><?= sanitize($u['email']) ?></span>
                </td>
                <td><span class="badge badge-<?= $u['role'] ?>"><?= strtoupper($u['role']) ?></span></td>
                <td><span class="badge badge-<?= $u['status'] ?>"><?= strtoupper($u['status']) ?></span></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>

    </div>
  </main>
</div>
<?php include '../../includes/toast.php'; ?>
</body>
</html>
