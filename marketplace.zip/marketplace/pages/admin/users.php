<?php
// ── Admin – User Management ──────────────────────────────────────────────────
session_start();
require_once '../../includes/config.php';

if (!isLoggedIn() || $_SESSION['role'] !== 'admin') redirect('/login.php');

$user = currentUser();
$db   = getDB();

// ── Ensure is_super_user column exists ───────────────────────────────────────
$cols = array_column($db->query("SHOW COLUMNS FROM users")->fetchAll(), 'Field');
if (!in_array('is_super_user', $cols)) {
    $db->exec("ALTER TABLE users ADD COLUMN is_super_user TINYINT(1) NOT NULL DEFAULT 0");
    $db->exec("UPDATE users SET is_super_user = 1 WHERE role = 'admin' ORDER BY id ASC LIMIT 1");
}

// ── Helper: is a given user the super user? ──────────────────────────────────
function isSuperUser(array $u): bool {
    return !empty($u['is_super_user']);
}

// ── Handle POST actions ───────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $uid    = (int) ($_POST['user_id'] ?? 0);

    // Fetch target user
    $target = $uid ? $db->prepare('SELECT * FROM users WHERE id = ?') : null;
    if ($target) { $target->execute([$uid]); $target = $target->fetch(); }

    // ── Add user ─────────────────────────────────────────────────────────────
    if ($action === 'add_user') {
        $name  = trim($_POST['full_name'] ?? '');
        $email = trim($_POST['email']     ?? '');
        $pass  = $_POST['password']       ?? '';
        $role  = $_POST['role']           ?? 'customer';
        if (!in_array($role, ['customer', 'seller', 'admin'])) $role = 'customer';

        $exists = $db->prepare('SELECT id FROM users WHERE email = ?');
        $exists->execute([$email]);
        if ($exists->fetch()) {
            setToast('error', 'Email already exists.');
        } elseif (strlen($pass) < 6) {
            setToast('error', 'Password must be at least 6 characters.');
        } else {
            $db->prepare('INSERT INTO users (full_name, email, password, role, verify_status) VALUES (?,?,?,?,1)')
               ->execute([$name, $email, password_hash($pass, PASSWORD_DEFAULT), $role]);
            setToast('success', 'User created successfully.');
        }
        redirect('/pages/admin/users.php');
    }

    // ── Edit user ────────────────────────────────────────────────────────────
    if ($action === 'edit_user' && $target) {
        // Super user name/email/role cannot be changed by others
        if (isSuperUser($target) && $target['id'] !== $user['id']) {
            setToast('error', 'Super Admin details cannot be modified.');
            redirect('/pages/admin/users.php');
        }
        $name  = trim($_POST['full_name'] ?? '');
        $email = trim($_POST['email']     ?? '');
        $role  = $_POST['role']           ?? $target['role'];
        $status= $_POST['status']         ?? $target['status'];
        if (!in_array($role,   ['customer','seller','admin']))         $role   = $target['role'];
        if (!in_array($status, ['active','inactive','banned']))        $status = $target['status'];

        // Prevent revoking super-user role
        if (isSuperUser($target)) { $role = 'admin'; $status = 'active'; }

        $db->prepare('UPDATE users SET full_name=?, email=?, role=?, status=? WHERE id=?')
           ->execute([$name, $email, $role, $status, $uid]);
        setToast('success', 'User updated.');
        redirect('/pages/admin/users.php');
    }

    // ── Reset password ───────────────────────────────────────────────────────
    if ($action === 'reset_password' && $target) {
        $newpass = $_POST['new_password'] ?? '';
        if (strlen($newpass) < 6) {
            setToast('error', 'Password must be at least 6 characters.');
        } else {
            $db->prepare('UPDATE users SET password = ? WHERE id = ?')
               ->execute([password_hash($newpass, PASSWORD_DEFAULT), $uid]);
            setToast('success', 'Password reset for ' . $target['full_name'] . '.');
        }
        redirect('/pages/admin/users.php');
    }

    // ── Delete user ──────────────────────────────────────────────────────────
    if ($action === 'delete_user' && $target) {
        if (isSuperUser($target)) {
            setToast('error', 'Super Admin cannot be deleted.');
            redirect('/pages/admin/users.php');
        }
        if ($uid === $user['id']) {
            setToast('error', 'You cannot delete your own account.');
            redirect('/pages/admin/users.php');
        }
        // Cascade clean
        $db->prepare('DELETE FROM cart          WHERE user_id = ?')->execute([$uid]);
        $db->prepare('DELETE FROM notifications WHERE user_id = ?')->execute([$uid]);
        $oids = $db->prepare('SELECT id FROM orders WHERE customer_id = ?');
        $oids->execute([$uid]);
        foreach ($oids->fetchAll(PDO::FETCH_COLUMN) as $oid) {
            $db->prepare('DELETE FROM order_items WHERE order_id = ?')->execute([$oid]);
        }
        $db->prepare('DELETE FROM orders WHERE customer_id = ?')->execute([$uid]);
        $pids = $db->prepare('SELECT id FROM products WHERE seller_id = ?');
        $pids->execute([$uid]);
        foreach ($pids->fetchAll(PDO::FETCH_COLUMN) as $pid) {
            $db->prepare('DELETE FROM cart        WHERE product_id = ?')->execute([$pid]);
            $db->prepare('DELETE FROM order_items WHERE product_id = ?')->execute([$pid]);
        }
        $db->prepare('DELETE FROM products WHERE seller_id = ?')->execute([$uid]);
        $db->prepare('DELETE FROM users WHERE id = ?')->execute([$uid]);
        setToast('success', 'User deleted.');
        redirect('/pages/admin/users.php');
    }
}

// ── Search & filter ───────────────────────────────────────────────────────────
$search     = trim($_GET['q']    ?? '');
$roleFilter = $_GET['role']      ?? 'all';

$where  = ['1=1'];
$params = [];
if ($search) {
    $where[]  = '(full_name LIKE ? OR email LIKE ?)';
    $params[] = "%$search%";
    $params[] = "%$search%";
}
if ($roleFilter !== 'all') {
    $where[]  = 'role = ?';
    $params[] = $roleFilter;
}

$stmt = $db->prepare('SELECT * FROM users WHERE ' . implode(' AND ', $where) . ' ORDER BY is_super_user DESC, created_at DESC');
$stmt->execute($params);
$users = $stmt->fetchAll();

// Edit target (for pre-filling modal)
$editTarget = null;
if (!empty($_GET['edit'])) {
    $es = $db->prepare('SELECT * FROM users WHERE id = ?');
    $es->execute([(int)$_GET['edit']]);
    $editTarget = $es->fetch() ?: null;
}
$resetTarget = null;
if (!empty($_GET['reset'])) {
    $rs = $db->prepare('SELECT id, full_name FROM users WHERE id = ?');
    $rs->execute([(int)$_GET['reset']]);
    $resetTarget = $rs->fetch() ?: null;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <?php $pageTitle = 'User Management'; include '../../includes/head.php'; ?>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.all.min.js"></script>
  <style>
    /* Modal */
    .modal-overlay {
      display: none; position: fixed; inset: 0;
      background: rgba(0,0,0,.45); z-index: 1000;
      align-items: center; justify-content: center; padding: 16px;
    }
    .modal-overlay.open { display: flex; }
    .modal-box {
      background: #fff; border-radius: 14px;
      padding: 30px 28px 24px; width: 100%; max-width: 480px;
      max-height: 92vh; overflow-y: auto;
      box-shadow: 0 20px 60px rgba(0,0,0,.25);
      animation: modalIn .25s ease both;
    }
    @keyframes modalIn { from { opacity:0; transform:translateY(14px); } to { opacity:1; transform:translateY(0); } }
    .modal-title { font-size: 20px; font-weight: 800; color: #111; margin-bottom: 20px; }
    .modal-close {
      float: right; background: none; border: none;
      font-size: 22px; color: #aaa; cursor: pointer; line-height: 1;
      margin-top: -4px;
    }
    .modal-close:hover { color: #e01010; }
    .form-group  { margin-bottom: 14px; }
    .form-label  { display: block; font-size: 11px; font-weight: 700; letter-spacing: 1px; text-transform: uppercase; color: #888; margin-bottom: 5px; }
    .form-control {
      width: 100%; padding: 10px 13px; border: 1.5px solid #ddd;
      border-radius: 8px; font-size: 14px; color: #333; background: #fff;
      box-sizing: border-box; font-family: inherit; transition: border-color .15s;
    }
    .form-control:focus { outline: none; border-color: #e01010; }
    .form-control[readonly] { background: #f9f9f9; color: #aaa; cursor: not-allowed; }
    .form-grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
    .modal-footer { display: flex; gap: 10px; justify-content: flex-end; margin-top: 18px; }
    .btn-modal-cancel {
      padding: 10px 20px; background: #f0f0f0; color: #555;
      border: none; border-radius: 8px; cursor: pointer; font-weight: 600; font-size: 14px;
    }
    .btn-modal-cancel:hover { background: #e0e0e0; }
    .btn-modal-submit {
      padding: 10px 22px; border: none; border-radius: 8px;
      cursor: pointer; font-weight: 800; font-size: 14px; color: #fff;
      background: #e01010; transition: background .15s;
    }
    .btn-modal-submit:hover { background: #c00; }
    .btn-modal-dark { background: #222; }
    .btn-modal-dark:hover { background: #444; }

    /* Password eye in modal */
    .pw-wrap { position: relative; }
    .pw-wrap .form-control { padding-right: 42px; }
    .pw-eye {
      position: absolute; right: 11px; top: 50%;
      transform: translateY(-50%); background: none;
      border: none; cursor: pointer; color: #bbb; padding: 0;
      display: flex; align-items: center; transition: color .15s;
    }
    .pw-eye:hover { color: #e01010; }
    .eye-icon { width: 17px; height: 17px; stroke: currentColor; stroke-width: 2; stroke-linecap: round; stroke-linejoin: round; fill: none; }

    /* Table */
    .user-avatar-sm {
      width: 38px; height: 38px; border-radius: 50%;
      object-fit: cover; border: 2px solid #eee; flex-shrink: 0;
    }
    .super-row { background: #fffbea !important; }
    .super-crown { color: #e8a020; font-size: 14px; margin-left: 4px; }
    .badge-super-sm {
      display: inline-block; background: #e8a020; color: #fff;
      font-size: 10px; font-weight: 800; padding: 2px 8px;
      border-radius: 20px; letter-spacing: .5px;
    }
  </style>
</head>
<body>
<?php include '../../includes/nav.php'; ?>

<div class="dash-layout">
  <?php include '../../includes/admin_sidebar.php'; ?>

  <main class="dash-main">
    <div class="section-header">
      <div>
        <div class="dash-page-title">User Management</div>
        <div class="dash-page-sub"><?= count($users) ?> user<?= count($users) !== 1 ? 's' : '' ?> found
          <span style="color:#e8a020;font-size:12px;font-weight:700;margin-left:8px;">⭐ Super Admin cannot be deleted</span>
        </div>
      </div>
      <button class="btn btn-red" onclick="openModal('addModal')">+ Add User</button>
    </div>

    <!-- Search + filter -->
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:20px;flex-wrap:wrap;">
      <form method="GET" style="flex:1;min-width:220px;margin:0;">
        <div class="search-bar-wrap" style="margin-bottom:0;">
          <input type="text" name="q" value="<?= sanitize($search) ?>"
                 placeholder="Search users..." class="form-control" style="height:42px;">
          <span class="search-icon">
            <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                d="M21 21l-4.35-4.35m0 0A7.5 7.5 0 104.5 4.5a7.5 7.5 0 0012.15 12.15z"/>
            </svg>
          </span>
          <?php if ($roleFilter !== 'all'): ?>
            <input type="hidden" name="role" value="<?= $roleFilter ?>">
          <?php endif; ?>
        </div>
      </form>
      <div style="display:flex;gap:6px;flex-shrink:0;flex-wrap:nowrap;">
        <?php foreach (['all'=>'All','customer'=>'Customers','seller'=>'Sellers','admin'=>'Admins'] as $k=>$v): ?>
          <a href="?role=<?= $k ?><?= $search ? '&q='.urlencode($search) : '' ?>"
             style="display:inline-flex;align-items:center;justify-content:center;height:42px;padding:0 18px;border-radius:6px;font-size:13px;font-weight:700;text-decoration:none;white-space:nowrap;transition:all .12s;<?= $roleFilter===$k ? 'background:#111;color:#fff;border:1.5px solid #111;' : 'background:#fff;color:#444;border:1.5px solid #ddd;' ?>">
            <?= $v ?>
          </a>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- Users table -->
    <div class="dash-table-card">
      <table class="dash-table">
        <thead>
          <tr>
            <th>User</th>
            <th>Role</th>
            <th>Status</th>
            <th>Joined</th>
            <th style="text-align:right;padding-right:20px;">Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($users)): ?>
            <tr><td colspan="5" style="text-align:center;padding:40px;color:#888">No users found.</td></tr>
          <?php else: ?>
            <?php foreach ($users as $u):
              $isSuper = isSuperUser($u);
              $isMe    = $u['id'] === $user['id'];
              $avatarUrl = !empty($u['avatar'])
                ? BASE_URL . '/' . $u['avatar']
                : 'https://ui-avatars.com/api/?name=' . urlencode($u['full_name']) . '&background=' . ($isSuper ? 'e8a020' : 'e01010') . '&color=fff&size=80&bold=true&format=png';
            ?>
            <tr class="<?= $isSuper ? 'super-row' : '' ?>">
              <td>
                <div style="display:flex;align-items:center;gap:10px;">
                  <img src="<?= $isSuper ? BASE_URL.'/uploads/avatars/super_admin_avatar.jpg' : $avatarUrl ?>"
                       class="user-avatar-sm" alt="avatar"
                       onerror="this.src='<?= $avatarUrl ?>'">
                  <div>
                    <div style="font-weight:700;font-size:14px;color:#111;">
                      <?= sanitize($u['full_name']) ?>
                      <?php if ($isSuper): ?><span class="super-crown" title="Super Admin">⭐</span><?php endif; ?>
                      <?php if ($isMe): ?><span style="font-size:11px;color:#aaa;">(you)</span><?php endif; ?>
                    </div>
                    <div style="font-size:12px;color:#999;"><?= sanitize($u['email']) ?></div>
                    <?php if ($isSuper): ?><span class="badge-super-sm">SUPER ADMIN</span><?php endif; ?>
                  </div>
                </div>
              </td>
              <td><span class="badge badge-<?= $u['role'] ?>"><?= strtoupper($u['role']) ?></span></td>
              <td><span class="badge badge-<?= $u['status'] ?>"><?= strtoupper($u['status']) ?></span></td>
              <td style="font-size:13px;color:#666;"><?= date('M d, Y', strtotime($u['created_at'])) ?></td>
              <td style="padding-right:16px;">
                <div style="display:flex;gap:6px;justify-content:flex-end;flex-wrap:wrap;">

                  <?php if (!$isSuper): ?>
                    <!-- Edit -->
                    <a href="?edit=<?= $u['id'] ?><?= $search?'&q='.urlencode($search):'' ?><?= $roleFilter!=='all'?'&role='.$roleFilter:'' ?>"
                       class="btn btn-sm" style="background:#17a2b8;color:#fff;border:none;text-decoration:none;">✏ Edit</a>
                  <?php endif; ?>

                  <!-- Reset Password -->
                  <a href="?reset=<?= $u['id'] ?><?= $search?'&q='.urlencode($search):'' ?><?= $roleFilter!=='all'?'&role='.$roleFilter:'' ?>"
                     class="btn btn-sm" style="background:#6c757d;color:#fff;border:none;text-decoration:none;">🔑 Reset</a>

                  <!-- Delete -->
                  <?php if (!$isSuper && !$isMe): ?>
                    <button class="btn btn-sm" style="background:#fee2e2;color:#991b1b;border:none;"
                            onclick="confirmDelete(<?= $u['id'] ?>, '<?= addslashes(sanitize($u['full_name'])) ?>')">
                      🗑 Delete
                    </button>
                    <form id="del-form-<?= $u['id'] ?>" method="POST" style="display:none;">
                      <input type="hidden" name="action"  value="delete_user">
                      <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                    </form>
                  <?php elseif ($isSuper): ?>
                    <span class="btn btn-sm" style="background:#f5f5f5;color:#ccc;cursor:not-allowed;border:none;"
                          title="Super Admin cannot be deleted">🗑</span>
                  <?php endif; ?>

                </div>
              </td>
            </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </main>
</div>

<!-- ── ADD USER MODAL ──────────────────────────────────────────────────────── -->
<div class="modal-overlay" id="addModal" onclick="if(event.target===this)closeModal('addModal')">
  <div class="modal-box">
    <button class="modal-close" onclick="closeModal('addModal')">&times;</button>
    <div class="modal-title">➕ Add New User</div>
    <form method="POST">
      <input type="hidden" name="action" value="add_user">
      <div class="form-grid-2">
        <div class="form-group" style="grid-column:span 2;">
          <label class="form-label">Full Name</label>
          <input type="text" name="full_name" class="form-control" placeholder="Juan Dela Cruz" required>
        </div>
        <div class="form-group" style="grid-column:span 2;">
          <label class="form-label">Email</label>
          <input type="email" name="email" class="form-control" placeholder="user@email.com" required>
        </div>
        <div class="form-group" style="grid-column:span 2;">
          <label class="form-label">Password <span style="color:#bbb;font-weight:400;">(min 6 chars)</span></label>
          <div class="pw-wrap">
            <input type="password" name="password" id="add-pw" class="form-control" placeholder="••••••••" minlength="6" required>
            <button type="button" class="pw-eye" onclick="togglePw('add-pw',this)" tabindex="-1">
              <svg class="eye-icon eye-off" viewBox="0 0 24 24"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>
              <svg class="eye-icon eye-on" viewBox="0 0 24 24" style="display:none"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
            </button>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Role</label>
          <select name="role" class="form-control">
            <option value="customer">Customer</option>
            <option value="seller">Seller</option>
            <option value="admin">Admin</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Status</label>
          <select name="status" class="form-control">
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
            <option value="banned">Banned</option>
          </select>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn-modal-cancel" onclick="closeModal('addModal')">Cancel</button>
        <button type="submit" class="btn-modal-submit">Create User</button>
      </div>
    </form>
  </div>
</div>

<!-- ── EDIT USER MODAL ─────────────────────────────────────────────────────── -->
<?php if ($editTarget && !isSuperUser($editTarget)): ?>
<div class="modal-overlay open" id="editModal" onclick="if(event.target===this)window.location='users.php'">
  <div class="modal-box">
    <button class="modal-close" onclick="window.location='users.php'">&times;</button>
    <div class="modal-title">✏️ Edit User</div>
    <form method="POST">
      <input type="hidden" name="action"  value="edit_user">
      <input type="hidden" name="user_id" value="<?= $editTarget['id'] ?>">
      <div class="form-grid-2">
        <div class="form-group" style="grid-column:span 2;">
          <label class="form-label">Full Name</label>
          <input type="text" name="full_name" class="form-control"
                 value="<?= sanitize($editTarget['full_name']) ?>" required>
        </div>
        <div class="form-group" style="grid-column:span 2;">
          <label class="form-label">Email</label>
          <input type="email" name="email" class="form-control"
                 value="<?= sanitize($editTarget['email']) ?>" required>
        </div>
        <div class="form-group">
          <label class="form-label">Role</label>
          <select name="role" class="form-control">
            <?php foreach (['customer','seller','admin'] as $r): ?>
              <option value="<?= $r ?>" <?= $editTarget['role']===$r?'selected':'' ?>><?= ucfirst($r) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Status</label>
          <select name="status" class="form-control">
            <?php foreach (['active','inactive','banned'] as $s): ?>
              <option value="<?= $s ?>" <?= $editTarget['status']===$s?'selected':'' ?>><?= ucfirst($s) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>
      <div class="modal-footer">
        <a href="users.php" class="btn-modal-cancel" style="text-decoration:none;display:inline-flex;align-items:center;">Cancel</a>
        <button type="submit" class="btn-modal-submit">Save Changes</button>
      </div>
    </form>
  </div>
</div>
<?php endif; ?>

<!-- ── RESET PASSWORD MODAL ───────────────────────────────────────────────── -->
<?php if ($resetTarget): ?>
<div class="modal-overlay open" id="resetModal" onclick="if(event.target===this)window.location='users.php'">
  <div class="modal-box" style="max-width:400px;">
    <button class="modal-close" onclick="window.location='users.php'">&times;</button>
    <div class="modal-title">🔑 Reset Password</div>
    <p style="margin:0 0 18px;font-size:14px;color:#555;">
      Resetting password for <strong><?= sanitize($resetTarget['full_name']) ?></strong>.
    </p>
    <form method="POST">
      <input type="hidden" name="action"  value="reset_password">
      <input type="hidden" name="user_id" value="<?= $resetTarget['id'] ?>">
      <div class="form-group">
        <label class="form-label">New Password <span style="color:#bbb;font-weight:400;">(min 6 chars)</span></label>
        <div class="pw-wrap">
          <input type="password" name="new_password" id="rst-pw" class="form-control"
                 placeholder="••••••••" minlength="6" required autofocus>
          <button type="button" class="pw-eye" onclick="togglePw('rst-pw',this)" tabindex="-1">
            <svg class="eye-icon eye-off" viewBox="0 0 24 24"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>
            <svg class="eye-icon eye-on" viewBox="0 0 24 24" style="display:none"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
          </button>
        </div>
      </div>
      <div class="modal-footer">
        <a href="users.php" class="btn-modal-cancel" style="text-decoration:none;display:inline-flex;align-items:center;">Cancel</a>
        <button type="submit" class="btn-modal-submit btn-modal-dark">Reset Password</button>
      </div>
    </form>
  </div>
</div>
<?php endif; ?>

<script>
  function openModal(id)  { document.getElementById(id).classList.add('open'); }
  function closeModal(id) { document.getElementById(id).classList.remove('open'); }

  function confirmDelete(uid, name) {
    Swal.fire({
      title: 'Delete User?',
      html: 'Are you sure you want to permanently delete <strong>' + name + '</strong>?<br><small style="color:#aaa;">This cannot be undone.</small>',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#e01010',
      cancelButtonColor: '#6c757d',
      confirmButtonText: 'Yes, Delete',
      cancelButtonText: 'Cancel',
    }).then(result => {
      if (result.isConfirmed) document.getElementById('del-form-' + uid).submit();
    });
  }

  function togglePw(id, btn) {
    const inp = document.getElementById(id);
    const show = inp.type === 'password';
    inp.type = show ? 'text' : 'password';
    btn.querySelector('.eye-off').style.display = show ? 'none' : '';
    btn.querySelector('.eye-on').style.display  = show ? ''     : 'none';
    btn.style.color = show ? '#e01010' : '#bbb';
  }
</script>
<?php include '../../includes/toast.php'; ?>
</body>
</html>
