<?php
// ── Admin – My Profile ───────────────────────────────────────────────────────
session_start();
require_once '../../includes/config.php';

if (!isLoggedIn() || $_SESSION['role'] !== 'admin') redirect('/login.php');

$user = currentUser();
$db   = getDB();

// ── Ensure is_super_user column exists ────────────────────────────────────────
$cols = array_column($db->query("SHOW COLUMNS FROM users")->fetchAll(), 'Field');
if (!in_array('is_super_user', $cols)) {
    $db->exec("ALTER TABLE users ADD COLUMN is_super_user TINYINT(1) NOT NULL DEFAULT 0");
    // Mark the very first admin as super user
    $db->exec("UPDATE users SET is_super_user = 1 WHERE role = 'admin' ORDER BY id ASC LIMIT 1");
}

$isSuperUser = !empty($user['is_super_user']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // Super users: avatar is LOCKED — no upload allowed
    if ($action === 'update_profile') {
        $db->prepare('UPDATE users SET full_name=?, phone=?, address=?, bio=? WHERE id=?')
           ->execute([
               trim($_POST['full_name'] ?? ''),
               trim($_POST['phone']     ?? ''),
               trim($_POST['address']   ?? ''),
               trim($_POST['bio']       ?? ''),
               $user['id'],
           ]);
        setToast('success', 'Profile updated.');
        redirect('/pages/admin/profile.php');
    }

    if ($action === 'change_password') {
        $current = $_POST['current_password'] ?? '';
        $new     = $_POST['new_password']     ?? '';
        $confirm = $_POST['confirm_password'] ?? '';

        if (!password_verify($current, $user['password'])) {
            setToast('error', 'Current password incorrect.');
        } elseif (strlen($new) < 6) {
            setToast('error', 'New password must be at least 6 characters.');
        } elseif ($new !== $confirm) {
            setToast('error', 'Passwords do not match.');
        } else {
            $db->prepare('UPDATE users SET password = ? WHERE id = ?')
               ->execute([password_hash($new, PASSWORD_DEFAULT), $user['id']]);
            setToast('success', 'Password updated.');
        }
        redirect('/pages/admin/profile.php');
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <?php $pageTitle = 'My Profile'; include '../../includes/head.php'; ?>
  <style>
    .profile-grid {
      display: grid;
      grid-template-columns: 300px 1fr;
      gap: 20px;
      align-items: start;
    }
    .profile-card {
      background: #fff;
      border: 1px solid #ddd;
      border-radius: 14px;
      padding: 32px 24px 24px;
      text-align: center;
    }
    .profile-avatar {
      width: 120px; height: 120px;
      border-radius: 50%;
      margin: 0 auto 14px;
      overflow: hidden;
      border: 3px solid #e01010;
      box-shadow: 0 4px 18px rgba(224,16,16,.18);
    }
    .profile-avatar img { width: 100%; height: 100%; object-fit: cover; display: block; }
    .locked-badge {
      display: inline-flex; align-items: center; gap: 5px;
      font-size: 11px; font-weight: 700; color: #888;
      background: #f5f5f5; border: 1px solid #e0e0e0;
      border-radius: 20px; padding: 4px 12px; margin-bottom: 12px;
    }
    .profile-name  { font-size: 20px; font-weight: 800; margin-bottom: 2px; color: #111; }
    .profile-email { font-size: 13px; color: #999; margin-bottom: 10px; }
    .badge-super {
      display: inline-block;
      background: linear-gradient(135deg, #e01010, #a00);
      color: #fff;
      font-size: 11px; font-weight: 800;
      letter-spacing: 1px; text-transform: uppercase;
      padding: 5px 18px; border-radius: 6px;
    }
    .profile-divider { border: none; border-top: 1px solid #e8e3e0; margin: 18px 0; }
    .account-info-card {
      background: #fff; border: 1px solid #ddd;
      border-radius: 14px; padding: 20px 24px;
      margin-top: 16px; text-align: left;
    }
    .account-info-title {
      font-size: 11px; font-weight: 700;
      letter-spacing: 1.2px; text-transform: uppercase;
      color: #aaa; margin-bottom: 14px;
    }
    .info-row {
      display: flex; justify-content: space-between;
      align-items: center; font-size: 14px;
      margin-bottom: 10px; color: #333;
    }
    .form-card {
      background: #fff; border: 1px solid #ddd;
      border-radius: 14px; padding: 28px 28px 32px;
      margin-bottom: 20px;
    }
    .form-card-title { font-size: 22px; font-weight: 800; margin-bottom: 22px; color: #111; }
    .form-grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
    .form-group { margin-bottom: 16px; }
    .form-label {
      display: block; font-size: 11px; font-weight: 700;
      letter-spacing: 1px; text-transform: uppercase;
      color: #888; margin-bottom: 6px;
    }
    .form-control {
      width: 100%; padding: 11px 14px;
      border: 1.5px solid #ddd; border-radius: 8px;
      font-size: 14px; color: #333; background: #fff;
      box-sizing: border-box; transition: border-color .15s; font-family: inherit;
    }
    .form-control:focus { outline: none; border-color: #e01010; }
    .form-control[readonly] { background: #f9f9f9; color: #aaa; cursor: not-allowed; }
    .btn-red-profile {
      background: #e01010; color: #fff; border: none;
      padding: 13px 28px; font-size: 13px; font-weight: 800;
      letter-spacing: 1px; text-transform: uppercase;
      border-radius: 8px; cursor: pointer; transition: background .15s;
    }
    .btn-red-profile:hover { background: #c00; }
    .btn-dark-profile {
      background: #222; color: #fff; border: none;
      padding: 13px 28px; font-size: 13px; font-weight: 800;
      letter-spacing: 1px; text-transform: uppercase;
      border-radius: 8px; cursor: pointer; transition: background .15s;
    }
    .btn-dark-profile:hover { background: #444; }
    .pw-wrap { position: relative; }
    .pw-wrap .form-control { padding-right: 42px; }
    .pw-eye {
      position: absolute; right: 12px; top: 50%;
      transform: translateY(-50%); background: none;
      border: none; cursor: pointer; color: #bbb; padding: 0;
      display: flex; align-items: center; transition: color .15s;
    }
    .pw-eye:hover { color: #e01010; }
    .eye-icon { width: 18px; height: 18px; stroke: currentColor; stroke-width: 2; stroke-linecap: round; stroke-linejoin: round; fill: none; }
    .profile-divider { border: none; border-top: 1px solid #e8e3e0; margin: 18px 0; }
    .admin-about { text-align: left; }
    .admin-about-title {
      font-size: 11px; font-weight: 700; letter-spacing: 1.2px;
      text-transform: uppercase; color: #aaa; margin-bottom: 12px;
    }
    .admin-about-row {
      display: flex; flex-direction: column;
      margin-bottom: 10px;
    }
    .admin-about-label {
      font-size: 10px; font-weight: 700; letter-spacing: .8px;
      text-transform: uppercase; color: #bbb; margin-bottom: 2px;
    }
    .admin-about-value { font-size: 13px; color: #333; font-weight: 600; }
    @media (max-width: 768px) {
      .profile-grid { grid-template-columns: 1fr; }
      .form-grid-2  { grid-template-columns: 1fr; }
    }
  </style>
</head>
<body>
<?php include '../../includes/nav.php'; ?>

<div class="dash-layout">
  <?php include '../../includes/admin_sidebar.php'; ?>

  <main class="dash-main">
    <div class="dash-page-title">My Profile</div>
    <div class="dash-page-sub">Manage your admin account.</div>

    <div class="profile-grid">

      <!-- Left column -->
      <div>
        <div class="profile-card">

          <!-- Fixed avatar — cannot be changed for super user -->
          <div class="profile-avatar">
            <img src="<?= BASE_URL ?>/uploads/avatars/super_admin_avatar.jpg" alt="Admin Avatar"
                 onerror="this.src='<?= BASE_URL ?>/uploads/avatars/super_admin_avatar.jpg'">
          </div>

          <!-- Lock indicator -->
          <div class="locked-badge">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
            Photo Locked
          </div>

          <div class="profile-name"><?= sanitize($user['full_name']) ?></div>
          <div class="profile-email"><?= sanitize($user['email']) ?></div>
          <div><span class="badge-super">⭐ Super Admin</span></div>

          <hr class="profile-divider">

          <div class="admin-about">
            <div class="admin-about-title">About</div>
            <div class="admin-about-row">
              <span class="admin-about-label">Full Name</span>
              <span class="admin-about-value">April Mie L. Anteniero</span>
            </div>
            <div class="admin-about-row">
              <span class="admin-about-label">Course</span>
              <span class="admin-about-value">Bachelor of Science Information Technology</span>
            </div>
            <div class="admin-about-row">
              <span class="admin-about-label">Year</span>
              <span class="admin-about-value">3rd Year</span>
            </div>
          </div>
        </div>

        <!-- Account Info -->
        <div class="account-info-card">
          <div class="account-info-title">Account Info</div>
          <div class="info-row">
            <span style="color:#555">Role</span>
            <span class="badge-super" style="padding:3px 12px;font-size:10px;">ADMIN</span>
          </div>
          <div class="info-row">
            <span style="color:#555">Super User</span>
            <span style="font-weight:700;color:#e01010;">✔ Protected</span>
          </div>
          <div class="info-row">
            <span style="color:#555">Since</span>
            <span style="font-weight:600"><?= date('M Y', strtotime($user['created_at'])) ?></span>
          </div>
          <div class="info-row">
            <span style="color:#555">Status</span>
            <span style="font-weight:600;color:#16a34a;">ACTIVE</span>
          </div>
        </div>
      </div>

      <!-- Right column -->
      <div>
        <div class="form-card">
          <div class="form-card-title">Personal Information</div>
          <form method="POST">
            <input type="hidden" name="action" value="update_profile">
            <div class="form-grid-2">
              <div class="form-group">
                <label class="form-label">Full Name</label>
                <input type="text" name="full_name" class="form-control"
                       value="<?= sanitize($user['full_name']) ?>" required>
              </div>
              <div class="form-group">
                <label class="form-label">Email</label>
                <!-- Email locked for super user -->
                <input type="email" class="form-control"
                       value="<?= sanitize($user['email']) ?>" readonly>
                <small style="color:#bbb;font-size:11px;">Email cannot be changed for Super Admin.</small>
              </div>
              <div class="form-group">
                <label class="form-label">Phone</label>
                <input type="text" name="phone" class="form-control"
                       value="<?= sanitize($user['phone'] ?? '') ?>">
              </div>
              <div class="form-group">
                <label class="form-label">Address</label>
                <input type="text" name="address" class="form-control"
                       value="<?= sanitize($user['address'] ?? '') ?>">
              </div>
            </div>
            <div class="form-group">
              <label class="form-label">Bio</label>
              <textarea name="bio" class="form-control" rows="3"
                        placeholder="Tell us about yourself..."><?= sanitize($user['bio'] ?? '') ?></textarea>
            </div>
            <button type="submit" class="btn-red-profile">SAVE CHANGES</button>
          </form>
        </div>

        <div class="form-card">
          <div class="form-card-title">Change Password</div>
          <form method="POST">
            <input type="hidden" name="action" value="change_password">
            <div class="form-group">
              <label class="form-label">Current Password</label>
              <div class="pw-wrap">
                <input type="password" name="current_password" id="pw-cur" class="form-control" placeholder="••••••••">
                <button type="button" class="pw-eye" onclick="togglePw('pw-cur',this)" tabindex="-1">
                  <svg class="eye-icon eye-off" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>
                  <svg class="eye-icon eye-on" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" style="display:none"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                </button>
              </div>
            </div>
            <div class="form-grid-2">
              <div class="form-group">
                <label class="form-label">New Password</label>
                <div class="pw-wrap">
                  <input type="password" name="new_password" id="pw-new" class="form-control" placeholder="••••••••" minlength="6">
                  <button type="button" class="pw-eye" onclick="togglePw('pw-new',this)" tabindex="-1">
                    <svg class="eye-icon eye-off" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>
                    <svg class="eye-icon eye-on" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" style="display:none"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                  </button>
                </div>
              </div>
              <div class="form-group">
                <label class="form-label">Confirm Password</label>
                <div class="pw-wrap">
                  <input type="password" name="confirm_password" id="pw-con" class="form-control" placeholder="••••••••">
                  <button type="button" class="pw-eye" onclick="togglePw('pw-con',this)" tabindex="-1">
                    <svg class="eye-icon eye-off" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>
                    <svg class="eye-icon eye-on" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" style="display:none"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                  </button>
                </div>
              </div>
            </div>
            <button type="submit" class="btn-dark-profile">UPDATE PASSWORD</button>
          </form>
        </div>
      </div>

    </div>
  </main>
</div>

<script>
function togglePw(id, btn) {
  const inp = document.getElementById(id);
  const show = inp.type === 'password';
  inp.type = show ? 'text' : 'password';
  btn.querySelector('.eye-off').style.display = show ? 'none' : '';
  btn.querySelector('.eye-on').style.display  = show ? ''     : 'none';
  btn.style.color = show ? '#e01010' : '#bbb';
}
</script>
<?php include '../../includes/toast.php'; ?>
</body>
</html>
