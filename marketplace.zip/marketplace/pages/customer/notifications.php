<?php
// ── Customer – Notifications ─────────────────────────────────────────────────
session_start();
require_once '../../includes/config.php';
requireRole('customer');

$user = currentUser();
$db   = getDB();

// Mark all as read the moment the page is opened
$db->prepare('UPDATE notifications SET is_read = 1 WHERE user_id = ?')
   ->execute([$user['id']]);

// Handle "dismiss" (delete) a single notification
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['dismiss'])) {
    $db->prepare('DELETE FROM notifications WHERE id = ? AND user_id = ?')
       ->execute([(int) $_POST['dismiss'], $user['id']]);
    setToast('info', 'Notification dismissed.');
    redirect('/pages/customer/notifications.php');
}

// Filter support
$allowed = ['all', 'unread', 'order', 'review', 'promo', 'system'];
$filter  = in_array($_GET['filter'] ?? '', $allowed) ? $_GET['filter'] : 'all';

// Build the notification query based on the active filter
if ($filter === 'all') {
    $stmt = $db->prepare('SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC');
    $stmt->execute([$user['id']]);
} elseif ($filter === 'unread') {
    $stmt = $db->prepare('SELECT * FROM notifications WHERE user_id = ? AND is_read = 0 ORDER BY created_at DESC');
    $stmt->execute([$user['id']]);
} else {
    $stmt = $db->prepare('SELECT * FROM notifications WHERE user_id = ? AND type = ? ORDER BY created_at DESC');
    $stmt->execute([$user['id'], $filter]);
}
$notifs = $stmt->fetchAll();

// Helper: convert a datetime string to "5m ago / 3h ago / 2d ago"
function timeAgo(string $datetime): string
{
    $diff = time() - strtotime($datetime);
    if ($diff < 3600)  return round($diff / 60)    . 'm ago';
    if ($diff < 86400) return round($diff / 3600)  . 'h ago';
    return round($diff / 86400) . 'd ago';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <?php $pageTitle = 'Notifications'; include '../../includes/head.php'; ?>
</head>
<body>
<?php include '../../includes/nav.php'; ?>

<div class="dash-layout">
  <?php include '../../includes/customer_sidebar.php'; ?>

  <main class="dash-main">
    <div class="dash-page-title">Notifications</div>
    <div class="dash-page-sub"><?= count($notifs) ?> notification(s)</div>

    <!-- Filter tabs -->
    <div class="notif-filters">
      <?php foreach (['all' => 'All', 'unread' => 'Unread', 'order' => 'Orders',
                      'review' => 'Reviews', 'promo' => 'Promos', 'system' => 'System'] as $k => $v): ?>
        <a href="?filter=<?= $k ?>"
           class="notif-filter <?= $filter === $k ? 'active' : '' ?>">
          <?= $v ?>
        </a>
      <?php endforeach; ?>
    </div>

    <!-- Notification list -->
    <div class="notif-list">
      <?php if (empty($notifs)): ?>
        <div class="empty-state"><p>No notifications.</p></div>
      <?php else: ?>
        <?php foreach ($notifs as $n): ?>
          <div class="notif-item">

            <!-- Icon varies by notification type -->
            <div class="notif-icon">
              <?php if ($n['type'] === 'order'): ?>
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="24" height="24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"
                    d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 10V11"/>
                </svg>
              <?php elseif ($n['type'] === 'review'): ?>
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="24" height="24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"
                    d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915
                       c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674
                       c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888
                       c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888
                       c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"/>
                </svg>
              <?php else: ?>
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="24" height="24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"
                    d="M5 13l4 4L19 7"/>
                </svg>
              <?php endif; ?>
            </div>

            <!-- Message + meta -->
            <div class="notif-text">
              <div class="notif-msg"><?= sanitize($n['message']) ?></div>
              <div class="notif-meta">
                <span class="badge badge-<?= $n['type'] ?>"><?= ucfirst($n['type']) ?></span>
                <span class="notif-time"><?= timeAgo($n['created_at']) ?></span>
              </div>
            </div>

            <!-- Dismiss button -->
            <form method="POST" style="position:absolute;top:14px;right:14px">
              <input type="hidden" name="dismiss" value="<?= $n['id'] ?>">
              <button type="submit" class="notif-close">&times;</button>
            </form>

          </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>
  </main>
</div>
<?php include '../../includes/toast.php'; ?>
</body>
</html>
