<?php
// ── Customer – Cart ──────────────────────────────────────────────────────────
session_start();
require_once '../../includes/config.php';
requireRole('customer');

$user = currentUser();
$db   = getDB();

// Remove an item from the cart
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['remove_item'])) {
    $db->prepare('DELETE FROM cart WHERE id = ? AND user_id = ?')
       ->execute([(int) $_POST['cart_id'], $user['id']]);
    setToast('info', 'Item removed from cart.');
    redirect('/pages/customer/cart.php');
}

// Update quantity of a cart item
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_qty'])) {
    $db->prepare('UPDATE cart SET quantity = ? WHERE id = ? AND user_id = ?')
       ->execute([max(1, (int) $_POST['quantity']), (int) $_POST['cart_id'], $user['id']]);
    redirect('/pages/customer/cart.php');
}

// Proceed to checkout wizard
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['checkout'])) {
    unset($_SESSION['checkout_step'], $_SESSION['checkout_address'], $_SESSION['checkout_payment']);
    redirect('/pages/customer/checkout.php');
}

// ── Fetch cart items ──────────────────────────────────────────────────────────
$stmt = $db->prepare('
    SELECT c.id AS cart_id, c.quantity,
           p.id AS product_id, p.name, p.price, p.image, p.stock, p.status,
           cat.name AS cat_name,
           u.full_name AS seller_name
    FROM cart c
    JOIN products p   ON c.product_id = p.id
    LEFT JOIN categories cat ON p.category_id = cat.id
    JOIN users u       ON p.seller_id = u.id
    WHERE c.user_id = ?
    ORDER BY c.id DESC
');
$stmt->execute([$user['id']]);
$cartItems = $stmt->fetchAll();

$shipping = empty($cartItems) ? 0 : 80;
$subtotal = array_sum(array_map(fn($i) => $i['price'] * $i['quantity'], $cartItems));
$total    = $subtotal + $shipping;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <?php $pageTitle = 'Shopping Cart'; include '../../includes/head.php'; ?>
  <style>
    body { background: #f5f0ed; }

    .cart-wrap {
      max-width: 980px;
      margin: 0 auto;
      padding: 40px 24px;
    }

    .cart-title { font-size: 28px; font-weight: 800; color: #111; margin-bottom: 2px; }
    .cart-sub   { font-size: 13px; color: #999; margin-bottom: 28px; }

    /* Two-column layout */
    .cart-layout {
      display: grid;
      grid-template-columns: 1fr 300px;
      gap: 24px;
      align-items: start;
    }

    /* Item card */
    .cart-card {
      background: #fff;
      border: 1px solid #e8e3e0;
      border-radius: 10px;
      padding: 18px 20px;
      margin-bottom: 12px;
      display: flex;
      align-items: center;
      gap: 16px;
    }

    .cart-img {
      width: 72px; height: 72px; flex-shrink: 0;
      background: #ececec; border-radius: 8px;
      display: flex; align-items: center; justify-content: center;
      overflow: hidden;
    }
    .cart-img img { width: 100%; height: 100%; object-fit: cover; }
    .cart-img svg { width: 28px; height: 28px; color: #bbb; }

    .cart-info     { flex: 1; min-width: 0; }
    .cart-name     { font-size: 14px; font-weight: 700; color: #111; margin-bottom: 4px; line-height: 1.3; }
    .cart-price-tag { font-size: 13px; color: #e01010; font-weight: 700; }

    .cart-controls { display: flex; align-items: center; gap: 10px; margin-left: auto; flex-shrink: 0; }

    .qty-box { display: flex; align-items: center; gap: 2px; }
    .qty-btn {
      width: 28px; height: 28px;
      background: #f3f3f3; border: 1px solid #ddd; border-radius: 4px;
      font-size: 15px; font-weight: 700; cursor: pointer; color: #444;
      display: flex; align-items: center; justify-content: center; line-height: 1;
    }
    .qty-btn:hover { background: #e5e5e5; }
    .qty-num {
      width: 36px; height: 28px;
      border: 1px solid #ddd; border-radius: 4px;
      text-align: center; font-size: 14px; font-weight: 600;
      background: #fafafa; color: #111;
      -moz-appearance: textfield;
    }
    .qty-num::-webkit-inner-spin-button,
    .qty-num::-webkit-outer-spin-button { -webkit-appearance: none; }

    .remove-btn {
      background: #fee2e2; color: #b91c1c;
      border: none; border-radius: 5px;
      font-size: 12px; font-weight: 700;
      padding: 6px 12px; cursor: pointer;
      transition: background .12s;
    }
    .remove-btn:hover { background: #fecaca; }

    /* Order summary */
    .summary-card {
      background: #fff;
      border: 1px solid #e8e3e0;
      border-radius: 10px;
      padding: 24px 22px;
    }
    .summary-title { font-size: 15px; font-weight: 800; color: #111; margin-bottom: 14px; }
    .summary-item {
      display: flex; justify-content: space-between;
      font-size: 13px; color: #555; padding: 4px 0;
    }
    .summary-item .s-price { font-weight: 600; color: #e01010; }
    .summary-divider { border: none; border-top: 1px solid #f0ece9; margin: 12px 0; }
    .summary-row {
      display: flex; justify-content: space-between;
      font-size: 13px; color: #888; padding: 4px 0;
    }
    .summary-total {
      display: flex; justify-content: space-between;
      font-size: 16px; font-weight: 800; color: #111;
      padding-top: 14px; margin-top: 8px;
      border-top: 2px solid #e8e3e0;
    }
    .checkout-btn {
      display: block; width: 100%; margin-top: 18px;
      padding: 13px; background: #e01010; color: #fff;
      border: none; border-radius: 7px;
      font-size: 14px; font-weight: 800; letter-spacing: .5px;
      cursor: pointer; text-align: center; transition: background .12s;
    }
    .checkout-btn:hover { background: #c00d0d; }

    /* Empty state */
    .cart-empty { text-align: center; padding: 80px 20px; color: #888; background:#fff; border-radius:10px; }
    .cart-empty svg { width: 56px; height: 56px; color: #ccc; margin: 0 auto 14px; display: block; }
    .cart-empty-title { font-size: 18px; font-weight: 700; color: #333; margin-bottom: 6px; }
    .cart-continue { display:inline-block; margin-top:14px; color:#e01010; font-size:13px; font-weight:600; text-decoration:none; }
    .cart-continue:hover { text-decoration:underline; }

    @media (max-width: 700px) { .cart-layout { grid-template-columns: 1fr; } }
  </style>
</head>
<body>
<?php include '../../includes/nav.php'; ?>

<div class="cart-wrap">

  <div class="cart-title">Shopping Cart</div>
  <div class="cart-sub"><?= count($cartItems) ?> item<?= count($cartItems) !== 1 ? 's' : '' ?></div>

  <?php if (empty($cartItems)): ?>
    <div class="cart-empty">
      <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"
          d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13l-1.4 7h12.8M10 21a1 1 0 100-2 1 1 0 000 2zm7 0a1 1 0 100-2 1 1 0 000 2z"/>
      </svg>
      <div class="cart-empty-title">Your cart is empty</div>
      <p>Browse products and add items to your cart.</p>
      <a href="<?= BASE_URL ?>/pages/customer/browse.php" class="cart-continue">→ Browse Products</a>
    </div>

  <?php else: ?>

    <div class="cart-layout">

      <!-- Left: items -->
      <div>
        <?php foreach ($cartItems as $item): ?>
          <div class="cart-card">

            <div class="cart-img">
              <?php if (!empty($item['image'])): ?>
                <img src="<?= BASE_URL . '/' . sanitize($item['image']) ?>" alt="">
              <?php else: ?>
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1"
                    d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586
                       a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6
                       a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                </svg>
              <?php endif; ?>
            </div>

            <div class="cart-info">
              <div class="cart-name"><?= sanitize($item['name']) ?></div>
              <div class="cart-price-tag"><?= formatPrice($item['price']) ?></div>
            </div>

            <div class="cart-controls">
              <form method="POST" class="qty-box">
                <input type="hidden" name="cart_id" value="<?= $item['cart_id'] ?>">
                <button type="button" class="qty-btn"
                  onmousedown="var i=this.form.querySelector('.qty-num');
                               if(parseInt(i.value)>1){i.value=parseInt(i.value)-1;
                               i.dispatchEvent(new Event('change'));}return false;">&#8722;</button>
                <input class="qty-num" type="number" name="quantity"
                       value="<?= $item['quantity'] ?>" min="1" max="99"
                       onchange="this.form.submit()">
                <button type="button" class="qty-btn"
                  onmousedown="var i=this.form.querySelector('.qty-num');
                               if(parseInt(i.value)<99){i.value=parseInt(i.value)+1;
                               i.dispatchEvent(new Event('change'));}return false;">&#43;</button>
              </form>

              <form method="POST">
                <input type="hidden" name="cart_id" value="<?= $item['cart_id'] ?>">
                <button type="submit" name="remove_item" class="remove-btn"
                        data-mp-confirm="Remove this item?">Remove</button>
              </form>
            </div>

          </div>
        <?php endforeach; ?>
      </div>

      <!-- Right: order summary -->
      <div>
        <div class="summary-card">
          <div class="summary-title">Order Summary</div>

          <?php foreach ($cartItems as $item): ?>
            <div class="summary-item">
              <span><?= sanitize(mb_strimwidth($item['name'], 0, 24, '…')) ?> <?= $item['quantity'] ?>x</span>
              <span class="s-price"><?= formatPrice($item['price'] * $item['quantity']) ?></span>
            </div>
          <?php endforeach; ?>

          <hr class="summary-divider">

          <div class="summary-row">
            <span>Subtotal</span>
            <span><?= formatPrice($subtotal) ?></span>
          </div>
          <div class="summary-row">
            <span>Shipping</span>
            <span><?= formatPrice($shipping) ?></span>
          </div>

          <div class="summary-total">
            <span>TOTAL</span>
            <span><?= formatPrice($total) ?></span>
          </div>

          <form method="POST">
            <button type="submit" name="checkout" class="checkout-btn">Proceed to Checkout</button>
          </form>
        </div>
      </div>

    </div>
  <?php endif; ?>

</div>
<?php include '../../includes/toast.php'; ?>
</body>
</html>
