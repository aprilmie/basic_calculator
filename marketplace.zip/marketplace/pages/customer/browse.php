<?php
// ── Customer – Browse Products ───────────────────────────────────────────────
session_start();
require_once '../../includes/config.php';
requireRole('customer');

$user = currentUser();
$db   = getDB();

// ── AJAX: Add to cart ─────────────────────────────────────────────────────────
// Triggered by the "ADD" button inside the cart modal (fetch POST).
if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    && isset($_POST['add_to_cart'])
    && !empty($_SERVER['HTTP_X_REQUESTED_WITH'])
) {
    header('Content-Type: application/json');

    try {
        $pid = (int) $_POST['product_id'];
        $qty = max(1, (int) ($_POST['quantity'] ?? 1));

        // Make sure product exists and is active
        $p = $db->prepare('SELECT id, stock, status FROM products WHERE id = ?');
        $p->execute([$pid]);
        $product = $p->fetch();

        if (!$product || $product['status'] === 'inactive') {
            echo json_encode(['success' => false, 'message' => 'Product not available.']);
            exit;
        }

        // Insert or increment the cart row
        $existing = $db->prepare('SELECT id, quantity FROM cart WHERE user_id = ? AND product_id = ?');
        $existing->execute([$user['id'], $pid]);
        $row = $existing->fetch();

        if ($row) {
            $db->prepare('UPDATE cart SET quantity = quantity + ? WHERE id = ?')
               ->execute([$qty, $row['id']]);
        } else {
            $db->prepare('INSERT INTO cart (user_id, product_id, quantity) VALUES (?,?,?)')
               ->execute([$user['id'], $pid, $qty]);
        }

        // Return the new total cart count so the badge can be updated
        $cartTotal = cartCount($user['id']);
        echo json_encode(['success' => true, 'cart_count' => $cartTotal]);

    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
    }
    exit;
}

// ── Page query: search + filter + sort + pagination ───────────────────────────
$search   = trim($_GET['q']    ?? '');
$category = $_GET['cat']       ?? 'all';
$sort     = $_GET['sort']      ?? '';
$page     = max(1, (int) ($_GET['page'] ?? 1));
$perPage  = 10;
$offset   = ($page - 1) * $perPage;

// Build WHERE clause dynamically
$where  = ["p.status != 'inactive'"];
$params = [];
if ($search) {
    $where[]  = '(p.name LIKE ? OR u.full_name LIKE ?)';
    $params[] = "%$search%";
    $params[] = "%$search%";
}
if ($category !== 'all') {
    $where[]  = 'c.name = ?';
    $params[] = $category;
}
$whereSQL = 'WHERE ' . implode(' AND ', $where);

// ORDER BY
$orderSQL = match($sort) {
    'popular'    => 'ORDER BY p.id DESC',
    'price_asc'  => 'ORDER BY p.price ASC',
    'price_desc' => 'ORDER BY p.price DESC',
    default      => 'ORDER BY p.created_at DESC',
};

// Total count (for pagination)
$countStmt = $db->prepare("
    SELECT COUNT(*)
    FROM products p
    JOIN users u ON p.seller_id = u.id
    LEFT JOIN categories c ON p.category_id = c.id
    $whereSQL
");
$countStmt->execute($params);
$total      = (int) $countStmt->fetchColumn();
$totalPages = max(1, ceil($total / $perPage));

// Paginated product rows
$stmt = $db->prepare("
    SELECT p.*, c.name AS cat_name, u.full_name AS seller_name
    FROM products p
    JOIN users u ON p.seller_id = u.id
    LEFT JOIN categories c ON p.category_id = c.id
    $whereSQL $orderSQL
    LIMIT $perPage OFFSET $offset
");
$stmt->execute($params);
$products = $stmt->fetchAll();

// All category names (for the filter bar)
$cats = $db->query('SELECT DISTINCT name FROM categories ORDER BY name')
           ->fetchAll(PDO::FETCH_COLUMN);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <?php $pageTitle = 'Browse Products'; include '../../includes/head.php'; ?>
  <style>
    /* ── Cart modal ──────────────────────────────────────────────────────────── */
    .cart-modal-overlay {
      display: none; position: fixed; inset: 0;
      background: rgba(0,0,0,.65); z-index: 999;
      align-items: center; justify-content: center; padding: 16px;
    }
    .cart-modal-overlay.open { display: flex; }

    .cart-modal {
      position: relative; width: 420px; max-width: 100%;
      border-radius: 10px; overflow: visible;
      box-shadow: 0 20px 60px rgba(0,0,0,.5);
    }
    .cart-modal-inner { border-radius: 10px; overflow: hidden; position: relative; }

    /* Close button (top-right of dark section) */
    .cart-modal-close {
      position: absolute; top: 12px; right: 14px;
      background: none; border: none; font-size: 20px; color: #aaa;
      cursor: pointer; z-index: 10; padding: 4px 6px;
    }
    .cart-modal-close:hover { color: #fff; }

    /* Dark product preview area */
    .cart-modal-preview {
      background: #1a1a1a; display: flex; align-items: flex-start;
      gap: 16px; padding: 20px 20px 18px;
    }
    .cart-modal-img {
      width: 110px; height: 110px; flex-shrink: 0;
      background: #2e2e2e; border-radius: 6px;
      display: flex; align-items: center; justify-content: center; overflow: hidden;
    }
    .cart-modal-img img { width: 100%; height: 100%; object-fit: cover; }
    .cart-modal-img svg { width: 38px; height: 38px; color: #666; }
    .cart-modal-meta  { flex: 1; min-width: 0; padding-top: 2px; }
    .cart-modal-name  { font-size: 15px; font-weight: 700; color: #fff; line-height: 1.35; margin-bottom: 6px; }
    .cart-modal-price { font-size: 15px; font-weight: 700; color: #e01010; margin-bottom: 14px; }
    .qty-label        { font-size: 11px; color: #999; display: block; margin-bottom: 5px; letter-spacing: .4px; text-transform: uppercase; }
    .cart-modal-qty-row { display: flex; align-items: center; justify-content: space-between; }
    .cart-modal-qty     { display: flex; align-items: center; }
    .qty-btn {
      width: 26px; height: 26px; background: transparent;
      border: 1.5px solid #555; color: #fff; font-size: 16px; font-weight: 700;
      cursor: pointer; display: flex; align-items: center; justify-content: center;
      border-radius: 3px; user-select: none;
    }
    .qty-btn:hover { background: #333; border-color: #888; }
    .qty-input {
      width: 34px; height: 26px; background: transparent;
      border-top: 1.5px solid #555; border-bottom: 1.5px solid #555;
      border-left: none; border-right: none;
      color: #fff; text-align: center; font-size: 13px; font-weight: 600;
      -moz-appearance: textfield;
    }
    .qty-input::-webkit-inner-spin-button,
    .qty-input::-webkit-outer-spin-button { -webkit-appearance: none; }
    .cart-modal-remove {
      background: #e01010; color: #fff; border: none; border-radius: 4px;
      padding: 6px 14px; font-size: 11px; font-weight: 700; cursor: pointer; white-space: nowrap;
    }
    .cart-modal-remove:hover { background: #c00; }

    /* White details area */
    .cart-modal-details       { background: #fff; padding: 18px 20px 4px; }
    .cart-modal-details-title { font-size: 13px; font-weight: 700; color: #111; margin-bottom: 10px; }
    .cart-modal-line {
      display: flex; justify-content: space-between; align-items: flex-start;
      font-size: 13px; color: #333;
      padding-bottom: 10px; border-bottom: 1px solid #e0e0e0;
      margin-bottom: 12px; gap: 12px;
    }
    .cart-modal-total-row  { display: flex; justify-content: space-between; align-items: center; }
    .cart-modal-total-label { font-size: 14px; font-weight: 700; color: #111; }
    .cart-modal-total-val   { font-size: 15px; font-weight: 800; color: #111; }

    /* Footer with ADD button */
    .cart-modal-footer {
      background: #fff; display: flex; justify-content: flex-end;
      padding: 14px 20px 18px; border-top: 1px solid #f0f0f0;
    }
    .cart-modal-add-btn {
      padding: 11px 44px; background: #e01010; color: #fff;
      border: none; border-radius: 6px; font-size: 14px; font-weight: 800;
      letter-spacing: 1.5px; cursor: pointer; transition: background .15s;
    }
    .cart-modal-add-btn:hover    { background: #c00; }
    .cart-modal-add-btn:disabled { opacity: .6; cursor: not-allowed; }

    /* Dim overlay that sits behind the success toast */
    .cart-modal-dim {
      display: none; position: absolute; inset: 0;
      background: rgba(0,0,0,.40); border-radius: 10px;
      z-index: 10; pointer-events: auto;
    }
    .cart-modal-dim.show { display: block; }

    /* Success toast (centered over modal) */
    .cart-success-toast {
      display: none; position: absolute; top: 50%; left: 50%;
      transform: translate(-50%, -50%);
      background: #fff; border-radius: 8px; padding: 20px 24px 18px;
      text-align: center; box-shadow: 0 6px 32px rgba(0,0,0,.35);
      z-index: 20; width: 260px; max-width: 90%;
    }
    .cart-success-toast.show        { display: block; }
    .cart-success-toast-close       { position: absolute; top: 8px; right: 10px; background: none; border: none; font-size: 14px; color: #bbb; cursor: pointer; }
    .cart-success-toast-close:hover { color: #333; }
    .cart-success-toast-title       { font-size: 12px; font-weight: 800; letter-spacing: .8px; margin-bottom: 14px; color: #111; }
    .toast-btn-row { display: flex; gap: 8px; }
    .toast-btn     { flex: 1; padding: 9px 4px; border: none; border-radius: 5px; font-size: 13px; font-weight: 700; cursor: pointer; }
    .toast-btn-browse, .toast-btn-cart { background: #e01010; color: #fff; }
    .toast-btn-browse:hover, .toast-btn-cart:hover { background: #c00; }
  </style>
</head>
<body>
<?php include '../../includes/nav.php'; ?>

<div style="background:var(--gray);min-height:calc(100vh - 56px);padding:32px 40px;">

  <div class="dash-page-title">Browse Products</div>
  <div class="dash-page-sub"><?= $total ?> products found</div>

  <!-- Search + filter bar -->
  <div class="browse-header">
    <form method="GET" action="">
      <div class="search-bar-wrap">
        <input type="text" name="q" value="<?= sanitize($search) ?>"
               placeholder="Search products or sellers..." class="form-control">
        <span class="search-icon">
          <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
              d="M21 21l-4.35-4.35m0 0A7.5 7.5 0 104.5 4.5a7.5 7.5 0 0012.15 12.15z"/>
          </svg>
        </span>
      </div>
      <div class="filter-bar">
        <!-- Category filters -->
        <a href="?cat=all<?= $search ? '&q=' . urlencode($search) : '' ?>"
           class="filter-btn <?= $category === 'all' ? 'active' : '' ?>">All</a>
        <?php foreach ($cats as $c): ?>
          <a href="?cat=<?= urlencode($c) ?><?= $search ? '&q=' . urlencode($search) : '' ?>"
             class="filter-btn <?= $category === $c ? 'active' : '' ?>">
            <?= sanitize($c) ?>
          </a>
        <?php endforeach; ?>
        <!-- Sort filters -->
        <a href="?cat=<?= urlencode($category) ?>&sort=popular<?= $search ? '&q=' . urlencode($search) : '' ?>"
           class="filter-btn <?= $sort === 'popular' ? 'active' : '' ?>">Most Popular</a>
        <a href="?cat=<?= urlencode($category) ?>&sort=price_asc<?= $search ? '&q=' . urlencode($search) : '' ?>"
           class="filter-btn <?= $sort === 'price_asc' ? 'active' : '' ?>">Price ↑</a>
        <a href="?cat=<?= urlencode($category) ?>&sort=price_desc<?= $search ? '&q=' . urlencode($search) : '' ?>"
           class="filter-btn <?= $sort === 'price_desc' ? 'active' : '' ?>">Price ↓</a>
      </div>
    </form>
  </div>

  <!-- Product grid -->
  <div class="products-grid" style="margin-top:20px">
    <?php foreach ($products as $p): ?>
      <div class="product-card">
        <div class="product-img">
          <?php if ($p['image'] && file_exists('../../' . $p['image'])): ?>
            <img src="<?= BASE_URL . '/' . $p['image'] ?>" alt="">
          <?php else: ?>
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1"
                d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0
                   012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2
                   2 0 00-2 2v12a2 2 0 002 2z"/>
            </svg>
          <?php endif; ?>
        </div>
        <div class="product-info">
          <div class="product-cat"><?= sanitize($p['cat_name'] ?? '') ?></div>
          <div class="product-name"><?= sanitize($p['name']) ?></div>
          <div class="product-price"><?= formatPrice($p['price']) ?></div>
          <div class="product-seller">by <?= sanitize($p['seller_name']) ?></div>

          <?php if ($p['status'] === 'sold_out' || $p['stock'] == 0): ?>
            <button class="btn btn-dark" disabled>SOLD OUT</button>
          <?php else: ?>
            <!-- data-* attributes are read by JS to populate the cart modal -->
            <button
              type="button"
              class="btn btn-black open-cart-modal"
              data-id="<?= $p['id'] ?>"
              data-name="<?= htmlspecialchars($p['name'], ENT_QUOTES) ?>"
              data-price="<?= $p['price'] ?>"
              data-img="<?= htmlspecialchars($p['image'] ?? '', ENT_QUOTES) ?>"
            >ADD TO CART</button>
          <?php endif; ?>
        </div>
      </div>
    <?php endforeach; ?>

    <?php if (empty($products)): ?>
      <div style="grid-column:1/-1;text-align:center;padding:60px;color:#888">
        No products found.
      </div>
    <?php endif; ?>
  </div>

  <!-- Pagination -->
  <?php if ($totalPages > 1): ?>
    <div class="pagination">
      <?php for ($i = 1; $i <= min(3, $totalPages); $i++): ?>
        <a href="?page=<?= $i ?>&cat=<?= urlencode($category) ?>&q=<?= urlencode($search) ?>"
           class="page-btn <?= $i === $page ? 'active' : '' ?>"><?= $i ?></a>
      <?php endfor; ?>
      <?php if ($totalPages > 4): ?>
        <span class="page-btn" style="border:none;background:none;cursor:default">…</span>
      <?php endif; ?>
      <?php if ($totalPages > 3): ?>
        <a href="?page=<?= $totalPages - 1 ?>&cat=<?= urlencode($category) ?>&q=<?= urlencode($search) ?>"
           class="page-btn <?= ($totalPages - 1) === $page ? 'active' : '' ?>"><?= $totalPages - 1 ?></a>
        <a href="?page=<?= $totalPages ?>&cat=<?= urlencode($category) ?>&q=<?= urlencode($search) ?>"
           class="page-btn <?= $totalPages === $page ? 'active' : '' ?>"><?= $totalPages ?></a>
      <?php endif; ?>
    </div>
  <?php endif; ?>

</div>

<!-- ── Cart modal ─────────────────────────────────────────────────────────── -->
<div class="cart-modal-overlay" id="cartModalOverlay">
  <div class="cart-modal" id="cartModal">

    <!-- Dim + toast overlay (outside .cart-modal-inner so they aren't clipped) -->
    <div class="cart-modal-dim" id="cartModalDim"></div>
    <div class="cart-success-toast" id="cartSuccessToast">
      <button class="cart-success-toast-close" id="toastCloseBtn" type="button">&#x2715;</button>
      <div class="cart-success-toast-title">ADDED SUCCESSFULLY!</div>
      <div class="toast-btn-row">
        <button class="toast-btn toast-btn-browse" id="toastBrowseBtn" type="button">Browse</button>
        <button class="toast-btn toast-btn-cart"   id="toastCartBtn"   type="button">Cart</button>
      </div>
    </div>

    <!-- Inner: clips rounded corners -->
    <div class="cart-modal-inner">
      <button class="cart-modal-close" id="cartModalClose" type="button">&#x2715;</button>

      <!-- Dark preview section -->
      <div class="cart-modal-preview">
        <div class="cart-modal-img" id="modalProductImg">
          <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1"
              d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20
                 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>
          </svg>
        </div>
        <div class="cart-modal-meta">
          <div class="cart-modal-name"  id="modalProductName">—</div>
          <div class="cart-modal-price" id="modalProductPrice">₱0</div>
          <span class="qty-label">QTY.</span>
          <div class="cart-modal-qty-row">
            <div class="cart-modal-qty">
              <button class="qty-btn" id="qtyMinus" type="button">&#8722;</button>
              <input class="qty-input" type="number" id="qtyInput" value="1" min="1" max="99">
              <button class="qty-btn" id="qtyPlus"  type="button">&#43;</button>
            </div>
            <button class="cart-modal-remove" id="modalRemoveBtn" type="button">Remove</button>
          </div>
        </div>
      </div>

      <!-- White details section -->
      <div class="cart-modal-details">
        <div class="cart-modal-details-title">Details</div>
        <div class="cart-modal-line">
          <span id="modalLineLabel">1x —</span>
          <span id="modalLinePrice">-₱0</span>
        </div>
        <div class="cart-modal-total-row">
          <span class="cart-modal-total-label">Total:</span>
          <span class="cart-modal-total-val" id="modalTotal">-₱0</span>
        </div>
      </div>

      <!-- Footer -->
      <div class="cart-modal-footer">
        <button class="cart-modal-add-btn" id="modalAddBtn" type="button">ADD</button>
      </div>
    </div>
  </div>
</div>

<script>
(function () {
  'use strict';

  // ── Element references ──────────────────────────────────────────────────────
  var overlay       = document.getElementById('cartModalOverlay');
  var closeBtn      = document.getElementById('cartModalClose');
  var dim           = document.getElementById('cartModalDim');
  var toast         = document.getElementById('cartSuccessToast');
  var toastCloseBtn = document.getElementById('toastCloseBtn');
  var toastBrowse   = document.getElementById('toastBrowseBtn');
  var toastCart     = document.getElementById('toastCartBtn');
  var qtyInput      = document.getElementById('qtyInput');
  var qtyMinus      = document.getElementById('qtyMinus');
  var qtyPlus       = document.getElementById('qtyPlus');
  var removeBtn     = document.getElementById('modalRemoveBtn');
  var addBtn        = document.getElementById('modalAddBtn');

  var currentProduct = null; // holds the product data for the open modal

  // ── Helpers ─────────────────────────────────────────────────────────────────
  function fmt(n) {
    return '₱' + parseFloat(n).toLocaleString('en-PH', { minimumFractionDigits: 0, maximumFractionDigits: 2 });
  }

  function showToast()  { dim.classList.add('show');    toast.classList.add('show'); }
  function hideToast()  { dim.classList.remove('show'); toast.classList.remove('show'); }

  function openModal() {
    hideToast();
    qtyInput.value = 1;
    renderModal();
    overlay.classList.add('open');
    document.body.style.overflow = 'hidden';
  }

  function closeModal() {
    overlay.classList.remove('open');
    hideToast();
    document.body.style.overflow = '';
    currentProduct = null;
  }

  // Sync the modal's displayed values with the current qty input
  function renderModal() {
    if (!currentProduct) return;
    var qty   = Math.max(1, parseInt(qtyInput.value) || 1);
    var total = currentProduct.price * qty;

    document.getElementById('modalProductName').textContent  = currentProduct.name;
    document.getElementById('modalProductPrice').textContent = fmt(currentProduct.price);
    document.getElementById('modalLineLabel').textContent    = qty + 'x ' + currentProduct.name;
    document.getElementById('modalLinePrice').textContent    = '-' + fmt(total);
    document.getElementById('modalTotal').textContent        = '-' + fmt(total);

    var imgWrap = document.getElementById('modalProductImg');
    imgWrap.innerHTML = currentProduct.img
      ? '<img src="<?= BASE_URL ?>/' + currentProduct.img + '" alt="">'
      : '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>';
  }

  // Update the cart badge in the navbar
  function updateBadge(count) {
    var badge = document.querySelector('.dash-cart-count, .cart-count');
    if (badge) {
      badge.textContent    = count;
      badge.style.display  = count > 0 ? '' : 'none';
    } else if (count > 0) {
      var cartBtn = document.querySelector('.dash-cart-btn');
      if (cartBtn) {
        var span = document.createElement('span');
        span.className   = 'dash-cart-count';
        span.textContent = count;
        cartBtn.appendChild(span);
      }
    }
  }

  // ── Open modal when "ADD TO CART" is clicked ──────────────────────────────
  document.querySelectorAll('.open-cart-modal').forEach(function (btn) {
    btn.addEventListener('click', function () {
      currentProduct = {
        id   : this.dataset.id,
        name : this.dataset.name,
        price: parseFloat(this.dataset.price),
        img  : this.dataset.img || '',
      };
      openModal();
    });
  });

  // ── Quantity controls ─────────────────────────────────────────────────────
  qtyMinus.addEventListener('click', function () {
    var v = parseInt(qtyInput.value) || 1;
    if (v > 1) { qtyInput.value = v - 1; renderModal(); }
  });
  qtyPlus.addEventListener('click', function () {
    var v = parseInt(qtyInput.value) || 1;
    if (v < 99) { qtyInput.value = v + 1; renderModal(); }
  });
  qtyInput.addEventListener('input', function () {
    var v = parseInt(this.value) || 1;
    this.value = Math.min(99, Math.max(1, v));
    renderModal();
  });

  // ── Close / Remove buttons ────────────────────────────────────────────────
  removeBtn.addEventListener('click', closeModal);
  closeBtn .addEventListener('click', closeModal);
  overlay  .addEventListener('click', function (e) { if (e.target === overlay) closeModal(); });
  document .addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && overlay.classList.contains('open')) closeModal();
  });

  // ── ADD button → AJAX POST ────────────────────────────────────────────────
  addBtn.addEventListener('click', function () {
    if (!currentProduct) return;

    addBtn.disabled    = true;
    addBtn.textContent = 'Adding…';

    var fd = new FormData();
    fd.append('add_to_cart', '1');
    fd.append('product_id',  currentProduct.id);
    fd.append('quantity',    qtyInput.value);

    fetch(window.location.href, {
      method : 'POST',
      headers: { 'X-Requested-With': 'XMLHttpRequest' },
      body   : fd,
    })
    .then(function (r) {
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.json();
    })
    .then(function (data) {
      if (data.success) {
        updateBadge(data.cart_count);
        showToast();
      } else {
        alert(data.message || 'Could not add item. Please try again.');
      }
    })
    .catch(function (err) {
      console.error('Cart error:', err);
      alert('Something went wrong. Please try again.');
    })
    .finally(function () {
      addBtn.disabled    = false;
      addBtn.textContent = 'ADD';
    });
  });

  // ── Toast buttons ─────────────────────────────────────────────────────────
  toastCloseBtn.addEventListener('click', hideToast);
  toastBrowse  .addEventListener('click', closeModal); // stay on page
  toastCart    .addEventListener('click', function () {
    window.location.href = '<?= BASE_URL ?>/pages/customer/cart.php';
  });

})();
</script>
<?php include '../../includes/toast.php'; ?>
</body>
</html>
