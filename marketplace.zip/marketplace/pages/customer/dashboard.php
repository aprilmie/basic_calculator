<?php
// ── Customer Dashboard ───────────────────────────────────────────────────────
session_start();
require_once '../../includes/config.php';
requireRole('customer');

$user = currentUser();
$db   = getDB();

// ── Stats ─────────────────────────────────────────────────────────────────────
$totalOrdersStmt = $db->prepare('SELECT COUNT(*) FROM orders WHERE customer_id = ?');
$totalOrdersStmt->execute([$user['id']]);
$totalOrders = $totalOrdersStmt->fetchColumn();

$cartItems = cartCount($user['id']);
$notifs    = unreadNotifCount($user['id']);

// ── Recent orders (last 5) ───────────────────────────────────────────────────
$recentStmt = $db->prepare("
    SELECT o.order_code,
           GROUP_CONCAT(p.name SEPARATOR ', ') AS items,
           o.total,
           o.status
    FROM orders o
    LEFT JOIN order_items oi ON oi.order_id = o.id
    LEFT JOIN products    p  ON p.id = oi.product_id
    WHERE o.customer_id = ?
    GROUP BY o.id
    ORDER BY o.created_at DESC
    LIMIT 5
");
$recentStmt->execute([$user['id']]);
$recentOrders = $recentStmt->fetchAll();

$firstName = explode(' ', trim($user['full_name']))[0];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <?php $pageTitle = 'Dashboard'; include '../../includes/head.php'; ?>
</head>
<body>
<?php include '../../includes/nav.php'; ?>

<div class="dash-layout">
  <?php include '../../includes/customer_sidebar.php'; ?>

  <main class="dash-main">
    <div class="dash-page-title">Welcome, <?= sanitize($firstName) ?>!</div>
    <div class="dash-page-sub">Manage your account and orders.</div>

    <!-- Stat cards -->
    <div class="dash-stat-grid">
      <div class="dash-stat-card">
        <div class="dash-stat-num"><?= $totalOrders ?></div>
        <div class="dash-stat-label">Total Orders</div>
      </div>
      <div class="dash-stat-card">
        <div class="dash-stat-num"><?= $cartItems ?></div>
        <div class="dash-stat-label">Cart Items</div>
      </div>
      <div class="dash-stat-card">
        <div class="dash-stat-num"><?= $notifs ?></div>
        <div class="dash-stat-label">Unread Notifs</div>
      </div>
    </div>

    <!-- Recent orders table -->
    <div class="dash-table-card">
      <div class="dash-table-header">Recent Orders</div>
      <table class="dash-table">
        <thead>
          <tr>
            <th>Order ID</th>
            <th>Items</th>
            <th>Total</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($recentOrders)): ?>
            <tr>
              <td colspan="4" style="text-align:center;padding:40px;color:#aaa">No orders yet.</td>
            </tr>
          <?php else: ?>
            <?php foreach ($recentOrders as $o): ?>
              <tr>
                <td><?= sanitize($o['order_code']) ?></td>
                <td><?= sanitize($o['items'] ?? '—') ?></td>
                <td><?= formatPrice($o['total']) ?></td>
                <td><span class="badge badge-<?= $o['status'] ?>"><?= strtoupper($o['status']) ?></span></td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </main>
</div>
<?php include '../../includes/toast.php'; ?>
</body>
</html>
