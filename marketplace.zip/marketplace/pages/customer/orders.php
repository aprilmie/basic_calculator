<?php
// ── Customer – My Orders ─────────────────────────────────────────────────────
session_start();
require_once '../../includes/config.php';
requireRole('customer');

$user = currentUser();
$db   = getDB();

// ── Handle review submission ──────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_review'])) {
    $productId = (int) $_POST['product_id'];
    $rating    = max(1, min(5, (int) $_POST['rating']));
    $comment   = trim($_POST['comment'] ?? '');

    // Only allow review if customer has a delivered order containing this product
    $check = $db->prepare('
        SELECT COUNT(*)
        FROM orders o
        JOIN order_items oi ON oi.order_id = o.id
        WHERE o.customer_id = ? AND oi.product_id = ? AND o.status = "delivered"
    ');
    $check->execute([$user['id'], $productId]);

    if ($check->fetchColumn() > 0) {
        // Upsert: one review per customer per product
        $exists = $db->prepare('SELECT id FROM reviews WHERE product_id = ? AND user_id = ?');
        $exists->execute([$productId, $user['id']]);
        if ($exists->fetch()) {
            $db->prepare('UPDATE reviews SET rating=?, comment=? WHERE product_id=? AND user_id=?')
               ->execute([$rating, $comment, $productId, $user['id']]);
        } else {
            $db->prepare('INSERT INTO reviews (product_id, user_id, rating, comment) VALUES (?,?,?,?)')
               ->execute([$productId, $user['id'], $rating, $comment]);
        }

        // Notify the seller
        $sellerStmt = $db->prepare('
            SELECT p.seller_id, p.name
            FROM products p WHERE p.id = ?
        ');
        $sellerStmt->execute([$productId]);
        $prod = $sellerStmt->fetch();
        if ($prod) {
            $stars = str_repeat('★', $rating) . str_repeat('☆', 5 - $rating);
            $db->prepare("INSERT INTO notifications (user_id, message, type) VALUES (?,?,?)")
               ->execute([
                   $prod['seller_id'],
                   "New {$rating}-star review {$stars} on your product \"{$prod['name']}\"",
                   'review'
               ]);
        }

        setToast('success', 'Review submitted! Thank you.');
    } else {
        setToast('error', 'You can only review delivered orders.');
    }
    redirect('/pages/customer/orders.php');
}

// ── Fetch orders with product details ─────────────────────────────────────────
$stmt = $db->prepare("
    SELECT o.id AS order_id, o.order_code,
           o.total, o.status, o.created_at,
           GROUP_CONCAT(DISTINCT p.name SEPARATOR ', ') AS items,
           GROUP_CONCAT(DISTINCT p.id   SEPARATOR ',')  AS product_ids
    FROM orders o
    LEFT JOIN order_items oi ON oi.order_id = o.id
    LEFT JOIN products    p  ON p.id = oi.product_id
    WHERE o.customer_id = ?
    GROUP BY o.id
    ORDER BY o.created_at DESC
");
$stmt->execute([$user['id']]);
$orders = $stmt->fetchAll();

// Fetch already-reviewed product ids by this customer
$reviewedStmt = $db->prepare('SELECT product_id FROM reviews WHERE user_id = ?');
$reviewedStmt->execute([$user['id']]);
$reviewed = array_flip($reviewedStmt->fetchAll(PDO::FETCH_COLUMN));
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <?php $pageTitle = 'My Orders'; include '../../includes/head.php'; ?>
  <style>
    .review-btn {
      background: none; border: 1.5px solid #e01010; color: #e01010;
      border-radius: 6px; padding: 4px 12px; font-size: 12px; font-weight: 700;
      cursor: pointer; transition: all .12s; white-space: nowrap;
    }
    .review-btn:hover { background: #e01010; color: #fff; }
    .reviewed-tag {
      font-size: 11px; color: #16a34a; font-weight: 700;
      background: #f0fdf4; border: 1px solid #bbf7d0;
      border-radius: 6px; padding: 4px 10px; white-space: nowrap;
    }

    /* ── Review modal ── */
    .review-overlay {
      display: none; position: fixed; inset: 0;
      background: rgba(0,0,0,.55); z-index: 999;
      align-items: center; justify-content: center; padding: 16px;
    }
    .review-overlay.open { display: flex; }
    .review-modal {
      background: #fff; border-radius: 14px; padding: 32px 28px 28px;
      width: 420px; max-width: 100%; position: relative;
    }
    .review-modal-close {
      position: absolute; top: 14px; right: 18px;
      background: none; border: none; font-size: 22px; color: #bbb;
      cursor: pointer; line-height: 1;
    }
    .review-modal-close:hover { color: #333; }
    .review-modal-title { font-size: 18px; font-weight: 800; margin-bottom: 6px; color: #111; }
    .review-modal-product { font-size: 13px; color: #888; margin-bottom: 20px; }

    /* Star picker */
    .star-row { display: flex; gap: 6px; margin-bottom: 16px; flex-direction: row-reverse; justify-content: flex-end; }
    .star-row input { display: none; }
    .star-row label {
      font-size: 32px; color: #ddd; cursor: pointer;
      transition: color .1s; line-height: 1;
    }
    .star-row input:checked ~ label,
    .star-row label:hover,
    .star-row label:hover ~ label { color: #facc15; }

    .review-textarea {
      width: 100%; padding: 10px 13px; border: 1.5px solid #ddd;
      border-radius: 8px; font-size: 13px; font-family: inherit;
      resize: vertical; min-height: 80px; box-sizing: border-box;
      transition: border-color .15s;
    }
    .review-textarea:focus { outline: none; border-color: #e01010; }
    .review-submit {
      margin-top: 14px; width: 100%; padding: 12px;
      background: #e01010; color: #fff; border: none;
      border-radius: 8px; font-size: 14px; font-weight: 800;
      letter-spacing: .5px; cursor: pointer; transition: background .12s;
    }
    .review-submit:hover { background: #c00; }
  </style>
</head>
<body>
<?php include '../../includes/nav.php'; ?>

<div class="dash-layout">
  <?php include '../../includes/customer_sidebar.php'; ?>

  <main class="dash-main">
    <div class="dash-page-title">My Orders</div>
    <div class="dash-page-sub"><?= count($orders) ?> order(s) placed</div>

    <div class="dash-table-card">
      <div class="dash-table-header">Order History</div>
      <table class="dash-table">
        <thead>
          <tr>
            <th>Order ID</th>
            <th>Items</th>
            <th>Total</th>
            <th>Status</th>
            <th>Date</th>
            <th>Review</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($orders)): ?>
            <tr>
              <td colspan="6" style="text-align:center;padding:40px;color:#888">
                No orders yet.
                <a href="<?= BASE_URL ?>/pages/customer/browse.php" style="color:#e01010">Browse products</a>
              </td>
            </tr>
          <?php else: ?>
            <?php foreach ($orders as $o): ?>
              <?php
                $productIds  = array_filter(explode(',', $o['product_ids'] ?? ''));
                $isDelivered = $o['status'] === 'delivered';
                // Check if ALL products in this order are already reviewed
                $allReviewed = $isDelivered && !empty($productIds) &&
                               count(array_filter($productIds, fn($pid) => !isset($reviewed[(int)$pid]))) === 0;
              ?>
              <tr>
                <td><?= sanitize($o['order_code']) ?></td>
                <td><?= sanitize($o['items'] ?? '—') ?></td>
                <td><?= formatPrice($o['total']) ?></td>
                <td><span class="badge badge-<?= $o['status'] ?>"><?= strtoupper($o['status']) ?></span></td>
                <td><?= date('M d, Y', strtotime($o['created_at'])) ?></td>
                <td>
                  <?php if (!$isDelivered): ?>
                    <span style="color:#ccc;font-size:12px;">—</span>
                  <?php elseif ($allReviewed): ?>
                    <span class="reviewed-tag">✔ Reviewed</span>
                  <?php else: ?>
                    <button class="review-btn"
                      onclick="openReview('<?= $o['order_id'] ?>','<?= addslashes(htmlspecialchars($o['items'])) ?>',<?= htmlspecialchars(json_encode($productIds)) ?>)">
                      ★ Rate
                    </button>
                  <?php endif; ?>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </main>
</div>

<!-- ── Review Modal ─────────────────────────────────────────────────────── -->
<div class="review-overlay" id="reviewOverlay">
  <div class="review-modal">
    <button class="review-modal-close" onclick="closeReview()">&times;</button>
    <div class="review-modal-title">Rate Your Order</div>
    <div class="review-modal-product" id="reviewProductName"></div>

    <form method="POST" id="reviewForm">
      <input type="hidden" name="submit_review" value="1">
      <input type="hidden" name="product_id" id="reviewProductId">

      <!-- Star picker (reverse order for CSS trick) -->
      <div class="star-row">
        <?php for ($s = 5; $s >= 1; $s--): ?>
          <input type="radio" name="rating" id="star<?= $s ?>" value="<?= $s ?>" <?= $s === 5 ? 'checked' : '' ?>>
          <label for="star<?= $s ?>">★</label>
        <?php endfor; ?>
      </div>

      <textarea name="comment" class="review-textarea"
                placeholder="Share your experience with this product..."></textarea>

      <button type="submit" class="review-submit">SUBMIT REVIEW</button>
    </form>

    <!-- Product selector if multiple products in the order -->
    <div id="productSelector" style="margin-top:14px;display:none;">
      <div style="font-size:11px;font-weight:700;color:#aaa;letter-spacing:.8px;text-transform:uppercase;margin-bottom:8px;">Review a specific product:</div>
      <div id="productBtns" style="display:flex;flex-wrap:wrap;gap:8px;"></div>
    </div>
  </div>
</div>

<script>
var reviewedIds = <?= json_encode(array_keys($reviewed)) ?>;

function openReview(orderId, items, productIds) {
  // Filter out already-reviewed products
  var unreviewedIds = productIds.filter(function(id) {
    return reviewedIds.indexOf(parseInt(id)) === -1;
  });

  if (unreviewedIds.length === 0) return;

  document.getElementById('reviewOverlay').classList.add('open');
  document.body.style.overflow = 'hidden';

  var sel = document.getElementById('productSelector');
  var btns = document.getElementById('productBtns');
  btns.innerHTML = '';

  if (unreviewedIds.length === 1) {
    // Only one product — set directly
    setProduct(unreviewedIds[0], items);
    sel.style.display = 'none';
  } else {
    // Multiple products — show selector
    setProduct(unreviewedIds[0], 'Product #' + unreviewedIds[0]);
    unreviewedIds.forEach(function(pid) {
      var btn = document.createElement('button');
      btn.type = 'button';
      btn.textContent = 'Product #' + pid;
      btn.style.cssText = 'padding:6px 14px;border:1.5px solid #ddd;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer;background:#fff;';
      btn.onclick = function() {
        setProduct(pid, 'Product #' + pid);
        btns.querySelectorAll('button').forEach(function(b){ b.style.borderColor='#ddd';b.style.background='#fff'; });
        btn.style.borderColor = '#e01010';
        btn.style.background = '#fff5f5';
      };
      btns.appendChild(btn);
    });
    sel.style.display = 'block';
  }
}

function setProduct(pid, label) {
  document.getElementById('reviewProductId').value = pid;
  document.getElementById('reviewProductName').textContent = label;
}

function closeReview() {
  document.getElementById('reviewOverlay').classList.remove('open');
  document.body.style.overflow = '';
}

document.getElementById('reviewOverlay').addEventListener('click', function(e) {
  if (e.target === this) closeReview();
});
document.addEventListener('keydown', function(e) {
  if (e.key === 'Escape') closeReview();
});
</script>

<?php include '../../includes/toast.php'; ?>
</body>
</html>
