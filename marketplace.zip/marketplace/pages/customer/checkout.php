<?php
// ── Customer – Checkout (4-step wizard) ──────────────────────────────────────
session_start();
require_once '../../includes/config.php';
requireRole('customer');

$user = currentUser();
$db   = getDB();

// ── Fetch cart items ──────────────────────────────────────────────────────────
$stmt = $db->prepare('
    SELECT c.id AS cart_id, c.quantity,
           p.id AS product_id, p.name, p.price, p.image
    FROM cart c
    JOIN products p ON c.product_id = p.id
    WHERE c.user_id = ?
    ORDER BY c.id DESC
');
$stmt->execute([$user['id']]);
$cartItems = $stmt->fetchAll();

// Redirect back if cart is empty
if (empty($cartItems)) {
    redirect('/pages/customer/cart.php');
}

$shipping = 80;
$subtotal = array_sum(array_map(fn($i) => $i['price'] * $i['quantity'], $cartItems));
$grandTotal = $subtotal + $shipping;

// ── Determine current step (stored in session) ────────────────────────────────
if (!isset($_SESSION['checkout_step'])) {
    $_SESSION['checkout_step'] = 1;
}

// ── Handle POST actions ───────────────────────────────────────────────────────

// Step 1 → save address, go to step 2
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_address'])) {
    $fullName   = trim($_POST['full_name'] ?? '');
    $phone      = trim($_POST['phone'] ?? '');
    $street     = trim($_POST['street'] ?? '');
    $city       = trim($_POST['city'] ?? '');
    $zip        = trim($_POST['zip'] ?? '');

    if ($fullName && $phone && $street && $city && $zip) {
        $_SESSION['checkout_address'] = compact('fullName','phone','street','city','zip');
        $_SESSION['checkout_step']    = 2;
    }
    redirect('/pages/customer/checkout.php');
}

// Step 2 → go to step 3
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_summary'])) {
    $_SESSION['checkout_step'] = 3;
    redirect('/pages/customer/checkout.php');
}

// Step 3 → save payment, go to step 4
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_payment'])) {
    $method = $_POST['payment_method'] ?? 'Cash on Delivery';
    $_SESSION['checkout_payment'] = $method;
    $_SESSION['checkout_step']    = 4;
    redirect('/pages/customer/checkout.php');
}

// Step 4 → place order
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['place_order'])) {
    $addr   = $_SESSION['checkout_address'] ?? [];
    $method = $_SESSION['checkout_payment'] ?? 'Cash on Delivery';

    if (!empty($addr) && !empty($cartItems)) {
        $code = 'ORD-' . strtoupper(substr(uniqid(), -6));
        $shippingAddr = $addr['street'] . ', ' . $addr['city'] . ' ' . $addr['zip'];

        $db->prepare("
            INSERT INTO orders (order_code, customer_id, total, status, shipping_address, payment_method)
            VALUES (?,?,?,'paid',?,?)
        ")->execute([$code, $user['id'], $grandTotal, $shippingAddr, $method]);

        $orderId = $db->lastInsertId();

        foreach ($cartItems as $item) {
            $db->prepare('INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?,?,?,?)')
               ->execute([$orderId, $item['product_id'], $item['quantity'], $item['price']]);
        }

        $db->prepare('DELETE FROM cart WHERE user_id = ?')->execute([$user['id']]);

        // Notify customer
        $db->prepare("INSERT INTO notifications (user_id, message, type) VALUES (?,?,?)")
           ->execute([$user['id'], "Your order {$code} has been placed successfully!", 'order']);

        // Notify each seller whose products are in this order
        $sellerStmt = $db->prepare('
            SELECT DISTINCT p.seller_id, GROUP_CONCAT(p.name SEPARATOR ", ") AS pnames
            FROM order_items oi
            JOIN products p ON oi.product_id = p.id
            WHERE oi.order_id = ?
            GROUP BY p.seller_id
        ');
        $sellerStmt->execute([$orderId]);
        foreach ($sellerStmt->fetchAll() as $row) {
            $db->prepare("INSERT INTO notifications (user_id, message, type) VALUES (?,?,?)")
               ->execute([$row['seller_id'], "New order {$code} received for: {$row['pnames']}", 'order']);
        }

        // Cleanup session
        unset($_SESSION['checkout_step'], $_SESSION['checkout_address'], $_SESSION['checkout_payment']);

        setToast('success', "Order {$code} placed successfully! 🎉");
        redirect('/pages/customer/orders.php?ordered=1');
    }
}

// ── Back navigation ───────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['go_back'])) {
    $step = (int)($_SESSION['checkout_step'] ?? 1);
    $_SESSION['checkout_step'] = max(1, $step - 1);
    redirect('/pages/customer/checkout.php');
}

$step    = (int)$_SESSION['checkout_step'];
$addr    = $_SESSION['checkout_address'] ?? [];
$payment = $_SESSION['checkout_payment'] ?? 'Cash on Delivery';

$paymentOptions = [
    'Cash on Delivery' => ['icon' => '💵', 'desc' => 'Pay when your order arrives'],
    'GCash'            => ['icon' => '📱', 'desc' => 'Instant transfer via GCash'],
    'Credit / Debit Card' => ['icon' => '💳', 'desc' => 'Visa, Mastercard accepted'],
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <?php $pageTitle = 'Checkout'; include '../../includes/head.php'; ?>
  <style>
    body { background: #f5f0ed; }

    /* ── Page wrapper ── */
    .co-wrap {
      max-width: 960px;
      margin: 0 auto;
      padding: 32px 24px 60px;
    }

    /* ── Back link ── */
    .co-back {
      display: inline-flex; align-items: center; gap: 4px;
      font-size: 13px; color: #555; text-decoration: none;
      margin-bottom: 16px;
      background: none; border: none; cursor: pointer; padding: 0;
    }
    .co-back:hover { color: #e01010; }

    /* ── Title ── */
    .co-title {
      font-size: 26px; font-weight: 800; color: #111;
      margin-bottom: 24px;
    }

    /* ── Stepper ── */
    .co-stepper {
      background: #fff;
      border: 1px solid #e8e3e0;
      border-radius: 12px;
      padding: 20px 28px;
      display: flex; align-items: center; justify-content: space-between;
      margin-bottom: 24px;
    }
    .co-step {
      display: flex; align-items: center; gap: 10px;
      flex: 1;
    }
    .co-step-num {
      width: 34px; height: 34px; border-radius: 50%;
      display: flex; align-items: center; justify-content: center;
      font-size: 14px; font-weight: 700; flex-shrink: 0;
    }
    .co-step-num.done   { background: #22c55e; color: #fff; }
    .co-step-num.active { background: #e01010; color: #fff; }
    .co-step-num.pending { background: #9ca3af; color: #fff; }
    .co-step-label {
      font-size: 13px; font-weight: 600;
    }
    .co-step-label.active  { color: #e01010; }
    .co-step-label.done    { color: #22c55e; }
    .co-step-label.pending { color: #9ca3af; }
    .co-step-line {
      flex: 1; height: 2px; background: #e5e7eb; margin: 0 10px;
      max-width: 80px;
    }
    .co-step-line.done { background: #22c55e; }

    /* ── Main layout ── */
    .co-layout {
      display: grid;
      grid-template-columns: 1fr 300px;
      gap: 22px;
      align-items: start;
    }

    /* ── Panel card ── */
    .co-panel {
      background: #fff;
      border: 1px solid #e8e3e0;
      border-radius: 12px;
      padding: 28px 26px 26px;
    }
    .co-panel-title {
      font-size: 15px; font-weight: 800; color: #111;
      margin-bottom: 22px;
      padding-bottom: 14px;
      border-bottom: 1px solid #f0ece9;
      display: flex; align-items: center; gap: 8px;
    }

    /* ── Address form ── */
    .form-row {
      display: grid; gap: 14px;
      margin-bottom: 14px;
    }
    .form-row-2 { grid-template-columns: 1fr 1fr; }
    .form-group { display: flex; flex-direction: column; gap: 5px; }
    .form-label {
      font-size: 10px; font-weight: 700; color: #888;
      text-transform: uppercase; letter-spacing: .6px;
    }
    .form-input {
      padding: 10px 13px;
      border: 1px solid #ddd; border-radius: 7px;
      font-size: 13px; color: #111;
      background: #fafafa;
      outline: none; transition: border .15s;
      font-family: inherit;
    }
    .form-input:focus { border-color: #e01010; background: #fff; }
    .form-input::placeholder { color: #bbb; }

    /* ── Continue button ── */
    .co-btn {
      margin-top: 20px;
      padding: 12px 28px;
      background: #e01010; color: #fff;
      border: none; border-radius: 7px;
      font-size: 14px; font-weight: 800;
      cursor: pointer; letter-spacing: .3px;
      transition: background .12s;
    }
    .co-btn:hover { background: #c00d0d; }

    /* ── Order summary (step 2) ── */
    .sum-item {
      display: flex; align-items: center; gap: 14px;
      padding: 14px 0;
      border-bottom: 1px solid #f0ece9;
    }
    .sum-item:last-child { border-bottom: none; }
    .sum-img {
      width: 58px; height: 58px; border-radius: 8px;
      background: #ececec; flex-shrink: 0;
      overflow: hidden; display: flex; align-items: center; justify-content: center;
    }
    .sum-img img { width: 100%; height: 100%; object-fit: cover; }
    .sum-img svg { width: 24px; height: 24px; color: #bbb; }
    .sum-name { font-size: 14px; font-weight: 600; color: #111; }
    .sum-qty  { font-size: 12px; color: #888; margin-top: 2px; }
    .sum-price { margin-left: auto; font-size: 14px; font-weight: 700; color: #111; flex-shrink: 0; }

    /* ── Payment options ── */
    .pay-option {
      border: 1.5px solid #e5e7eb;
      border-radius: 10px;
      padding: 16px 18px;
      margin-bottom: 12px;
      cursor: pointer;
      display: flex; align-items: center; gap: 14px;
      transition: border-color .15s, background .15s;
    }
    .pay-option.selected {
      border-color: #e01010;
      background: #fff5f5;
    }
    .pay-option input[type="radio"] { display: none; }
    .pay-icon { font-size: 22px; flex-shrink: 0; }
    .pay-label { font-size: 14px; font-weight: 700; color: #111; }
    .pay-desc  { font-size: 12px; color: #888; margin-top: 2px; }

    /* ── Confirm box ── */
    .confirm-box {
      background: #fefce8;
      border: 1px solid #fde68a;
      border-radius: 8px;
      padding: 18px 20px;
      margin-bottom: 18px;
    }
    .confirm-row {
      font-size: 13px; color: #333; margin-bottom: 8px;
      display: flex; align-items: flex-start; gap: 6px;
    }
    .confirm-row:last-child { margin-bottom: 0; }
    .confirm-row strong { color: #111; min-width: 80px; }

    /* ── Right: totals card ── */
    .totals-card {
      background: #fff;
      border: 1px solid #e8e3e0;
      border-radius: 12px;
      padding: 24px 22px;
    }
    .totals-title { font-size: 14px; font-weight: 800; color: #111; margin-bottom: 14px; }
    .totals-row {
      display: flex; justify-content: space-between;
      font-size: 13px; color: #666; padding: 5px 0;
    }
    .totals-divider { border: none; border-top: 1px solid #f0ece9; margin: 10px 0; }
    .totals-grand {
      display: flex; justify-content: space-between;
      font-size: 15px; font-weight: 800; color: #111;
      padding-top: 12px;
      border-top: 2px solid #e8e3e0;
      margin-top: 6px;
    }

    @media (max-width: 680px) {
      .co-layout { grid-template-columns: 1fr; }
      .form-row-2 { grid-template-columns: 1fr; }
      .co-stepper { padding: 14px 12px; }
      .co-step-line { max-width: 30px; }
    }
  </style>
</head>
<body>
<?php include '../../includes/nav.php'; ?>

<div class="co-wrap">

  <!-- Back -->
  <?php if ($step === 1): ?>
    <a href="<?= BASE_URL ?>/pages/customer/cart.php" class="co-back">&#8592; Back</a>
  <?php else: ?>
    <form method="POST" style="display:inline">
      <button type="submit" name="go_back" class="co-back">&#8592; Back</button>
    </form>
  <?php endif; ?>

  <div class="co-title">Checkout</div>

  <!-- ── Stepper ── -->
  <div class="co-stepper">
    <?php
      $steps = ['Address','Summary','Payment','Confirm'];
      foreach ($steps as $i => $label):
        $n    = $i + 1;
        $cls  = $n < $step ? 'done' : ($n === $step ? 'active' : 'pending');
    ?>
      <?php if ($i > 0): ?>
        <div class="co-step-line <?= $n <= $step ? 'done' : '' ?>"></div>
      <?php endif; ?>
      <div class="co-step">
        <div class="co-step-num <?= $cls ?>">
          <?php if ($cls === 'done'): ?>
            <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 13l4 4L19 7"/>
            </svg>
          <?php else: ?>
            <?= $n ?>
          <?php endif; ?>
        </div>
        <span class="co-step-label <?= $cls ?>"><?= $label ?></span>
      </div>
    <?php endforeach; ?>
  </div>

  <!-- ── Main layout ── -->
  <div class="co-layout">

    <!-- ════ LEFT PANEL ════ -->
    <div>

      <?php if ($step === 1): ?>
      <!-- STEP 1: Address -->
      <div class="co-panel">
        <div class="co-panel-title">📦 Shipping Address</div>
        <form method="POST">
          <div class="form-row form-row-2">
            <div class="form-group">
              <label class="form-label">Full Name</label>
              <input class="form-input" type="text" name="full_name"
                     placeholder="Juan Dela Cruz"
                     value="<?= sanitize($addr['fullName'] ?? $user['full_name']) ?>" required>
            </div>
            <div class="form-group">
              <label class="form-label">Phone</label>
              <input class="form-input" type="text" name="phone"
                     placeholder="09XX XXX XXXX"
                     value="<?= sanitize($addr['phone'] ?? '') ?>" required>
            </div>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label class="form-label">Street Address</label>
              <input class="form-input" type="text" name="street"
                     placeholder="House No., Brgy., Street"
                     value="<?= sanitize($addr['street'] ?? '') ?>" required>
            </div>
          </div>
          <div class="form-row form-row-2">
            <div class="form-group">
              <label class="form-label">City</label>
              <input class="form-input" type="text" name="city"
                     placeholder="Davao City"
                     value="<?= sanitize($addr['city'] ?? '') ?>" required>
            </div>
            <div class="form-group">
              <label class="form-label">Zip Code</label>
              <input class="form-input" type="text" name="zip"
                     placeholder="8000"
                     value="<?= sanitize($addr['zip'] ?? '') ?>" required>
            </div>
          </div>
          <button type="submit" name="save_address" class="co-btn">Continue</button>
        </form>
      </div>

      <?php elseif ($step === 2): ?>
      <!-- STEP 2: Order Summary -->
      <div class="co-panel">
        <div class="co-panel-title">🗒 Order Summary</div>
        <?php foreach ($cartItems as $item): ?>
          <div class="sum-item">
            <div class="sum-img">
              <?php if (!empty($item['image'])): ?>
                <img src="<?= BASE_URL . '/' . sanitize($item['image']) ?>" alt="">
              <?php else: ?>
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.2"
                    d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0
                       012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2
                       2 0 00-2 2v12a2 2 0 002 2z"/>
                </svg>
              <?php endif; ?>
            </div>
            <div>
              <div class="sum-name"><?= sanitize($item['name']) ?></div>
              <div class="sum-qty">Qty. <?= $item['quantity'] ?></div>
            </div>
            <div class="sum-price"><?= formatPrice($item['price'] * $item['quantity']) ?></div>
          </div>
        <?php endforeach; ?>
        <form method="POST">
          <button type="submit" name="confirm_summary" class="co-btn">Continue</button>
        </form>
      </div>

      <?php elseif ($step === 3): ?>
      <!-- STEP 3: Payment -->
      <div class="co-panel">
        <div class="co-panel-title">💳 Payment Method</div>
        <form method="POST" id="payForm">
          <?php foreach ($paymentOptions as $key => $opt):
            $sel = ($payment === $key) ? 'selected' : '';
          ?>
            <label class="pay-option <?= $sel ?>" onclick="selectPay(this, '<?= htmlspecialchars($key) ?>')">
              <input type="radio" name="payment_method" value="<?= htmlspecialchars($key) ?>"
                     <?= $sel ? 'checked' : '' ?>>
              <div class="pay-icon"><?= $opt['icon'] ?></div>
              <div>
                <div class="pay-label"><?= $key ?></div>
                <div class="pay-desc"><?= $opt['desc'] ?></div>
              </div>
            </label>
          <?php endforeach; ?>
          <button type="submit" name="save_payment" class="co-btn">Continue</button>
        </form>
      </div>

      <?php elseif ($step === 4): ?>
      <!-- STEP 4: Confirm -->
      <div class="co-panel">
        <div class="co-panel-title">✅ Confirm Order</div>
        <div class="confirm-box">
          <div class="confirm-row">
            <strong>Ship to:</strong>
            <span>
              <?= sanitize($addr['street'] ?? 'N/A') ?>,
              <?= sanitize($addr['city']   ?? '') ?>
              <?= sanitize($addr['zip']    ?? '') ?>
            </span>
          </div>
          <div class="confirm-row">
            <strong>Payment:</strong>
            <span><?= sanitize($payment) ?></span>
          </div>
        </div>
        <form method="POST">
          <button type="submit" name="place_order" class="co-btn">Place Order</button>
        </form>
      </div>
      <?php endif; ?>

    </div>

    <!-- ════ RIGHT: Totals ════ -->
    <div>
      <div class="totals-card">
        <div class="totals-title">Total</div>
        <div class="totals-row">
          <span>Subtotal</span>
          <span><?= formatPrice($subtotal) ?></span>
        </div>
        <div class="totals-row">
          <span>Shipping</span>
          <span><?= formatPrice($shipping) ?></span>
        </div>
        <hr class="totals-divider">
        <div class="totals-grand">
          <span>GRAND TOTAL</span>
          <span><?= formatPrice($grandTotal) ?></span>
        </div>
      </div>
    </div>

  </div><!-- /.co-layout -->
</div>

<script>
function selectPay(el, val) {
  document.querySelectorAll('.pay-option').forEach(o => o.classList.remove('selected'));
  el.classList.add('selected');
  el.querySelector('input[type=radio]').checked = true;
}
</script>
<?php include '../../includes/toast.php'; ?>
</body>
</html>
