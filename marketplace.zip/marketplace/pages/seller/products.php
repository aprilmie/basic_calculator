<?php
// ── Seller – My Products ─────────────────────────────────────────────────────
session_start();
require_once '../../includes/config.php';
requireRole('seller');

$user  = currentUser();
$db    = getDB();

// ── Handle form actions ───────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // Add or edit a product
    if ($action === 'add_product' || $action === 'edit_product') {
        $name   = trim($_POST['name']        ?? '');
        $desc   = trim($_POST['description'] ?? '');
        $price  = (float) $_POST['price'];
        $stock  = (int)   $_POST['stock'];
        $cat    = (int)   $_POST['category_id'];
        $status = $_POST['status'] ?? 'active';

        // ── Handle image upload ───────────────────────────────────────────────
        $imgPath = null;
        $file    = $_FILES['image'] ?? null;
        if ($file && $file['error'] === 0) {
            $ext     = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
            if (in_array($ext, $allowed)) {
                $dir = '../../uploads/products/';
                if (!is_dir($dir)) mkdir($dir, 0775, true);
                $filename = 'product_' . time() . '_' . uniqid() . '.' . $ext;
                move_uploaded_file($file['tmp_name'], $dir . $filename);
                $imgPath = 'uploads/products/' . $filename;
            }
        }

        if ($action === 'add_product') {
            $db->prepare('
                INSERT INTO products (seller_id, category_id, name, description, price, stock, image, status)
                VALUES (?,?,?,?,?,?,?,?)
            ')->execute([$user['id'], $cat, $name, $desc, $price, $stock, $imgPath, $status]);
            setToast('success', 'Product added successfully.');
            redirect('/pages/seller/products.php');
        } else {
            $pid = (int) $_POST['product_id'];
            if ($imgPath) {
                // New image — delete old file first
                $old = $db->prepare('SELECT image FROM products WHERE id = ? AND seller_id = ?');
                $old->execute([$pid, $user['id']]);
                $oldRow = $old->fetch();
                if ($oldRow && $oldRow['image'] && file_exists('../../' . $oldRow['image'])) {
                    unlink('../../' . $oldRow['image']);
                }
                $db->prepare('
                    UPDATE products
                    SET category_id=?, name=?, description=?, price=?, stock=?, image=?, status=?
                    WHERE id=? AND seller_id=?
                ')->execute([$cat, $name, $desc, $price, $stock, $imgPath, $status, $pid, $user['id']]);
            } else {
                // No new image — keep existing
                $db->prepare('
                    UPDATE products
                    SET category_id=?, name=?, description=?, price=?, stock=?, status=?
                    WHERE id=? AND seller_id=?
                ')->execute([$cat, $name, $desc, $price, $stock, $status, $pid, $user['id']]);
            }
            setToast('success', 'Product updated.');
            redirect('/pages/seller/products.php');
        }
    }

    // Delete a product (seller can only delete their own)
    if ($action === 'delete_product') {
        $pid = (int) $_POST['product_id'];
        // Verify ownership before deleting
        $check = $db->prepare('SELECT id, image FROM products WHERE id = ? AND seller_id = ?');
        $check->execute([$pid, $user['id']]);
        $row = $check->fetch();
        if ($row) {
            if ($row['image'] && file_exists('../../' . $row['image'])) {
                unlink('../../' . $row['image']);
            }
            $db->prepare('DELETE FROM cart        WHERE product_id = ?')->execute([$pid]);
            $db->prepare('DELETE FROM order_items WHERE product_id = ?')->execute([$pid]);
            $db->prepare('DELETE FROM products    WHERE id = ? AND seller_id = ?')->execute([$pid, $user['id']]);
            setToast('success', 'Product deleted.');
        }
        redirect('/pages/seller/products.php');
    }
}


// ── Data for the page ─────────────────────────────────────────────────────────
$productStmt = $db->prepare('
    SELECT p.*, c.name AS cat_name
    FROM products p
    LEFT JOIN categories c ON p.category_id = c.id
    WHERE p.seller_id = ?
    ORDER BY p.created_at DESC
');
$productStmt->execute([$user['id']]);
$products = $productStmt->fetchAll();

$cats = $db->query('SELECT * FROM categories ORDER BY name')->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <?php $pageTitle = 'My Products'; include '../../includes/head.php'; ?>
</head>
<body>
<?php include '../../includes/nav.php'; ?>

<div class="dash-layout">
  <?php include '../../includes/seller_sidebar.php'; ?>

  <main class="dash-main">
    <div class="section-header">
      <div>
        <div class="dash-page-title">My Products</div>
        <div class="dash-page-sub"><?= count($products) ?> products listed</div>
      </div>
      <button class="btn btn-red" onclick="openModal('addModal')">+ Add Product</button>
    </div>

    <!-- Products table -->
    <div class="dash-table-card">
      <table class="dash-table">
        <thead>
          <tr>
            <th>Image</th>
            <th>Name</th>
            <th>Category</th>
            <th>Price</th>
            <th>Stock</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($products)): ?>
            <tr>
              <td colspan="7" style="text-align:center;padding:40px;color:#888">No products yet.</td>
            </tr>
          <?php else: ?>
            <?php foreach ($products as $p): ?>
              <tr>
                <td>
                  <?php if (!empty($p['image'])): ?>
                    <img src="<?= BASE_URL . '/' . sanitize($p['image']) ?>" alt=""
                         style="width:44px;height:44px;object-fit:cover;border-radius:4px;border:1px solid #e5e7eb;">
                  <?php else: ?>
                    <div style="width:44px;height:44px;background:#f3f4f6;border-radius:4px;display:flex;align-items:center;justify-content:center;">
                      <svg width="18" height="18" fill="none" stroke="#9ca3af" viewBox="0 0 24 24">
                        <rect x="3" y="3" width="18" height="18" rx="2" stroke-width="1.5"/>
                        <circle cx="8.5" cy="8.5" r="1.5" stroke-width="1.5"/>
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M21 15l-5-5L5 21"/>
                      </svg>
                    </div>
                  <?php endif; ?>
                </td>
                <td><strong><?= sanitize($p['name']) ?></strong></td>
                <td><?= sanitize($p['cat_name'] ?? '') ?></td>
                <td><?= formatPrice($p['price']) ?></td>
                <td><?= $p['stock'] ?></td>
                <td><span class="badge badge-<?= $p['status'] ?>"><?= strtoupper($p['status']) ?></span></td>
                <td>
                  <div class="action-btns">
                    <!-- Edit: passes product data to JS to populate the edit modal -->
                    <button class="btn btn-sm" style="background:#16a34a;color:#fff;border:none;border-radius:20px;font-weight:700;letter-spacing:.5px;padding:6px 16px;"
                      onclick="editProduct(<?= htmlspecialchars(json_encode($p), ENT_QUOTES) ?>)">
                      EDIT
                    </button>
                    <form method="POST" data-confirm="Delete this product?">
                      <input type="hidden" name="action"     value="delete_product">
                      <input type="hidden" name="product_id" value="<?= $p['id'] ?>">
                      <button type="submit" class="btn btn-sm"
                              style="background:#e01010;color:#fff;border:none;border-radius:20px;font-weight:700;letter-spacing:.5px;padding:6px 16px;">DELETE</button>
                    </form>
                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </main>
</div>

<!-- ── Add Product Modal ──────────────────────────────────────────────────── -->
<div class="modal-overlay" id="addModal">
  <div class="modal">
    <button class="modal-close" onclick="closeModal('addModal')">&times;</button>
    <div class="modal-title">Add New Product</div>
    <form method="POST" enctype="multipart/form-data">
      <input type="hidden" name="action" value="add_product">

      <!-- Image upload -->
      <div class="form-group">
        <label class="form-label">Product Image</label>
        <div class="product-img-upload" onclick="document.getElementById('addImgInput').click()">
          <img id="addImgPreview" src="" alt="" style="display:none;">
          <svg id="addImgIcon" width="32" height="32" fill="none" stroke="#9ca3af" viewBox="0 0 24 24" style="margin:0 auto 6px;">
            <rect x="3" y="3" width="18" height="18" rx="2" stroke-width="1.5"/>
            <circle cx="8.5" cy="8.5" r="1.5" stroke-width="1.5"/>
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M21 15l-5-5L5 21"/>
          </svg>
          <span>Click to upload image (JPG, PNG, WEBP)</span>
          <input type="file" name="image" id="addImgInput" accept="image/*" style="display:none"
                 onchange="previewImg(this, 'addImgPreview', 'addImgIcon')">
        </div>
      </div>

      <div class="form-group">
        <label class="form-label">Product Name</label>
        <input type="text" name="name" class="form-control" required>
      </div>
      <div class="form-group">
        <label class="form-label">Description</label>
        <textarea name="description" class="form-control"></textarea>
      </div>
      <div class="form-grid-2">
        <div class="form-group">
          <label class="form-label">Price (₱)</label>
          <input type="number" step="0.01" name="price" class="form-control" required>
        </div>
        <div class="form-group">
          <label class="form-label">Stock</label>
          <input type="number" name="stock" class="form-control" value="0">
        </div>
      </div>
      <div class="form-grid-2">
        <div class="form-group">
          <label class="form-label">Category</label>
          <select name="category_id" class="form-control">
            <?php foreach ($cats as $c): ?>
              <option value="<?= $c['id'] ?>"><?= sanitize($c['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Status</label>
          <select name="status" class="form-control">
            <option value="active">Active</option>
            <option value="sold_out">Sold Out</option>
            <option value="inactive">Inactive</option>
          </select>
        </div>
      </div>
      <button type="submit" class="btn btn-red btn-full" style="margin-top:8px">Add Product</button>
    </form>
  </div>
</div>

<!-- ── Edit Product Modal ─────────────────────────────────────────────────── -->
<div class="modal-overlay" id="editModal">
  <div class="modal">
    <button class="modal-close" onclick="closeModal('editModal')">&times;</button>
    <div class="modal-title">Edit Product</div>
    <form method="POST" enctype="multipart/form-data">
      <input type="hidden" name="action"     value="edit_product">
      <input type="hidden" name="product_id" id="edit-pid">

      <!-- Image upload -->
      <div class="form-group">
        <label class="form-label">Product Image</label>
        <div class="product-img-upload" onclick="document.getElementById('editImgInput').click()">
          <img id="editImgPreview" src="" alt="" style="display:none;">
          <svg id="editImgIcon" width="32" height="32" fill="none" stroke="#9ca3af" viewBox="0 0 24 24" style="margin:0 auto 6px;">
            <rect x="3" y="3" width="18" height="18" rx="2" stroke-width="1.5"/>
            <circle cx="8.5" cy="8.5" r="1.5" stroke-width="1.5"/>
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M21 15l-5-5L5 21"/>
          </svg>
          <span id="editImgLabel">Click to upload image (leave blank to keep current)</span>
          <input type="file" name="image" id="editImgInput" accept="image/*" style="display:none"
                 onchange="previewImg(this, 'editImgPreview', 'editImgIcon')">
        </div>
      </div>

      <div class="form-group">
        <label class="form-label">Product Name</label>
        <input type="text" name="name" id="edit-name" class="form-control" required>
      </div>
      <div class="form-group">
        <label class="form-label">Description</label>
        <textarea name="description" id="edit-desc" class="form-control"></textarea>
      </div>
      <div class="form-grid-2">
        <div class="form-group">
          <label class="form-label">Price (₱)</label>
          <input type="number" step="0.01" name="price" id="edit-price" class="form-control">
        </div>
        <div class="form-group">
          <label class="form-label">Stock</label>
          <input type="number" name="stock" id="edit-stock" class="form-control">
        </div>
      </div>
      <div class="form-grid-2">
        <div class="form-group">
          <label class="form-label">Category</label>
          <select name="category_id" id="edit-cat" class="form-control">
            <?php foreach ($cats as $c): ?>
              <option value="<?= $c['id'] ?>"><?= sanitize($c['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Status</label>
          <select name="status" id="edit-status" class="form-control">
            <option value="active">Active</option>
            <option value="sold_out">Sold Out</option>
            <option value="inactive">Inactive</option>
          </select>
        </div>
      </div>
      <button type="submit" class="btn btn-red btn-full" style="margin-top:8px">Save Changes</button>
    </form>
  </div>
</div>

<script>
  function openModal(id)  { document.getElementById(id).classList.add('open'); }
  function closeModal(id) { document.getElementById(id).classList.remove('open'); }

  // Shared image preview helper
  function previewImg(input, previewId, iconId) {
    if (input.files && input.files[0]) {
      const reader = new FileReader();
      reader.onload = e => {
        const preview = document.getElementById(previewId);
        const icon    = document.getElementById(iconId);
        preview.src           = e.target.result;
        preview.style.display = 'block';
        icon.style.display    = 'none';
      };
      reader.readAsDataURL(input.files[0]);
    }
  }

  // Populate the edit modal fields from the product data object
  function editProduct(p) {
    document.getElementById('edit-pid').value    = p.id;
    document.getElementById('edit-name').value   = p.name;
    document.getElementById('edit-desc').value   = p.description ?? '';
    document.getElementById('edit-price').value  = p.price;
    document.getElementById('edit-stock').value  = p.stock;
    document.getElementById('edit-cat').value    = p.category_id;
    document.getElementById('edit-status').value = p.status;

    // Show existing image or placeholder
    const preview = document.getElementById('editImgPreview');
    const icon    = document.getElementById('editImgIcon');
    const label   = document.getElementById('editImgLabel');
    if (p.image) {
      preview.src           = '<?= BASE_URL ?>/' + p.image;
      preview.style.display = 'block';
      icon.style.display    = 'none';
      label.textContent     = 'Click to change image';
    } else {
      preview.style.display = 'none';
      icon.style.display    = 'block';
      label.textContent     = 'Click to upload image (leave blank to keep none)';
    }
    // Reset file input so old selection doesn't linger
    document.getElementById('editImgInput').value = '';
    openModal('editModal');
  }
</script>
<?php include '../../includes/toast.php'; ?>
</body>
</html>
