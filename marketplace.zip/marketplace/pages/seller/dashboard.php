<?php
// ── Seller – Dashboard ───────────────────────────────────────────────────────
session_start();
require_once '../../includes/config.php';
requireRole('seller');

$user = currentUser();
$db   = getDB();

// ── Stats ─────────────────────────────────────────────────────────────────────
$totalProductsStmt = $db->prepare('SELECT COUNT(*) FROM products WHERE seller_id = ?');
$totalProductsStmt->execute([$user['id']]);
$totalProducts = $totalProductsStmt->fetchColumn();

$totalSalesStmt = $db->prepare('
    SELECT COALESCE(SUM(oi.price * oi.quantity), 0)
    FROM order_items oi
    JOIN products p ON oi.product_id = p.id
    WHERE p.seller_id = ?
');
$totalSalesStmt->execute([$user['id']]);
$totalSales = $totalSalesStmt->fetchColumn();

$totalOrdersStmt = $db->prepare('
    SELECT COUNT(DISTINCT o.id)
    FROM orders o
    JOIN order_items oi ON o.id = oi.order_id
    JOIN products p     ON oi.product_id = p.id
    WHERE p.seller_id = ?
');
$totalOrdersStmt->execute([$user['id']]);
$totalOrders = $totalOrdersStmt->fetchColumn();

// ── Weekly sales (Mon–Sun of current week) ────────────────────────────────────
$weeklyStmt = $db->prepare('
    SELECT DAYOFWEEK(o.created_at) AS dow,
           COALESCE(SUM(oi.price * oi.quantity), 0) AS total
    FROM orders o
    JOIN order_items oi ON o.id = oi.order_id
    JOIN products p     ON oi.product_id = p.id
    WHERE p.seller_id = ?
      AND o.created_at >= DATE(NOW()) - INTERVAL WEEKDAY(NOW()) DAY
      AND o.created_at <  DATE(NOW()) - INTERVAL WEEKDAY(NOW()) DAY + INTERVAL 7 DAY
    GROUP BY DAYOFWEEK(o.created_at)
');
$weeklyStmt->execute([$user['id']]);
$weeklyRaw = $weeklyStmt->fetchAll(PDO::FETCH_KEY_PAIR);

// DAYOFWEEK: 1=Sun,2=Mon,...,7=Sat → map to Mon(0)–Sun(6)
$dayMap = [2 => 0, 3 => 1, 4 => 2, 5 => 3, 6 => 4, 7 => 5, 1 => 6];
$weeklyData = array_fill(0, 7, 0);
foreach ($weeklyRaw as $dow => $total) {
    $weeklyData[$dayMap[$dow]] = (float)$total;
}
$maxWeekly = max(array_merge($weeklyData, [1]));

$firstName = explode(' ', trim($user['full_name']))[0];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <?php $pageTitle = 'Seller Dashboard'; include '../../includes/head.php'; ?>
  <style>
    .weekly-chart {
      background: #fff;
      border: 1px solid #e8e3e0;
      border-radius: 14px;
      padding: 24px 28px 20px;
      margin-top: 20px;
    }
    .weekly-chart-title {
      font-size: 15px;
      font-weight: 800;
      color: #111;
      margin-bottom: 20px;
      letter-spacing: .3px;
    }
    .bar-chart-wrap {
      display: flex;
      align-items: flex-end;
      justify-content: space-between;
      gap: 10px;
      height: 160px;
    }
    .bar-col {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      height: 100%;
    }
    .bar-spacer { flex: 1; }
    .bar-body {
      width: 100%;
      background: #e01010;
      border-radius: 6px 6px 3px 3px;
      min-height: 6px;
      transition: height .3s ease;
    }
    .bar-body.empty { background: #f0f0f0; }
    .bar-day-label {
      margin-top: 8px;
      font-size: 10px;
      font-weight: 700;
      letter-spacing: 1px;
      text-transform: uppercase;
      color: #aaa;
      white-space: nowrap;
    }
    .bar-amount {
      font-size: 9px;
      color: #bbb;
      margin-bottom: 4px;
      font-weight: 600;
    }
  </style>
</head>
<body>
<?php include '../../includes/nav.php'; ?>

<div class="dash-layout">
  <?php include '../../includes/seller_sidebar.php'; ?>

  <main class="dash-main">
    <div class="dash-page-title">Welcome, <?= sanitize($firstName) ?>!</div>
    <div class="dash-page-sub">Welcome back, <?= sanitize($firstName) ?></div>

    <!-- Stat cards -->
    <div class="dash-stat-grid">
      <div class="dash-stat-card">
        <div class="dash-stat-num"><?= formatPrice($totalSales) ?></div>
        <div class="dash-stat-label">Total Revenue</div>
      </div>
      <div class="dash-stat-card">
        <div class="dash-stat-num"><?= $totalProducts ?></div>
        <div class="dash-stat-label">Product Listed</div>
      </div>
      <div class="dash-stat-card">
        <div class="dash-stat-num"><?= $totalOrders ?></div>
        <div class="dash-stat-label">Orders Received</div>
      </div>
    </div>

    <!-- Weekly Sales Bar Chart -->
    <div class="weekly-chart">
      <div class="weekly-chart-title">Weekly Sales</div>
      <div class="bar-chart-wrap">
        <?php
        $days = ['MON','TUE','WED','THU','FRI','SAT','SUN'];
        foreach ($days as $i => $day):
          $val   = $weeklyData[$i];
          $pct   = $maxWeekly > 0 ? $val / $maxWeekly : 0;
          $px    = max((int)($pct * 140), $val > 0 ? 8 : 4);
          $empty = $val == 0;
        ?>
        <div class="bar-col">
          <div class="bar-spacer"></div>
          <?php if (!$empty): ?>
            <div class="bar-amount">₱<?= number_format($val, 0) ?></div>
          <?php endif; ?>
          <div class="bar-body <?= $empty ? 'empty' : '' ?>" style="height:<?= $px ?>px"></div>
          <div class="bar-day-label"><?= $day ?></div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>

  </main>
</div>

<?php include '../../includes/toast.php'; ?>
</body>
</html>
