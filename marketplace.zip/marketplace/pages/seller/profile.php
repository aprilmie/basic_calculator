<?php
// ── Seller – My Profile ──────────────────────────────────────────────────────
session_start();
require_once '../../includes/config.php';
requireRole('seller');

$user = currentUser();
$db   = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'upload_avatar') {
        $file = $_FILES['avatar'] ?? null;
        if ($file && $file['error'] === 0) {
            $ext     = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            $allowed = ['jpg','jpeg','png','gif','webp'];
            if (in_array($ext, $allowed)) {
                $dir = '../../uploads/avatars/';
                if (!is_dir($dir)) mkdir($dir, 0775, true);
                if ($user['avatar'] && file_exists('../../' . $user['avatar'])) unlink('../../' . $user['avatar']);
                $filename = 'avatar_' . $user['id'] . '_' . time() . '.' . $ext;
                move_uploaded_file($file['tmp_name'], $dir . $filename);
                $db->prepare('UPDATE users SET avatar = ? WHERE id = ?')
                   ->execute(['uploads/avatars/' . $filename, $user['id']]);
                setToast('success', 'Profile photo updated.');
                redirect('/pages/seller/profile.php');
            } else {
                setToast('error', 'Only JPG, PNG, GIF, WEBP allowed.');
                redirect('/pages/seller/profile.php');
            }
        }
    }

    if ($action === 'update_profile') {
        $db->prepare('UPDATE users SET full_name=?, email=?, phone=?, address=?, bio=? WHERE id=?')
           ->execute([
               trim($_POST['full_name']  ?? ''),
               trim($_POST['email']      ?? ''),
               trim($_POST['phone']      ?? ''),
               trim($_POST['address']    ?? ''),
               trim($_POST['bio']        ?? ''),
               $user['id'],
           ]);
        setToast('success', 'Profile updated successfully.');
        redirect('/pages/seller/profile.php');
    }

    if ($action === 'change_password') {
        $current = $_POST['current_password'] ?? '';
        $new     = $_POST['new_password']     ?? '';
        $confirm = $_POST['confirm_password'] ?? '';

        if (!password_verify($current, $user['password'])) {
            setToast('error', 'Current password is incorrect.');
            redirect('/pages/seller/profile.php');
        } elseif ($new !== $confirm) {
            setToast('error', 'New passwords do not match.');
            redirect('/pages/seller/profile.php');
        } elseif (strlen($new) < 6) {
            setToast('error', 'Password must be at least 6 characters.');
            redirect('/pages/seller/profile.php');
        } else {
            $db->prepare('UPDATE users SET password = ? WHERE id = ?')
               ->execute([password_hash($new, PASSWORD_DEFAULT), $user['id']]);
            setToast('success', 'Password updated successfully.');
            redirect('/pages/seller/profile.php');
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <?php $pageTitle = 'My Profile'; include '../../includes/head.php'; ?>
  <style>
    .profile-grid {
      display: grid;
      grid-template-columns: 300px 1fr;
      gap: 20px;
      align-items: start;
    }
    /* ── Left card ── */
    .profile-card {
      background: #fff;
      border: 1px solid #ddd;
      border-radius: 14px;
      padding: 32px 24px 24px;
    }
    .profile-avatar-wrap {
      display: flex;
      flex-direction: column;
      align-items: center;
      text-align: center;
      margin-bottom: 20px;
    }
    .profile-avatar {
      width: 110px;
      height: 110px;
      border-radius: 50%;
      background: linear-gradient(135deg, #3b3fcf, #6b21a8);
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 36px;
      font-weight: 700;
      margin-bottom: 14px;
      overflow: hidden;
    }
    .profile-avatar img { width: 100%; height: 100%; object-fit: cover; border-radius: 50%; }
    .avatar-upload-input { display: none; }
    .avatar-upload-btn {
      font-size: 12px;
      font-weight: 600;
      color: var(--red);
      cursor: pointer;
      background: none;
      border: 1.5px solid var(--red);
      border-radius: 4px;
      padding: 4px 12px;
      margin-bottom: 10px;
      display: inline-block;
      transition: all .12s;
    }
    .avatar-upload-btn:hover { background: var(--red); color: #fff; }
    .profile-name { font-size: 22px; font-weight: 800; margin-bottom: 2px; }
    .profile-email { font-size: 13px; color: #999; margin-bottom: 10px; }
    .profile-role-badge { margin-bottom: 0; }
    .badge-seller-red {
      display: inline-block;
      background: #e01010;
      color: #fff;
      font-size: 11px;
      font-weight: 800;
      letter-spacing: 1px;
      text-transform: uppercase;
      padding: 5px 18px;
      border-radius: 6px;
    }
    .profile-divider { border: none; border-top: 1px solid #e8e3e0; margin: 18px 0; }
    .profile-contact {
      display: flex;
      flex-direction: column;
      gap: 10px;
      font-size: 14px;
      color: #444;
    }
    .profile-contact-row {
      display: flex;
      align-items: center;
      gap: 10px;
    }
    .profile-contact-row svg { flex-shrink: 0; color: #555; }
    /* ── Account info card ── */
    .account-info-card {
      background: #fff;
      border: 1px solid #ddd;
      border-radius: 14px;
      padding: 20px 24px;
      margin-top: 16px;
    }
    .account-info-title {
      font-size: 11px;
      font-weight: 700;
      letter-spacing: 1.2px;
      text-transform: uppercase;
      color: #aaa;
      margin-bottom: 14px;
    }
    .info-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 14px;
      margin-bottom: 10px;
      color: #333;
    }
    /* ── Right form cards ── */
    .form-card {
      background: #fff;
      border: 1px solid #ddd;
      border-radius: 14px;
      padding: 28px 28px 32px;
      margin-bottom: 20px;
    }
    .form-card-title {
      font-size: 22px;
      font-weight: 800;
      margin-bottom: 22px;
      color: #111;
    }
    .form-grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
    .form-group { margin-bottom: 16px; }
    .form-label {
      display: block;
      font-size: 11px;
      font-weight: 700;
      letter-spacing: 1px;
      text-transform: uppercase;
      color: #888;
      margin-bottom: 6px;
    }
    .form-control {
      width: 100%;
      padding: 11px 14px;
      border: 1.5px solid #ddd;
      border-radius: 8px;
      font-size: 14px;
      color: #333;
      background: #fff;
      box-sizing: border-box;
      transition: border-color .15s;
      font-family: inherit;
    }
    .form-control:focus { outline: none; border-color: #e01010; }
    .btn-red-profile {
      background: #e01010;
      color: #fff;
      border: none;
      padding: 13px 28px;
      font-size: 13px;
      font-weight: 800;
      letter-spacing: 1px;
      text-transform: uppercase;
      border-radius: 8px;
      cursor: pointer;
      transition: background .15s;
    }
    .btn-red-profile:hover { background: #c00; }
    .btn-dark-profile {
      background: #222;
      color: #fff;
      border: none;
      padding: 13px 28px;
      font-size: 13px;
      font-weight: 800;
      letter-spacing: 1px;
      text-transform: uppercase;
      border-radius: 8px;
      cursor: pointer;
      transition: background .15s;
    }
    .btn-dark-profile:hover { background: #444; }
    @media (max-width: 768px) {
      .profile-grid { grid-template-columns: 1fr; }
      .form-grid-2  { grid-template-columns: 1fr; }
    }
  </style>
</head>
<body>
<?php include '../../includes/nav.php'; ?>

<div class="dash-layout">
  <?php include '../../includes/seller_sidebar.php'; ?>

  <main class="dash-main">
    <div class="dash-page-title">My Profile</div>
    <div class="dash-page-sub">Manage your personal information and account settings</div>

    <div class="profile-grid">

      <!-- Left column -->
      <div>
        <div class="profile-card">
          <div class="profile-avatar-wrap">
            <div class="profile-avatar">
              <?php if (!empty($user['avatar'])): ?>
                <img src="<?= BASE_URL . '/' . sanitize($user['avatar']) ?>" alt="Avatar">
              <?php else: ?>
                <?= getInitials($user['full_name']) ?>
              <?php endif; ?>
            </div>
            <div class="profile-name"><?= sanitize($user['full_name']) ?></div>
            <div class="profile-email"><?= sanitize($user['email']) ?></div>
            <div class="profile-role-badge">
              <span class="badge-seller-red">SELLER</span>
            </div>
          </div>

          <hr class="profile-divider">

          <div class="profile-contact">
            <?php if ($user['phone']): ?>
              <div class="profile-contact-row">
                <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498A1 1 0 0121 15.72V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/>
                </svg>
                <?= sanitize($user['phone']) ?>
              </div>
            <?php endif; ?>
            <?php if ($user['address']): ?>
              <div class="profile-contact-row">
                <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/>
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/>
                </svg>
                <?= sanitize($user['address']) ?>
              </div>
            <?php endif; ?>
          </div>

          <!-- Change photo form -->
          <form method="POST" enctype="multipart/form-data" style="text-align:center;margin-top:16px">
            <input type="hidden" name="action" value="upload_avatar">
            <input type="file" name="avatar" accept="image/*" class="avatar-upload-input" id="avatarInput"
                   onchange="this.form.submit()">
            <label for="avatarInput" class="avatar-upload-btn">Change Photo</label>
          </form>
        </div>

        <!-- Account Info -->
        <div class="account-info-card">
          <div class="account-info-title">Account Info</div>
          <div class="info-row">
            <span style="color:#555">Role</span>
            <span class="badge-seller-red">SELLER</span>
          </div>
          <div class="info-row">
            <span style="color:#555">Member since</span>
            <span style="font-weight:600"><?= date('M Y', strtotime($user['created_at'])) ?></span>
          </div>
          <div class="info-row">
            <span style="color:#555">Status</span>
            <span class="badge badge-<?= $user['status'] ?>"><?= strtoupper($user['status']) ?></span>
          </div>
        </div>
      </div>

      <!-- Right column -->
      <div>
        <!-- Personal Information -->
        <div class="form-card">
          <div class="form-card-title">Personal Information</div>
          <form method="POST">
            <input type="hidden" name="action" value="update_profile">
            <div class="form-grid-2">
              <div class="form-group">
                <label class="form-label">Full Name</label>
                <input type="text" name="full_name" class="form-control"
                       value="<?= sanitize($user['full_name']) ?>" required>
              </div>
              <div class="form-group">
                <label class="form-label">Email Address</label>
                <input type="email" name="email" class="form-control"
                       value="<?= sanitize($user['email']) ?>" required>
              </div>
              <div class="form-group">
                <label class="form-label">Phone Number</label>
                <input type="text" name="phone" class="form-control"
                       value="<?= sanitize($user['phone'] ?? '') ?>">
              </div>
              <div class="form-group">
                <label class="form-label">Address</label>
                <input type="text" name="address" class="form-control"
                       value="<?= sanitize($user['address'] ?? '') ?>">
              </div>
            </div>
            <div class="form-group">
              <label class="form-label">Full Name</label>
              <textarea name="bio" class="form-control" rows="4"
                        placeholder="tell us about yourself..."><?= sanitize($user['bio'] ?? '') ?></textarea>
            </div>
            <button type="submit" class="btn-red-profile">SAVE CHANGES</button>
          </form>
        </div>

        <!-- Change Password -->
        <div class="form-card">
          <div class="form-card-title">Change Password</div>
          <form method="POST">
            <input type="hidden" name="action" value="change_password">
            <div class="form-group">
              <label class="form-label">Current Password</label>
              <input type="password" name="current_password" class="form-control">
            </div>
            <div class="form-grid-2">
              <div class="form-group">
                <label class="form-label">New Password</label>
                <input type="password" name="new_password" class="form-control">
              </div>
              <div class="form-group">
                <label class="form-label">Confirm Password</label>
                <input type="password" name="confirm_password" class="form-control">
              </div>
            </div>
            <button type="submit" class="btn-dark-profile">UPDATE PASSWORD</button>
          </form>
        </div>
      </div>

    </div>
  </main>
</div>
<?php include '../../includes/toast.php'; ?>
</body>
</html>
