<?php
// ── Seller – Orders ──────────────────────────────────────────────────────────
session_start();
require_once '../../includes/config.php';
requireRole('seller');

$user  = currentUser();
$db    = getDB();

// ── Update order status ───────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $orderId = (int) $_POST['order_id'];
    $status  = $_POST['status'];
    $allowed = ['paid', 'shipped', 'delivered', 'cancelled'];

    if (in_array($status, $allowed)) {
        $ownsOrder = $db->prepare('
            SELECT COUNT(*)
            FROM order_items oi
            JOIN products p ON oi.product_id = p.id
            WHERE oi.order_id = ? AND p.seller_id = ?
        ');
        $ownsOrder->execute([$orderId, $user['id']]);

        if ($ownsOrder->fetchColumn() > 0) {
            $db->prepare('UPDATE orders SET status = ? WHERE id = ?')
               ->execute([$status, $orderId]);

            // Fetch order details for notifications
            $orderRow = $db->prepare('SELECT order_code, customer_id FROM orders WHERE id = ?');
            $orderRow->execute([$orderId]);
            $ord = $orderRow->fetch();

            if ($ord) {
                $code       = $ord['order_code'];
                $customerId = $ord['customer_id'];

                // Always notify the customer of the status change
                $statusMsg = [
                    'shipped'   => "Your order {$code} has been shipped! It's on its way.",
                    'delivered' => "Your order {$code} has been delivered successfully. Enjoy!",
                    'cancelled' => "Your order {$code} has been cancelled.",
                    'paid'      => "Your order {$code} payment has been confirmed.",
                ];
                if (isset($statusMsg[$status])) {
                    $db->prepare("INSERT INTO notifications (user_id, message, type) VALUES (?,?,?)")
                       ->execute([$customerId, $statusMsg[$status], 'order']);
                }

                // Notify the seller when the order is delivered
                if ($status === 'delivered') {
                    $db->prepare("INSERT INTO notifications (user_id, message, type) VALUES (?,?,?)")
                       ->execute([$user['id'], "Order {$code} has been marked as delivered.", 'order']);
                }
            }

            setToast('success', 'Order status updated.');
            redirect('/pages/seller/orders.php');
        }
    }
}

// ── Fetch all orders ──────────────────────────────────────────────────────────
$stmt = $db->prepare('
    SELECT DISTINCT
           o.id, o.order_code,
           GROUP_CONCAT(p.name SEPARATOR ", ") AS products,
           o.total, o.status, o.created_at,
           u.full_name AS customer_name
    FROM orders o
    JOIN order_items oi ON o.id = oi.order_id
    JOIN products p     ON oi.product_id = p.id
    JOIN users u        ON o.customer_id = u.id
    WHERE p.seller_id = ?
    GROUP BY o.id
    ORDER BY o.created_at DESC
');
$stmt->execute([$user['id']]);
$orders = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <?php $pageTitle = 'Orders'; include '../../includes/head.php'; ?>
  <style>
    .orders-table-card {
      background: #fff;
      border: 1px solid #ddd;
      border-radius: 12px;
      overflow: hidden;
      margin-top: 8px;
    }
    .orders-table-header {
      padding: 14px 24px;
      font-size: 11px;
      font-weight: 700;
      letter-spacing: 1.5px;
      text-transform: uppercase;
      color: #888;
      border-bottom: 1px solid #e8e3e0;
    }
    .orders-table {
      width: 100%;
      border-collapse: collapse;
    }
    .orders-table thead th {
      padding: 13px 20px;
      background: #fce4e4;
      font-size: 11px;
      font-weight: 800;
      text-transform: uppercase;
      letter-spacing: 0.8px;
      color: #333;
      text-align: left;
    }
    .orders-table tbody tr { border-top: 1px solid #f0ebe8; transition: background 0.1s; }
    .orders-table tbody tr:hover { background: #fafafa; }
    .orders-table tbody td { padding: 16px 20px; font-size: 14px; color: #333; }
    .status-select-wrap {
      position: relative;
      display: inline-block;
    }
    .status-select-wrap::after {
      content: '\25BE';
      position: absolute;
      right: 10px;
      top: 50%;
      transform: translateY(-50%);
      color: #fff;
      font-size: 13px;
      pointer-events: none;
    }
    .status-select-wrap select {
      padding: 7px 30px 7px 14px;
      border-radius: 8px;
      border: none;
      font-size: 12px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      cursor: pointer;
      color: #fff;
      appearance: none;
      -webkit-appearance: none;
      background: #555;
    }
    .status-select-wrap select.s-delivered,
    .status-select-wrap select.s-shipped,
    .status-select-wrap select.s-paid,
    .status-select-wrap select.s-cancelled { background: #666; }
  </style>
</head>
<body>
<?php include '../../includes/nav.php'; ?>

<div class="dash-layout">
  <?php include '../../includes/seller_sidebar.php'; ?>

  <main class="dash-main">
    <div class="dash-page-title">Incoming Orders</div>

    <div class="orders-table-card">
      <div class="orders-table-header">Recent Orders</div>
      <table class="orders-table">
        <thead>
          <tr>
            <th>Order ID</th>
            <th>Customer</th>
            <th>Items</th>
            <th>Total</th>
            <th>Status</th>
            <th>Update</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($orders)): ?>
            <tr>
              <td colspan="6" style="text-align:center;padding:40px;color:#888">No orders yet.</td>
            </tr>
          <?php else: ?>
            <?php foreach ($orders as $o): ?>
              <tr>
                <td><?= sanitize($o['order_code']) ?></td>
                <td><?= sanitize($o['customer_name']) ?></td>
                <td><?= sanitize($o['products']) ?></td>
                <td><?= formatPrice($o['total']) ?></td>
                <td>
                  <span class="badge badge-<?= $o['status'] ?>">
                    <?= strtoupper($o['status']) ?>
                  </span>
                </td>
                <td>
                  <form method="POST">
                    <input type="hidden" name="order_id" value="<?= $o['id'] ?>">
                    <input type="hidden" name="update_status" value="1">
                    <div class="status-select-wrap">
                      <select name="status" class="s-<?= $o['status'] ?>"
                              onchange="this.form.submit()">
                        <?php foreach (['paid', 'shipped', 'delivered', 'cancelled'] as $s): ?>
                          <option value="<?= $s ?>" <?= $o['status'] === $s ? 'selected' : '' ?>>
                            <?= strtoupper($s) ?>
                          </option>
                        <?php endforeach; ?>
                      </select>
                    </div>
                  </form>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </main>
</div>
<?php include '../../includes/toast.php'; ?>
</body>
</html>
