# MARKETPLACE. — PHP System

A Filipino local marketplace web app with three user roles: **Customer**, **Seller**, and **Admin**.

---

## Requirements
- PHP 8.0+ (with PDO & PDO_MySQL)
- MySQL 5.7+ or MariaDB 10+
- Apache / Nginx with mod_rewrite
- XAMPP / WAMP / LAMP recommended for local development

---

## Setup

### 1. Import the Database
1. Open **phpMyAdmin** (or MySQL CLI)
2. Create a new database called `marketplace_db`
3. Import `marketplace_db.sql`

### 2. Configure Database Connection
Edit `includes/config.php`:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'marketplace_db');
```

### 3. Place Files in Web Root
Copy the `marketplace/` folder into `htdocs/` (XAMPP) or `www/` (WAMP).
Access via: `http://localhost/marketplace/`

---

## Demo Accounts

| Role     | Email                    | Password |
|----------|--------------------------|----------|
| Admin    | admin@marketplace.com    | password |
| Seller   | seller@marketplace.com   | password |
| Customer | customer@marketplace.com | password |

---

## File Structure

```
marketplace/
├── index.php                  # Landing page (redirects logged-in users)
├── login.php                  # Login, Register, Forgot Password
├── logout.php                 # Destroys session and redirects
├── marketplace_db.sql         # DB schema + seed data
│
├── css/
│   └── style.css              # All shared styles
│
├── includes/
│   ├── config.php             # DB connection, auth helpers, utility functions
│   ├── head.php               # Shared <head> partial (title, css, fonts)
│   ├── nav.php                # Shared top navigation bar
│   ├── customer_sidebar.php   # Sidebar for customer pages
│   ├── seller_sidebar.php     # Sidebar for seller pages
│   └── admin_sidebar.php      # Sidebar for admin pages
│
└── pages/
    ├── customer/
    │   ├── dashboard.php      # Stats + recent orders
    │   ├── browse.php         # Product grid with search, filter, cart modal
    │   ├── cart.php           # Cart items, qty update, checkout
    │   ├── orders.php         # Full order history
    │   ├── notifications.php  # Filterable notifications
    │   └── profile.php        # Edit info + change password
    │
    ├── seller/
    │   ├── dashboard.php      # Sales stats + recent orders
    │   ├── products.php       # Add / edit / delete products
    │   ├── orders.php         # View & update order statuses
    │   ├── notifications.php  # Notifications
    │   └── profile.php        # Edit store info + change password
    │
    └── admin/
        ├── dashboard.php      # Platform overview
        ├── users.php          # Create, update role/status, delete users
        ├── products.php       # Update status, delete products
        ├── orders.php         # Update order statuses, filter
        └── profile.php        # Admin profile
```

---

## Key Includes Explained

| File | Purpose |
|------|---------|
| `config.php` | DB connection singleton, `requireRole()`, `sanitize()`, `formatPrice()`, helper functions |
| `head.php` | Outputs `<meta>`, `<title>`, CSS and font `<link>` tags — set `$pageTitle` before including |
| `nav.php` | Top bar with logo, cart icon (customers), dashboard link, user badge, sign out |
| `*_sidebar.php` | Role-specific left navigation; highlights the active page automatically |

---

## Design
- Black / Red color scheme
- Philippine Peso (₱) currency formatting
- Google Fonts: Bebas Neue + Outfit
